# Appearance theme — negative Electron baseline

**Result: 2 failed cases, 17 failed assertions.** Light-start case: 9. Dark-start case: 8.
Both cases reached all nine observation stages, including reload. No page errors.

## Provenance

- Documentary HEAD: `6642d46467304cbe1181d0963d51c085ec09a0c4`.
- Application source/build pin: `37c22c2fcff92fb76b10ffc97ec0643ac325d62f`.
- Frozen build: `/tmp/opencode/build-provider-draft-final`.
- All **90/90** renderer/main/preload distribution members match the freeze before and after execution; no extra distribution members.
- All **512/512** non-Markdown pinned application inputs match before and after execution.
- `packages/app/src/screens/system/settings.tsx` SHA-256: `b859cf9785ada768307e77a2546c02b80576b1491187b6ffa944c1673432eed6`.
- Test: `tests/e2e/appearance-theme.spec.ts`.
- Test SHA-256 before/after: `2bff6928c640ef274363b00e3861027488fa1025d0087135a93ddbee061949ba`.
- Test source stayed unchanged after the negative run. No application source or build writes.

## Execution

Actual Electron through the existing `launch` fixture; fresh renderer/engine data per case.
English, 960×640, light/dark route starts, reduced motion. OS color scheme emulated through Playwright.
Node `v22.23.3`; Xvfb; one worker; zero retries. Started `2026-10-03T12:22:52.284Z`.
Runner duration: 19.624s. Process exit code: 1.

`CORTEX_RENDERER_URL` removed from the runner environment, rather than set to an empty string.
`NODE_ENV=test`; `TMPDIR=/tmp/opencode/appearance-theme-baseline/tmp`.
Launch receives `CORTEX_CATALOG_URL=data:application/json,{}`. No API mocks or custom event dispatch.

Exact command, environment facts and process duration: [`run.json`](./run.json).
Full runner output: [`run.log`](./run.log). Machine report: [`results.json`](./results.json).
Integrity receipts: [`before-integrity.json`](./before-integrity.json), [`after-integrity.json`](./after-integrity.json).

## Exact failures

| Assertion | Light-start | Dark-start |
| --- | --- | --- |
| Selected radio owns the only Tab stop | Failed: `[0,0,0]`, expected `[-1,0,-1]` | Failed: `[0,0,0]`, expected `[-1,-1,0]` |
| ArrowRight selects/focuses adjacent radio | Failed: Dark unchecked/unfocused | Failed: System unchecked/unfocused |
| ArrowRight applies/saves preference | Failed: Light retained, expected Dark | Failed: Dark retained, expected System |
| ArrowLeft selects/focuses adjacent radio | Failed: System unchecked/unfocused | Failed: Light unchecked/unfocused |
| ArrowLeft applies/saves preference | Failed: Light retained, expected System | Failed: Dark retained, expected Light |
| Tab exits selected radio to Language | Failed: focus moved to Dark | Passed: Language follows last card |
| Appearance follows explicit rail preference | Failed: Light remains selected after rail Dark | Failed: Dark remains selected after rail Light |
| Appearance keeps System selected under light OS appearance | Failed: Light remains selected | Failed: Dark remains selected |
| Appearance keeps System selected under dark OS appearance | Failed: Light remains selected | Failed: Dark remains selected |

Pointer selection applies and saves the requested theme in both cases. Rail Space activation applies and saves the opposite theme in both cases. After rail System selection, storage stays `system` and HTML follows both emulated OS schemes. At reload, the retained `theme=system` URL, saved preference, both selected radios and dark resolved HTML agree.

Initial observation, intentionally separate from assertions: fresh storage is `null`; HTML/rail follow the requested hash theme; Appearance incorrectly selects System. Pointer setup isolates subsequent assertions from this initial mismatch.

Observations: [`appearance-theme-observations-light.json`](./appearance-theme-observations-light.json), [`appearance-theme-observations-dark.json`](./appearance-theme-observations-dark.json).

## Two diagnostic captures

One screenshot call per case; Playwright also retains a byte-identical attachment copy. Both images inspected at 960×640.

- [Dark rendered theme; stale Light card](./artifacts/appearance-theme-Appearanc-d4dec-synchronization-—-960-light/appearance-theme-dark.png): dark rail selected, main Light card selected.
- [Light rendered theme; stale Dark card](./artifacts/appearance-theme-Appearanc-bb3ff--synchronization-—-960-dark/appearance-theme-light.png): light rail selected, main Dark card selected.

## Static checks

Node 22: focused ESLint and repository `tsc -p tsconfig.json --pretty false` both exited 0 before the negative run.
Home/End are not asserted. The test covers ArrowRight, ArrowLeft, Tab and native Space activation.
