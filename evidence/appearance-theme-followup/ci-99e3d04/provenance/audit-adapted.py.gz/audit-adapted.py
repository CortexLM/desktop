import base64
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
from PIL import Image, ImageChops, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
REPO=Path('/root/.local/share/opencode/worktree/b489da9add1907e124bad2dfd49e8423fbd978b1/goal-desktop-rewrite')
OUT=REPO/'evidence/appearance-theme-followup/ci-99e3d04'
FROZEN=Path('/tmp/opencode/build-appearance-theme-final')
HEAD='99e3d04a8dab6b51b6cf23bcdae0365624492e0f'
PRIOR=REPO/'evidence/provider-draft-followup/ci-37c22c2'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_text())
git=lambda *args:subprocess.check_output(['git',*args],cwd=REPO)
blob=lambda name:git('show',HEAD+':'+name)
def save(name,data):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def specs(suites):
    for s in suites:yield from s.get('specs',[]);yield from specs(s.get('suites',[]))
retention=[]
def retain(source,name,normalize=False):
    raw=source.read_bytes(); p=OUT/(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(raw,mtime=0))
    row={'original':str(source),'retained':str(p.relative_to(OUT)),'rawSHA256':sha(raw),'rawBytes':len(raw),'gzipSHA256':sha(p.read_bytes())}
    if normalize:
        text='\n'.join(l.rstrip() for l in re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf-8-sig')).splitlines())+'\n'
        (OUT/name).write_text(text);row.update(normalized=name,normalizedSHA256=sha(text.encode()),transformation='BOM/ANSI removed, CRLF normalized, trailing whitespace stripped; original gzip retained.')
    retention.append(row);return row

checkout=load(ROOT/'metadata/checkout.json');assert checkout['tree']['sha']==git('rev-parse',HEAD+'^{tree}').decode().strip()
run=load(ROOT/'metadata/run.json');jobs=load(ROOT/'metadata/jobs.json')['jobs'];artifacts=load(ROOT/'metadata/artifacts.json')['artifacts']
assert run['head_sha']==HEAD and run['conclusion']=='success' and len(jobs)==3 and all(j['conclusion']=='success' for j in jobs)
tree={}
for entry in git('ls-tree','-rz',HEAD).split(b'\0'):
    if not entry:continue
    meta,name=entry.split(b'\t',1);mode,kind,digest=meta.decode().split();tree[name.decode()]={'mode':mode,'gitBlob':digest,'type':kind}
inputs=load(FROZEN/'pinned-inputs.json'); renderer=load(FROZEN/'renderer-inputs.json');members=load(FROZEN/'members.json')
assert len(inputs['inputs'])==514 and len(renderer['files'])==473 and len(members['members'])==90
input_rows=[]
for row in inputs['inputs']:
    raw=blob(row['path']);assert sha(raw)==row['sha256'],row['path']
    input_rows.append({**row,**tree[row['path']]})
for row in renderer['files']: assert sha(blob(row['path']))==row['sha256']
fingerprint=sha('\n'.join(f"{r['path']}:{r['sha256']}" for r in renderer['files']).encode())
assert fingerprint==renderer['sourceFingerprint']=='474405faaf26dba6319cb1c139f0b32ef04adf2b7e600d6edee37f72b4fabf44'
assert all(sha((FROZEN/r['path']).read_bytes())==r['sha256'] for r in members['members'])
assert {r['path'] for r in members['members']}=={str(p.relative_to(FROZEN)) for p in (FROZEN/'packages').rglob('*') if p.is_file()}
main=FROZEN/'packages/desktop/dist/main.cjs'
assert sha(main.read_bytes())=='f0fc4522cde726dd8b88dcbb56f4116ba93dc87e1e9e29163502d25e522512c7'
old_inputs=load(Path('/tmp/opencode/build-provider-draft-final/pinned-inputs.json'))['inputs']
old_index={r['path']:r['sha256'] for r in old_inputs}
deltas=[r['path'] for r in input_rows if old_index[r['path']]!=r['sha256']]
assert deltas==['packages/app/src/screens/system/settings.tsx','packages/app/src/shell/nav.tsx','packages/app/src/shell/shell.tsx']
pins=[]
paths=['tests/e2e/appearance-theme.spec.ts','packages/app/src/shell/nav.tsx','packages/app/src/shell/shell.tsx','tests/e2e/provider-draft.spec.ts','tests/e2e/provider-key-pending.spec.ts','tests/e2e/chat-missing.spec.ts','tests/e2e/code-models.spec.ts','packages/app/src/screens/system/settings.tsx','.github/workflows/ci.yml','tests/e2e/live-state.spec.ts','tests/e2e/bot-owner.spec.ts','tests/e2e/remote-auth.spec.ts','tests/e2e/fixtures.ts','tests/e2e/fake-provider.ts','tests/e2e/screens.spec.ts','playwright.config.ts','scripts/smoke.mjs','packages/desktop/src/main.ts','packages/app/src/state/live.ts','packages/app/src/screens/bots/bot.tsx','packages/app/src/kit/styles.css','packages/app/src/screens/system/system.css','packages/desktop/test/remote.test.ts']
for name in paths:
    raw=blob(name);p=ROOT/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    pins.append({'path':name,'sha256':sha(raw),**tree[name]})
expected={'tests/e2e/appearance-theme.spec.ts':'2bff6928c640ef274363b00e3861027488fa1025d0087135a93ddbee061949ba','packages/app/src/screens/system/settings.tsx':'4f0b4f911195eb7e5a12dc22ff9e940f0cd67190ce9eb44ae7c99d6054c80461','packages/app/src/shell/nav.tsx':'876682aef675ef9e0b1c5a3a59a49b00acbb1da84a7897f0dc17efa287579315','packages/app/src/shell/shell.tsx':'880240350484738971849dbabdfe591cd90471afc08fa0ffca02ef6f78a6ae67','tests/e2e/provider-draft.spec.ts':'bf57e5cdb18d53f31572ec04ec7727130574a1c33cbdf9cc3b6fcb4733365c3a','tests/e2e/provider-key-pending.spec.ts':'bcafa61de982af883954f648123c06370021b0dab8c8aca5003a2ec06d3d7477','tests/e2e/chat-missing.spec.ts':'a9bdc8e86f3ede94f0b54dc6a5d8b45142a62b98ad9fd0af2515c96bddb3d994','tests/e2e/code-models.spec.ts':'ff1bc7e7e6d08f59d713f0c7fccfb79fa35c02b682a870b804988145ae107ff5','tests/e2e/live-state.spec.ts':'842804966f6cd584834c728c92c495ccc52ece47bce2dcd128df912f98c83710','tests/e2e/bot-owner.spec.ts':'21af3392fad947945861063d93625d6115675f288ff43273568ea1fe4c50cdff','tests/e2e/remote-auth.spec.ts':'653016add38f51d766dfec52c205790de4b941c02739a993315c282469b1b0cb'}
for name,digest in expected.items():assert sha(blob(name))==digest
assert blob('tests/e2e/live-state.spec.ts')==(REPO/'evidence/live-state-followup/baseline/source/live-state.spec.ts').read_bytes()
assert blob('tests/e2e/bot-owner.spec.ts')==(REPO/'evidence/live-state-followup/bot-owner-baseline/source/bot-owner.spec.ts').read_bytes()
for filename in ['pinned-inputs.json','renderer-inputs.json','members.json']:save('provenance/'+filename,load(FROZEN/filename))
save('provenance/input-bindings.json',input_rows);save('source-pins.json',pins)
save('checkout-binding.json',{'head':HEAD,'checkout':checkout['sha'],'tree':checkout['tree']['sha'],'headCheckoutTreesEqual':True,'inputs':514,'rendererInputs':473,'rendererComparatorFingerprint':fingerprint,'frozenBuildMembers':90,'frozenMainSHA256':sha(main.read_bytes()),'inputDeltaFrom37c22c2':deltas,'originalSixRegressionTestsUnchanged':True,'ciASAROrMainCompared':False,'scope':'CI checkout matches source tree. Frozen local build receipt verified, not rebuilt. Test artifacts have no main bundle or ASAR; package/native receipt is coordinator-owned.'})

logs={}
for source in sorted((ROOT/'logs').glob('[012]_*.txt'))+[ROOT/'macos/out/smoke.log']:
    row=retain(source,'logs/'+source.name.replace(' ','-').replace(',',''),True);logs[source.name]=(OUT/row['normalized']).read_text()
for p in (ROOT/'metadata').glob('*.http'):retain(p,'metadata/'+p.name,True)
joblogs=[text for name,text in logs.items() if name!='smoke.log']
assert all(checkout['sha'] in text and 'HEAD is now at '+checkout['sha'][:7] in text for text in joblogs)
checklog=next(text for name,text in logs.items() if 'Lint' in name)
maclog=next(text for name,text in logs.items() if 'macOS' in name)
linuxlog=next(text for name,text in logs.items() if 'Linux' in name)
assert '245 passed' in checklog and re.search(r'245 passed\s*\|\s*1 skipped\s*\(246\)',checklog)
assert '65 files, 2272 keys used, 3405 keys in en, 0 problem(s)' in checklog
unit_rows=[{'path':p,'total':int(n),'skipped':int(skipped or 0)} for p,n,skipped in re.findall(r'✓ ([\w/.-]+\.test\.tsx?) \((\d+) tests?(?: \| (\d+) skipped)?\)',checklog)]
assert len(unit_rows)==22 and sum(r['total'] for r in unit_rows)==246 and sum(r['skipped'] for r in unit_rows)==1
for a in artifacts:assert a['digest'].split(':')[1] in '\n'.join(joblogs)
checkjob=next(j for j in jobs if j['name'].startswith('Lint'))
assert all(next(s for s in checkjob['steps'] if s['name']=='Run bun run '+n)['conclusion']=='success' for n in ['lint','typecheck','test','audit:i18n'])
save('checks-summary.json',{'lint':'pass','types':'pass','unitPassed':245,'unitSkipped':1,'unitFiles':22,'unitFileCounts':unit_rows,'optionalSkip':'lists models from a real backend; CORTEX_TEST_BACKEND_URL guard','i18n':{'files':65,'usedKeys':2272,'englishKeys':3405,'problems':0},'nodeVersions':{name:re.findall(r'node: v([0-9.]+)',text) for name,text in logs.items() if 'node: v' in text},'bun':'1.4.2','electron':'44.5.1','macOSUnitSuiteExecuted':False})

reuse={}
for location in [REPO/'evidence/appearance-theme-followup/electron-final',REPO/'evidence/live-state-followup/electron-final',REPO/'evidence/live-state-followup/electron-initial']:
    for line in (location/'images.jsonl').read_text().splitlines():
        row=json.loads(line);p=(location/row['canonical']).resolve();reuse.setdefault(row['rgbaSHA256'],p)
for row in load(PRIOR/'images.json'):reuse.setdefault(row['rgbaSHA256'],(PRIOR/row['canonical']).resolve())
images=[];targets=[];cases=[];scope={};summaries={};fonts={};geometry={};bot_checks=[];chat_checks=[]
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
answer='Hello from the streaming test provider. Everything works.'
previous_cases={(r['file'],r['title']) for r in load(PRIOR/'cases.json')}
all_case_ids={}
for side in ['e2e-linux','macos']:
    folder=ROOT/side;report=load(folder/'test-results/e2e.json');retain(folder/'test-results/e2e.json',side+'-report.json')
    rows=list(specs(report['suites']));tests=[t for s in rows for t in s['tests']];results=[r for t in tests for r in t['results']]
    assert len(rows)==len(tests)==len(results)==113 and not report['errors']
    assert all(t['status']=='expected' for t in tests) and all(r['status']=='passed' and r['retry']==0 and not r.get('errors') for r in results)
    assert all(p['retries']==0 for p in report['config']['projects'])
    assert report['config']['metadata']['gitCommit']['hash']==checkout['sha']
    assert report['config']['metadata']['ci']['buildHref'].endswith('/37124432902')
    assert sum('rendered 426 screen states' in o.get('text','') for r in results for o in r['stdout'])==1
    identities={(s['file'],s['title']) for s in rows};all_case_ids[side]=identities
    assert previous_cases<=identities and len(identities-previous_cases)==2
    assert {f for f,t in identities-previous_cases}=={'appearance-theme.spec.ts'}
    groups=defaultdict(list);names=defaultdict(list)
    for p in sorted(folder.rglob('*.png')):groups[sha(p.read_bytes())].append(p)
    scoped=[]
    for spec in rows:
        result=spec['tests'][0]['results'][0];atts=result['attachments'];decoded={a['name']:json.loads(base64.b64decode(a['body'])) for a in atts if a['contentType']=='application/json' and 'body' in a}
        cases.append({'os':side,'file':spec['file'],'title':spec['title'],'status':'passed','attempts':1,'retry':0,'durationMs':result['duration'],'attachments':[{'name':a['name'],'type':a['contentType']} for a in atts]})
        if decoded:scoped.append({'file':spec['file'],'title':spec['title'],'attachments':decoded})
        if 'auth-locale-fonts' in decoded:fonts[side]=decoded['auth-locale-fonts'];geometry[side]=decoded['auth-locale-geometry']
        if 'bot-owner-evidence' in decoded:
            e=decoded['bot-owner-evidence'];a,b=e['sessions']['alpha'],e['sessions']['beta'];held=json.loads(e['held']['body'])
            assert e['errors']==e['rendererHttp']==[] and e['held']['status']==200 and len(held)==1
            assert held[0]['id']==b['id'] and held[0]['botID']==b['botID'] and a['botID']!=b['botID']
            assert e['whileHeld']=={'users':[],'answers':[]} and e['afterRelease']==['Beta saved request']
            assert e['prompts']==[f"/api/sessions/{b['id']}/prompt"]
            def users(messages):return [p['text'] for m in messages if m['info']['role']=='user' for p in m['parts'] if p['type']=='text']
            assert len(e['alphaMessages'])==2 and len(e['betaMessages'])==4
            assert users(e['alphaMessages'])==['Alpha first request'] and users(e['betaMessages'])==['Beta saved request','Intended for Beta after navigation']
            assistants=[m for m in e['alphaMessages']+e['betaMessages'] if m['info']['role']=='assistant']
            assert len(assistants)==3 and all(m['info']['time'].get('completed') and not m['info'].get('error') and ''.join(p['text'] for p in m['parts'] if p['type']=='text')==answer for m in assistants)
            beta=[s for s in e['snapshots'] if s['title']=='Review Beta']
            assert beta and beta[0]['users']==beta[0]['answers']==[] and all('Alpha first request' not in s['users'] for s in beta)
            assert beta[-1]['users']==['Beta saved request','Intended for Beta after navigation'] and beta[-1]['answers']==[answer,answer]
            bot_checks.append({'os':side,'theme':e['theme'],'alphaSessionID':a['id'],'betaSessionID':b['id'],'heldStatus':200,'heldSessionID':held[0]['id'],'whileHeld':e['whileHeld'],'afterRelease':e['afterRelease'],'actualPostPaths':e['prompts'],'alphaUsers':users(e['alphaMessages']),'betaUsers':users(e['betaMessages']),'alphaMessages':2,'betaMessages':4,'completedAssistants':3,'domSamples':len(e['snapshots']),'betaSamples':len(beta),'noObservedAlphaUnderBeta':True,'errors':e['errors'],'rendererHttp':e['rendererHttp']})
        if 'live-state-evidence' in decoded:
            e=decoded['live-state-evidence'];err=decoded['live-state-errors'];held=decoded['held-real-history'];stream='completed stream' in spec['title']
            assert len(held)==2 and held[0]['parts'][0]['text']=='Earlier saved message must remain.' and err=={'errors':[],'rendererHttp':[]}
            nonsetup=[s for s in e['snapshots'] if s['phase']!='setup'];assert len(nonsetup)>=2
            counts=Counter(ev['type'] for ev in e['events']);completed={ev['properties']['message']['id'] for ev in e['events'] if ev['type']=='message.updated' and ev['properties']['message']['role']=='assistant' and ev['properties']['message']['time'].get('completed')}
            if stream:
                assert all('Newest streamed message must remain.' in s['users'] for s in nonsetup)
                assert nonsetup[-1]['users']==['Earlier saved message must remain.','Newest streamed message must remain.'] and nonsetup[-1]['answers']==[answer,answer]
                assert len(completed)==2 and counts['part.delta']==26 and counts['part.updated']==14 and counts['message.updated']==8 and counts['session.status']==4
            else:assert counts['session.deleted']==1 and all(not s['users'] and not s['answers'] for s in e['snapshots'])
            chat_checks.append({'os':side,'title':spec['title'],'eventCounts':dict(counts),'completedAssistantIDs':sorted(completed),'domSamples':len(e['snapshots']),'nonSetupSamples':len(nonsetup),'final':nonsetup[-1],'noObservedEraseOrRevival':True,**err})
        for a in atts:
            if a['contentType']!='image/png':continue
            if 'body' in a:
                raw=base64.b64decode(a['body']);digest=sha(raw)
                if digest not in groups:
                    p=ROOT/'inline'/side/(digest+'.png');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);groups[digest].append(p)
            else:
                suffix=a['path'].split('/test-results/',1)[1];p=folder/'test-results'/suffix;assert p.is_file(),p;digest=sha(p.read_bytes())
            names[digest].append({'file':spec['file'],'title':spec['title'],'name':a['name']})
    scope[side]=scoped
    side_images=[]
    for digest,paths in groups.items():
        p=min(paths,key=lambda p:('data' in p.parts or 'attachments' in p.parts,len(str(p))));im=Image.open(p).convert('RGBA');rgba=sha(im.tobytes())
        aliases=names[digest] or [{'file':'smoke','title':'renderer smoke','name':p.stem}]
        row={'os':side,'sha256':digest,'rgbaSHA256':rgba,'size':list(im.size),'originalPath':str(p),'aliases':aliases,'copies':[str(p.relative_to(folder)) if p.is_relative_to(folder) else str(p) for p in paths]}
        canonical=reuse.get(rgba)
        if canonical:
            prior=Image.open(canonical).convert('RGBA');assert im.size==prior.size and im.tobytes()==prior.tobytes()
            row['retention']='existing RGBA-exact canonical'
        else:
            canonical=OUT/'images'/(rgba+'.webp');canonical.parent.mkdir(exist_ok=True);im.save(canonical,lossless=True,exact=True,method=4)
            assert Image.open(canonical).convert('RGBA').tobytes()==im.tobytes();reuse[rgba]=canonical
            row['retention']='new RGBA-exact lossless WebP'
        row.update(canonical=os.path.relpath(canonical,OUT),retainedSHA256=sha(canonical.read_bytes()),rgbaExact=True)
        side_images.append(row)
    side_images.sort(key=lambda r:(r['aliases'][0]['file'],r['aliases'][0]['title'],r['aliases'][0]['name']))
    for i,row in enumerate(side_images,1):row['id']=f'{side}-{i:03d}'
    (OUT/'contacts').mkdir(exist_ok=True)
    for start in range(0,len(side_images),12):
        batch=side_images[start:start+12];sheet=Image.new('RGB',(1476,1512),'#d6d6d6');draw=ImageDraw.Draw(sheet)
        for i,row in enumerate(batch):
            x,y=i%3*492+6,i//3*378+4;im=Image.open(row['originalPath']).convert('RGB');im.thumbnail((480,320),Image.Resampling.LANCZOS);sheet.paste(im,(x,y))
            a=row['aliases'][0];draw.text((x,y+322),row['id']+' '+a['file'],fill='black',font=font);draw.text((x,y+342),a['name'][:55],fill='black',font=font);draw.text((x,y+362),a['title'][-55:],fill='black',font=font)
        name=f'contacts/{side}-{start//12+1:02d}.jpg';sheet.save(OUT/name,quality=92)
        for row in batch:row['contactSheet']=name
    for row in side_images:
        for a in row['aliases']:
            if a['file']=='appearance-theme.spec.ts' or a['name'].startswith('remote-locale-'):
                theme=a['title'].split(' — ')[-1] if ' — ' in a['title'] else 'dark'
                name=a['name']+'.png'
                link=ROOT/'full-size'/side/name;link.parent.mkdir(parents=True,exist_ok=True)
                if not link.exists():link.symlink_to(row['originalPath'])
                targets.append({'os':side,'view':name,'imageID':row['id'],'originalPath':str(link),'sha256':row['sha256'],'rgbaSHA256':row['rgbaSHA256'],'canonical':row['canonical'],'size':row['size']})
    summaries[side]={'cases':113,'attempts':113,'passed':113,'retries':0,'skipped':0,'flaky':0,'unexpected':0,'runnerErrors':0,'registeredRenderVisits':426,'workers':report['config']['metadata']['actualWorkers'],'startTime':report['stats']['startTime'],'durationMs':report['stats']['duration'],'caseFiles':dict(Counter(s['file'] for s in rows)),'diskPngFiles':len(list(folder.rglob('*.png'))),'uniquePNGs':len(groups),'reportSHA256':sha((folder/'test-results/e2e.json').read_bytes()),'metadata':{k:v for k,v in report['config']['metadata'].items() if k!='gitDiff'},'noMainBundleOrASARInArtifact':not any(p.name=='main.cjs' or p.suffix=='.asar' for p in folder.rglob('*'))}
    images+=side_images
assert all_case_ids['e2e-linux']==all_case_ids['macos']
assert len(targets)==20 and Counter(r['os'] for r in targets)=={'e2e-linux':10,'macos':10}
assert len(bot_checks)==4 and len(chat_checks)==8
save('e2e-summary.json',summaries);save('cases.json',cases);save('scoped-attachments.json',scope);save('images.json',images);save('fullsize-targets.json',targets);save('bot-checks.json',bot_checks);save('chat-checks.json',chat_checks)
save('font-records.json',fonts);save('locale-geometry.json',geometry)
locale_summary={}
for side,rows in geometry.items():
    assert len(rows)==80 and len({(r['locale'],r['theme'],r['state']) for r in rows})==80
    text=[c for r in rows for c in r['copy']];controls=[c for r in rows for c in r.get('keyboard',[])]
    assert len(text)==384 and len(controls)==144 and all(c['readable'] for c in text) and all(c['reachable'] for c in controls)
    assert all(abs(c['opacity']-(0.7 if r['state']=='option-unavailable' else 1))<.005 for r in rows for c in r['copy'])
    records=fonts[side];assert len(records)==6 and {(r['locale'],r['theme']) for r in records}=={(l,t) for l in ['ja','ko','zh-Hans'] for t in ['light','dark']}
    for r in records:
        assert r['pair']=={'ja':['あ','ア'],'ko':['한','글'],'zh-Hans':['汉','字']}[r['locale']]
        assert [w['weight'] for w in r['weights']]==[400,500]
        assert all(w['passed'] and w['ink']==[True,True] and w['distinct'] and w['notMissing']==[True,True] for w in r['weights'])
        assert any(not f['isCustomFont'] and f['glyphCount']>0 for f in r['platformFonts'])
    locale_summary[side]={'primaryStates':48,'measurementRecords':80,'textRows':384,'keyboardStops':144,'fontRecords':6,'passingWeightChecks':12,'glyphFailurePNGs':sum(a['name'].startswith('auth-glyph-') for s in cases if s['os']==side for a in s['attachments']),'localeCaptures':8}
save('locale-summary.json',locale_summary)
font_inventory=ROOT/'e2e-linux/out/fonts/fontconfig.tsv';packages=ROOT/'e2e-linux/out/fonts/packages.tsv'
retain(font_inventory,'fonts/fontconfig.tsv',True);retain(packages,'fonts/packages.tsv',True)
inventory=[]
for line in font_inventory.read_text().splitlines():
    file,index,family,postscript,charset=line.split('\t');inventory.append({'file':file,'index':index,'family':family,'postscript':postscript,'charset':charset})
font_binding=[]
for r in fonts['e2e-linux']:
    heading=next(g['copy'][0]['text'] for g in geometry['e2e-linux'] if g['locale']==r['locale'] and g['theme']==r['theme'] and g['state']=='code_sent')
    for f in r['platformFonts']:
        if f['isCustomFont']:continue
        assert f['familyName'].startswith('Noto Sans CJK')
        matches=[p for p in inventory if p['postscript']==f['postScriptName']];assert matches
        needed={ord(c) for c in heading+''.join(r['pair']) if not c.isspace()}
        def charset(chars):
            points=set()
            for word in chars.split():
                span=word.split('-');points.update(range(int(span[0],16),int(span[-1],16)+1))
            return points
        assert any(needed<=charset(p['charset']) for p in matches)
        font_binding.append({'locale':r['locale'],'theme':r['theme'],'platformFont':f,'inventoryMatches':[{k:v for k,v in p.items() if k!='charset'} for p in matches],'headingAndSentinelCharactersCovered':True})
assert 'fonts-noto-cjk\t1:20230817+repack1-3\tinstall ok installed' in packages.read_text()
assert 'Selecting previously unselected package fonts-noto-cjk' in linuxlog and 'Setting up fonts-noto-cjk (1:20230817+repack1-3)' in linuxlog
save('font-provisioning.json',{'packageVersion':'1:20230817+repack1-3','fontconfigVersion':'2.15.0-1.1ubuntu2','packagePreviouslyUnselectedInThisRun':True,'inventoryPatterns':len(inventory),'inventoryFiles':len({r['file'] for r in inventory}),'matchedPlatformFonts':font_binding,'scope':'Current CI provisioning, raster and actual-heading font evidence. Historical CI1076 lacked inventory; its package-versus-configuration cause remains unknown. CI37 already verifies Noto provisioning. JP font selected for Chinese is recorded, not relabeled SC.'})

drift=[]
old_targets=load(PRIOR/'fullsize-targets.json')
for row in targets:
    if not row['view'].startswith('remote-locale-'):continue
    previous=next(r for r in old_targets if r['os']==row['os'] and r['view']==row['view'])
    a=Image.open(PRIOR/previous['canonical']).convert('RGBA');b=Image.open(row['originalPath']).convert('RGBA');assert a.size==b.size
    delta=ImageChops.difference(a,b);mask=ImageChops.lighter(ImageChops.lighter(delta.getchannel('R'),delta.getchannel('G')),ImageChops.lighter(delta.getchannel('B'),delta.getchannel('A')))
    drift.append({'os':row['os'],'view':row['view'],'priorCanonical':os.path.relpath(PRIOR/previous['canonical'],OUT),'priorPNG_SHA256':previous['sha256'],'currentPNG_SHA256':row['sha256'],'changedPixels':a.width*a.height-mask.histogram()[0],'bounds':mask.getbbox(),'samePNG':previous['sha256']==row['sha256'],'cause':'No drift' if previous['sha256']==row['sha256'] else 'Unknown; no cause attributed.'})
save('locale-image-drift.json',drift)
assert 'SMOKE OK' in maclog and 'could not create image from display' in maclog and 'screencapture failed: Command failed: screencapture -x out/smoke-screen.png' in maclog
assert not (ROOT/'macos/out/smoke-screen.png').exists()
diagnostics=[]
for p in (ROOT/'macos').rglob('*.ips'):
    raw=p.read_bytes();header,body=raw.decode().split('\n',1);header=json.loads(header);body=json.loads(body)
    diagnostics.append({**retain(p,'logs/'+p.name),'appName':header['app_name'],'timestamp':header['timestamp'],'simulated':header.get('is_simulated')==1,'exception':body['exception']['type'],'terminationNamespace':body['termination']['namespace']})
save('smoke-and-crash.json',{'smoke':'process/window/renderer success','nativeDisplayCapture':'failed','nativeCaptureCause':'unknown; stderr retained','nativeDisplayFile':False,'diagnostics':diagnostics,'cortexCrashDiagnosticInArtifact':any('Cortex' in d['appName'] for d in diagnostics),'crashFreeClaim':False,'packageDownloaded':False,'ciASARCompared':False,'packageArtifactID':11274389994})
save('retention.json',retention)
print(json.dumps({'e2e':{k:{x:v for x,v in s.items() if x not in ['metadata','caseFiles']} for k,s in summaries.items()},'images':len(images),'globalUniquePNG':len({r['sha256'] for r in images}),'globalUniqueRGBA':len({r['rgbaSHA256'] for r in images}),'retention':dict(Counter(r['retention'] for r in images)),'contacts':len(list((OUT/'contacts').glob('*.jpg'))),'fullSizeViews':len(targets),'uniqueFullSizeImages':len({r['sha256'] for r in targets}),'botChecks':bot_checks,'chatChecks':chat_checks,'fontPatterns':len(inventory),'fontFiles':len({r['file'] for r in inventory}),'diagnostics':diagnostics},indent=2))
