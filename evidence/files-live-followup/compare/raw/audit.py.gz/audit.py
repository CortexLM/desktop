"""Audit existing source/build/PNG receipts offline; retain only within assigned scope."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
from urllib.parse import urlsplit, unquote
import difflib, gzip, hashlib, json, os, subprocess
from PIL import Image, ImageDraw, ImageFont

REPO = Path.cwd()
OUT = REPO / 'evidence/files-live-followup/compare'
TMP = Path('/tmp/opencode/files-compare-audit')
BASE = Path('/tmp/opencode/files-live/compare-corrected')
BUILD = Path('/tmp/opencode/build-files-corrected')
OLD = Path('/tmp/opencode/build-work-activity')
SOURCE = BUILD / 'source'
FREEZE = Path('/root/cortex-ui-freezes/2026-10-02-7b388e2d9674')
REV = 'd390cce590600cf5896fa19acf0ddd44d7057e2c'
COMMIT = 'd20a012fbb774aa9b348fe1913f85d3476430098'
ORIGINAL = REPO / 'evidence/files-live-followup/production'
FP = '087587293bfb7c2ccf85176cece73982ae75db48318e1c381270caa5196a0d73'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
fp = lambda rows: sha('\n'.join(f'{p}:{h}' for p,h in sorted(rows.items())).encode())
pins = {}

def read(p):
    p = Path(p); data = p.read_bytes(); pins[str(p)] = sha(data); return data

def save(name, data):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')

def copy(src, name):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(read(src))

def rgba(p):
    read(p)
    with Image.open(p) as im:
        im.load(); assert im.size == (2880,1800); return im.convert('RGBA')

started = datetime.now(timezone.utc).isoformat()
rows = json.loads(read(BASE/'report.json')); prov = json.loads(read(BASE/'provenance.json')); run = prov['runs'][0]
assert sha((BASE/'report.json').read_bytes()) == prov['reportSha256']
assert len(rows) == len({r['name'] for r in rows}) == 9 and len(prov['runs']) == 1
assert prov['counts'] == {'registered':426,'optionalInteractions':5,'capturedThisRun':9,'retainedRows':9,'compared':8,'noDesignShot':1}
assert run['baseUrl'] == 'http://127.0.0.1:5433/' and run['only'] == ['file-image','chat'] and run['jobCount'] == 9
clock = {'mode':'fixed','source':'cli','time':'2026-10-02T12:00:00.000Z','timezone':'UTC','timers':'real'}
assert prov['clock'] == run['clock'] == clock
assert prov['render'] == {'viewport':{'width':1440,'height':900},'deviceScaleFactor':2,'locale':'fr-FR','catalogLocale':'fr','pixelmatchThreshold':0.15}
assert sha(read(REPO/'scripts/compare-shots.mjs')) == prov['comparatorSha256']
documents = {n:json.loads(read(ORIGINAL/n)) for n in ['pinned-inputs.json','renderer-inputs.json','members.json','linux-package.json']}
for r in documents.values(): assert r['revision'] == REV and r['dirty'] is True
later = []
for name,key in [('pinned-inputs.json','inputs'),('renderer-inputs.json','files'),('members.json','members')]:
    bound = json.loads(read(BUILD/name))
    assert bound['revision'] == COMMIT and bound['dirty'] is False
    assert {k:v for k,v in bound.items() if k not in ['revision','dirty']} == {k:v for k,v in documents[name].items() if k not in ['revision','dirty']}
    later.append({'receipt':name,'originalSHA256':sha(read(ORIGINAL/name)),'boundSHA256':sha(read(BUILD/name)),'payloadUnchanged':True})
imap = {r['path']:r['sha256'] for r in documents['pinned-inputs.json']['inputs']}
bmap = {r['path']:r['sha256'] for r in documents['members.json']['members']}
assert len(imap) == len(documents['pinned-inputs.json']['inputs']) == 520
assert len(bmap) == len(documents['members.json']['members']) == 90
actual = {str(p.relative_to(SOURCE)):sha(read(p)) for p in SOURCE.rglob('*') if p.is_file()}
assert actual == imap
batch = subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for path,digest in sorted(imap.items()):
    batch.stdin.write((COMMIT+':'+path+'\n').encode()); batch.stdin.flush(); head=batch.stdout.readline()
    assert b' blob ' in head,head
    data=batch.stdout.read(int(head.split()[-1])); assert batch.stdout.read(1)==b'\n' and sha(data)==digest
batch.stdin.close(); assert batch.wait()==0
roots = ['packages/app/src','packages/app/public','packages/client/src','packages/core/src','packages/desktop/src','packages/i18n/src','packages/i18n/locales','packages/protocol/src','packages/schema/src','packages/server/src','skills']
singles = ['bun.lock','electron-builder.yml','package.json','packages/app/index.html','packages/app/package.json','packages/app/vite.config.ts','packages/client/package.json','packages/core/README.md','packages/core/package.json','packages/desktop/build.mjs','packages/desktop/package.json','packages/i18n/package.json','packages/protocol/package.json','packages/schema/package.json','packages/server/package.json','tsconfig.json']
assert {str(p.relative_to(SOURCE)) for root in roots for p in (SOURCE/root).rglob('*') if p.is_file()} | set(singles) == set(imap)
assert {str(p.relative_to(BUILD)):sha(read(p)) for root in ['packages/app/dist','packages/desktop/dist'] for p in (BUILD/root).rglob('*') if p.is_file()} == bmap
rmap = {}
for name in prov['application']['sourcePaths']:
    p = SOURCE/name
    for f in p.rglob('*') if p.is_dir() else [p]:
        if f.is_file(): rmap[str(f.relative_to(SOURCE))] = sha(read(f))
assert len(rmap) == documents['renderer-inputs.json']['sourceFileCount'] == prov['application']['sourceFileCount'] == 478
assert rmap == {r['path']:r['sha256'] for r in documents['renderer-inputs.json']['files']}
assert fp(rmap) == documents['renderer-inputs.json']['sourceFingerprint'] == prov['application']['sourceFingerprint'] == FP
assert prov['application']['revision'] == run['applicationRevision'] == REV
linux = documents['linux-package.json']
assert linux['packageInputs'] == 520 and linux['buildMembers'] == 90 and linux['rendererFingerprint'] == FP
assert linux['asarSHA256'] == '9eeffe464327d09642b8f7ac27facbbf7d54f3c776d3d507e19083b92c11c893'
assets = []
for a in run['build']['files']:
    u = urlsplit(a['url']); assert u.scheme == 'http' and u.netloc == '127.0.0.1:5433' and not u.query and not u.fragment
    name = 'packages/app/dist/'+(unquote(u.path).lstrip('/') or 'index.html')
    assert '..' not in Path(name).parts and name in bmap
    data = read(BUILD/name); assert sha(data) == bmap[name] == a['sha256'] and len(data) == a['bytes']
    assets.append({**a,'frozenMember':name})
assert len(assets) == 20
assert sha('\n'.join(f"{a['url']}:{a['sha256']}" for a in run['build']['files']).encode()) == run['build']['sha256']
assert len(run['ignoredPreviewApiErrors']) == 9 and all(e['url']=='http://127.0.0.1:5433/api/projects' and '404' in e['message'] for e in run['ignoredPreviewApiErrors'])
previous = json.loads(read(OLD/'pinned-inputs.json')); pi = {r['path']:r['sha256'] for r in previous['inputs']}
pm = {r['path']:r['sha256'] for r in json.loads(read(OLD/'members.json'))['members']}
assert previous['revision'] == '9ba8e59fbec8c1f38f93ace25414d4a3489aede3' and previous['dirty'] is False
assert {str(p.relative_to(OLD/'source')):sha(read(p)) for p in (OLD/'source').rglob('*') if p.is_file()} == pi and len(pi) == 517
assert {str(p.relative_to(OLD)):sha(read(p)) for root in ['packages/app/dist','packages/desktop/dist'] for p in (OLD/root).rglob('*') if p.is_file()} == pm
added = sorted(imap.keys()-pi.keys()); changed = sorted(p for p in imap.keys()&pi.keys() if imap[p]!=pi[p])
assert added == ['packages/app/src/screens/files/image.tsx','packages/app/src/screens/files/raster.test.ts','packages/app/src/screens/files/raster.ts'] and len(changed) == 14 and not pi.keys()-imap.keys()
assert all(imap[p]==pi[p] for p in pi if p.startswith(('packages/core/','packages/desktop/','packages/protocol/','packages/client/','packages/schema/','packages/server/')))
main = [p for p in bmap if p.startswith('packages/desktop/dist/')]; assert len(main)==4 and all(bmap[p]==pm[p] for p in main)
fragment = lambda text: text.split('function PreviewChat(',1)[1].split('const textOf',1)[0]
chat = 'packages/app/src/screens/chat/live-chat.tsx'
assert fragment((SOURCE/chat).read_text()) == fragment((OLD/'source'/chat).read_text())
translations = []
for p in changed:
    if p.startswith('packages/i18n/locales/'):
        a,b = load(OLD/'source'/p),load(SOURCE/p)
        assert len(b.keys()-a.keys())==19 and all(b[k]==v for k,v in a.items())
        translations.append({'path':p,'newKeys':sorted(b.keys()-a.keys()),'existingValuesUnchanged':True})
assert len(translations)==8
assert 'dimensions' not in (SOURCE/'packages/app/src/screens/files/media.tsx').read_text().split('export function ImageScreen()',1)[1].split('// Before / after',1)[0]
assert imap['packages/app/src/screens/chat/states.tsx']==pi['packages/app/src/screens/chat/states.tsx']
patch = ''.join(''.join(difflib.unified_diff((OLD/'source'/p).read_text().splitlines(True),(SOURCE/p).read_text().splitlines(True),fromfile='9ba8e59/'+p,tofile='files/'+p)) for p in changed if not p.endswith('.json'))
OUT.mkdir(parents=True,exist_ok=True); (OUT/'source.patch').write_text(patch)
save('source-build-delta.json',{'priorApplication':previous['revision'],'currentDirtyBase':REV,'currentRendererFingerprint':FP,'added':[{'path':p,'sha256':imap[p]} for p in added],'changed':[{'path':p,'before':pi[p],'after':imap[p]} for p in changed],'unchangedPriorInputs':503,'PreviewChatFunctionByteExact':True,'PreviewChatFunctionSHA256':sha(fragment((SOURCE/chat).read_text()).encode()),'chatStatesSourceUnchanged':True,'ImageScreenPassesNoDimensions':True,'rasterTestListedBySourceFingerprintNotRuntimeImport':True,'translationDelta':translations,'membersSamePathAndBytes':sum(bmap.get(p)==h for p,h in pm.items()),'buildAdded':[{'path':p,'sha256':bmap[p]} for p in sorted(bmap.keys()-pm.keys())],'buildRemoved':[{'path':p,'sha256':pm[p]} for p in sorted(pm.keys()-bmap.keys())],'buildChanged':[p for p in sorted(bmap.keys()&pm.keys()) if bmap[p]!=pm[p]],'mainPreloadMapsByteExact':main})
freeze = json.loads(read(FREEZE/'freeze.json')); fsource = {str(p.relative_to(FREEZE)):sha(read(p)) for p in (FREEZE/'src').rglob('*') if p.is_file()}
assert len(fsource)==freeze['sourceFileCount']==prov['reference']['sourceFileCount']==106
assert fp(fsource)==freeze['sourceFingerprint']==prov['reference']['sourceFingerprint']=='7b388e2d967400d20bf5f2cc7cd44c56ba74859889908c220964f8d12abfc768'
meta = {'freezeSha256':'freeze.json','manifestSha256':'shots/manifest.json','registrySha256':'shots/registry.json','coverageSha256':'review/cmp/coverage.json','motionIndexSha256':'public/states/index.json'}
for key,name in meta.items(): assert sha(read(FREEZE/name))==prov['reference'][key]
manifest=json.loads(read(FREEZE/'shots/manifest.json'))['images']
expected = [('chat-'+t,'chat','',t,None) for t in ['dark','light']] + [(f'file-image~{a}-{t}','file-image',v,t,None) for a,v in [('view','affichage'),('zoom','zoom'),('compare','comparaison')] for t in ['dark','light']] + [('file-image+ask-light','file-image','affichage','light','ask')]
assert [r['name'] for r in rows]==[e[0] for e in expected]
originals=[]
for row,(_,route,variant,theme,interaction) in zip(rows,expected):
    state=dict(route=route,variant=variant,theme=theme,interaction=interaction)
    assert row['clock']==clock and row['run']==run['id']
    assert all(row['reference'][k]==v for k,v in state.items())
    matches=[(n,r) for n,r in manifest.items() if all(r[k]==v for k,v in state.items())]
    if row.get('status'):
        assert not matches and row['status']=='no-design-shot' and list(row['files'])==['app']
    else:
        assert len(matches)==1; name,ref=matches[0]
        assert row['reference']=={**ref,'file':name} and row['ref']==name
        assert sha(read(FREEZE/'shots'/name))==ref['sha256']
        assert read(BASE/row['files']['design']['file'])==read(FREEZE/'shots'/name)
    for kind,f in row['files'].items():
        p=BASE/f['file']; data=read(p); assert sha(data)==f['sha256'] and len(data)==f['bytes']
        with Image.open(p) as im: im.verify()
        image=rgba(p); originals.append({'state':row['name'],'kind':kind,**f,'width':2880,'height':1800,'rgbaSHA256':sha(image.tobytes()),'alphaExtrema':list(image.getchannel('A').getextrema())})
assert len(originals)==25
metrics=json.loads(read(TMP/'metrics.json')); assert [r['name'] for r in metrics['rows']]==[r['name'] for r in rows]
for name in ['report.json','provenance.json']: copy(BASE/name,name)
copy(TMP/'metrics.json','metrics.json'); copy('/tmp/opencode/files-live/compare-corrected.log','capture.log')
copy('/tmp/opencode/files-live/compare.log','negative/first-attempt.log')
negative=(OUT/'negative/first-attempt.log').read_text(); assert 'ERR_EMPTY_RESPONSE' in negative and '5432/#/gallery' in negative
save('negative/receipt.json',{'status':'failed-before-capture','stage':'initial-gallery-request','error':'net::ERR_EMPTY_RESPONSE','port':5432,'creditedCaptures':0,'source':'first-attempt.log','cause':'Coordinator reports occupied-port launch refusal; this retained log independently establishes only an empty gallery response. No earlier image credit.'})
for name in documents: copy(ORIGINAL/name,'binding/'+name)
for name in ['pinned-inputs.json','renderer-inputs.json','members.json']: copy(BUILD/name,'binding/committed/'+name)
copy(ORIGINAL/'application-pin.json','binding/application-pin.json')
save('commit-binding.json',{'captureDirtyBase':REV,'laterCommit':COMMIT,'gitInputsMatched':520,'originalDirtyReceiptsPreserved':True,'headerBindings':later,'scope':'Exact later Git/source attribution; no clean rebuild or new ASAR/package/CI/native execution.'})
save('binding/verified.json',{'status':'passed','captureDirtyBase':REV,'sourceFiles':520,'rendererFiles':478,'rendererFingerprint':FP,'completeFrozenSourcePathSet':True,'completeRendererPathSet':True,'completeMemberPathSet':True,'buildMembers':90,'servedAssetCount':len(assets),'servedAssets':assets,'referenceSourceFiles':106,'referenceSourceFingerprint':fp(fsource),'referenceSelectedMappings':8,'explicitGaps':1,'suppliedPNGCount':25,'linuxASARReceipt':linux['asarSHA256'],'asarBytesIndependentlyRead':False,'limits':'Frozen copied files and served-byte receipt match; source receipt retains dirty provenance. No new build, live HTTP verification, CI or packaged/native execution.'})
save('original-images.json',originals)
archive=[]
for src,name in [(REPO/'scripts/compare-shots.mjs','comparator.mjs.gz'),(FREEZE/'shots/manifest.json','reference-manifest.json.gz'),(FREEZE/'freeze.json','reference-freeze.json.gz'),(BASE/'index.html','original-index.html.gz')]:
    data=read(src); target=OUT/'raw'/name; target.parent.mkdir(exist_ok=True); target.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(target.read_bytes())==data; archive.append({'source':str(src),'originalSHA256':sha(data),'originalBytes':len(data),'file':'raw/'+name,'sha256':sha(target.read_bytes())})
save('raw-retention.json',archive)
retained=[]
for original in originals:
    if original['kind']=='diff': continue
    row=next(r for r in rows if r['name']==original['state']); source=BASE/original['file']; im=rgba(source)
    candidates=sorted((REPO/'evidence').glob(f"**/{original['state']}.{original['kind']}.webp"))
    canonical=None
    for p in candidates:
        if OUT in p.parents: continue
        with Image.open(p) as candidate:
            if candidate.size!=im.size: continue
            if candidate.convert('RGBA').tobytes()==im.tobytes(): canonical=p; read(p); break
    if canonical is None:
        target=OUT/'images'/f"{original['state']}.{original['kind']}.webp"; target.parent.mkdir(exist_ok=True)
        im.save(target,format='WEBP',lossless=True,method=6,exact=True)
        storage='new-lossless-WebP'
    else: target=canonical; storage='existing-RGBA-exact-canonical'
    with Image.open(target) as check: assert check.convert('RGBA').tobytes()==im.tobytes()
    retained.append({'state':original['state'],'kind':original['kind'],'sourcePNG':original['file'],'sourceSHA256':original['sha256'],'sourceBytes':original['bytes'],'rgbaSHA256':original['rgbaSHA256'],'file':os.path.relpath(target,OUT),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'width':2880,'height':1800,'rgbaExact':True,'storage':storage})
save('retained.json',{'policy':'App/reference RGBA-exact lossless retention; canonical reuse requires byte-for-byte decoded RGBA equality. Supplied diff PNG hashes/metrics retained, no bulk triplets.','newWebPs':sum(r['storage']=='new-lossless-WebP' for r in retained),'canonicalReuses':sum(r['storage']=='existing-RGBA-exact-canonical' for r in retained),'images':retained})
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
contacts=[]
for start in range(0,len(rows),3):
    group=rows[start:start+3]; sheet=Image.new('RGB',(1732,len(group)*394),(238,238,238)); draw=ImageDraw.Draw(sheet)
    for y,row in enumerate(group):
        draw.text((8,y*394+4),row['name']+' | app / frozen / original diff | '+str(row.get('diffPct','no reference'))+'%',fill=(20,20,20),font=font)
        for col,kind in enumerate(['app','design','diff']):
            if kind not in row['files']: continue
            image=rgba(BASE/row['files'][kind]['file']).convert('RGB'); image.thumbnail((568,355),Image.Resampling.LANCZOS); sheet.paste(image,(8+col*576,y*394+30))
    target=OUT/'contacts'/f'pairs-{start//3+1:02d}.jpg'; target.parent.mkdir(exist_ok=True); sheet.save(target,quality=90)
    contacts.append({'file':str(target.relative_to(OUT)),'sha256':sha(target.read_bytes()),'states':[r['name'] for r in group],'derivedFromOriginalPNGs':True})
save('contacts.json',contacts)
lines=['# Files image/Chat comparison row ledger','','Original report/provenance remain unchanged. Links retain full-resolution RGBA; percentages are original rounded comparator values.','','| State | App | Frozen reference | Difference % | Original capture UTC |','| --- | --- | --- | ---: | --- |']
for row in rows:
    a=next(r for r in retained if r['state']==row['name'] and r['kind']=='app'); d=next((r for r in retained if r['state']==row['name'] and r['kind']=='design'),None)
    ref=f"[{row['ref']}]({d['file']})" if d else '**No matching frozen reference**'
    lines.append(f"| `{row['name']}` | [image]({a['file']}) | {ref} | {row.get('diffPct','gap')} | {row['capturedAt']} |")
(OUT/'image-index.md').write_text('\n'.join(lines)+'\n')
assert all(sha(Path(p).read_bytes())==h for p,h in pins.items())
save('binding/input-hashes.json',pins)
save('verification.json',{'status':'passed','startedUTC':started,'finishedUTC':datetime.now(timezone.utc).isoformat(),'inputFilesStable':len(pins),'imageDecoder':'Pillow '+Image.__version__,'watchedInputHashes':'binding/input-hashes.json','pixelVerifierSHA256':sha(read(TMP/'pixels.mjs')),'bindingVerifierSHA256':sha(Path(__file__).read_bytes()),'rawPNGCount':25,'newWebPs':sum(r['storage']=='new-lossless-WebP' for r in retained),'canonicalReuses':sum(r['storage']=='existing-RGBA-exact-canonical' for r in retained),'newWebPBytes':sum(r['bytes'] for r in retained if r['storage']=='new-lossless-WebP'),'newCaptures':0,'networkRequests':0,'applicationTests':0,'builds':0})
print(json.dumps(load(OUT/'verification.json'),indent=2))
