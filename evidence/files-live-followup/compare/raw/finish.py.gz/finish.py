"""Finalize bounded offline review receipts; never reads a running application."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json
from PIL import Image, ImageChops

REPO=Path.cwd(); OUT=REPO/'evidence/files-live-followup/compare'; TMP=Path('/tmp/opencode/files-compare-audit')
BASE=Path('/tmp/opencode/files-live/compare-corrected'); OLD=Path('/tmp/opencode/current-full-compare-6d96535')
FREEZE=Path('/root/cortex-ui-freezes/2026-10-02-7b388e2d9674')
sha=lambda b:hashlib.sha256(b).hexdigest(); load=lambda p:json.loads(p.read_bytes())
def save(n,d): (OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def im(p):
    with Image.open(p) as i: return i.convert('RGBA')
rows=load(OUT/'report.json'); metrics=load(OUT/'metrics.json'); retention=load(OUT/'retained.json'); pins=load(OUT/'binding/input-hashes.json')
regional=[]
for row in rows:
    current=im(BASE/row['files']['app']['file']); before=next(r for r in metrics['rows'] if r['name']==row['name'])['history']['original']
    previous=im(OLD/before['files']['app']['file']); reference=im(BASE/row['files']['design']['file']) if 'design' in row['files'] else None
    rects=[('main-interior',[754,150,2790,1690])]
    if row['name'].startswith('chat-'): rects += [('transcript-text-code',[1150,430,2460,1080])]
    if '~view' in row['name']: rects += [('photo-controls-metadata',[784,250,2760,1670])]
    if '~zoom' in row['name']: rects += [('zoom-image-minimap',[784,349,2760,1660])]
    if '~compare' in row['name']: rects += [('comparison-image-handle',[784,349,2760,1660])]
    if '+ask' in row['name']: rects += [('ask-response-text',[2185,275,2730,850])]
    for label,rect in rects:
        a=current.crop(rect); record={'state':row['name'],'region':label,'rect':rect,'rgbaSHA256':sha(a.tobytes())}
        for key,b in [('previous',previous),('frozen',reference)]:
            if b is None: continue
            diff=ImageChops.difference(a,b.crop(rect)); channels=diff.split(); mask=channels[0]
            for c in channels[1:]: mask=ImageChops.lighter(mask,c)
            count=sum(mask.histogram()[1:]); record[key]={'rawPixels':count,'rgbaExact':count==0,'localBounds':mask.getbbox()}
        regional.append(record)
save('regions.json',{'policy':'Diagnostic unshifted crops, not replacement whole-frame metrics. Coordinates are original device pixels.','rows':regional})
visual=[]
for row in rows:
    name=row['name']
    if name.startswith('chat-'):
        finding='Readable French transcript, code block and composer align; two inherited French colon-space differences remain versus frozen. No new clipping or missing content observed.'
    elif '~view' in name:
        finding='Fit photo, toolbar and right metadata column align; no new clipping, overlap or missing image observed.'
    elif '~zoom' in name:
        finding='250% photo crop, Fit/zoom controls and bottom-right minimap align. Frozen pixel residuals remain; whole-frame perfection is not claimed.'
    elif '~compare' in name:
        finding='Comparison split, center handle and image placement align. Inherited French retouch-label spacing differences remain.'
    else:
        finding='Preview Ask panel, response and narrowed photo/metadata layout readable. No matching frozen reference; no frozen fidelity acceptance.'
    visual.append({'state':name,'contactInspected':True,'fullResolutionAppInspected':True,'fullResolutionFrozenInspected':'design' in row['files'],'finding':finding,'newBlockingStaticRegression':False})
save('visual-review.json',{'disposition':'Scoped static preview pass; existing frozen residuals retained','application':'d20a012fbb774aa9b348fe1913f85d3476430098','pairSheetsInspected':3,'fullSizePairsInspected':8,'additionalUnpairedFullSizeApps':1,'uniqueFullResolutionImages':17,'rows':visual,'gaps':['file-image+ask-light has no frozen reference','Uploaded/selected Chat preview states were not captured by --only file-image,chat'],'nativeOrLiveAcceptance':False})
matches=[r for r in metrics['rows'] if r['frozen']]; maximum=max(matches,key=lambda r:r['frozen']['exactPct'])
save('summary.json',{'disposition':'Scoped static preview pass; no new blocking regression identified','applicationRevision':'d20a012fbb774aa9b348fe1913f85d3476430098','captureDirtyBase':'d390cce590600cf5896fa19acf0ddd44d7057e2c','rendererFingerprint':'087587293bfb7c2ccf85176cece73982ae75db48318e1c381270caa5196a0d73','rows':9,'compared':8,'explicitGaps':1,'routes':{'chat':2,'file-image':7},'suppliedPNGs':25,'suppliedPNGBytes':sum(r['bytes'] for r in load(OUT/'original-images.json')),'maximum':{'state':maximum['name'],**{k:maximum['frozen'][k] for k in ['thresholdPixels','exactPct','roundedPct']}},'meanExactPct':sum(r['frozen']['exactPct'] for r in matches)/8,'fullFramesRGBAExactToFrozen':0,'thresholdZeroFrames':0,'fullFramesRGBAExactToPrior':0,'imageContentRegionsRGBAExactToPrior':6,'contentRegion':[754,150,2880,1800],'sourceInputs':520,'rendererInputs':478,'gitInputsMatched':520,'buildMembers':90,'servedAssets':20,'frozenSourceFiles':106,'originalClock':load(OUT/'provenance.json')['clock'],'historicalClock':metrics['historicalProvenance']['clock'],'contacts':3,'fullSizePairs':8,'additionalUnpairedFullSizeApps':1,'newWebPs':retention['newWebPs'],'canonicalReuses':retention['canonicalReuses'],'newWebPBytes':sum(r['bytes'] for r in retention['images'] if r['storage']=='new-lossless-WebP'),'previousFailedAttemptCreditedCaptures':0,'limits':['French 1440x900 scale2 preview only','No uploaded/selected Chat-state captures','No new application tests or full-suite review','No CI/native/package/ASAR-byte admission','No full-product acceptance']})
helpers=[]
for name in ['pixels.mjs','audit.py','finish.py']:
    source=TMP/name; data=source.read_bytes(); dest=OUT/'raw'/f'{name}.gz'; dest.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(dest.read_bytes())==data
    helpers.append({'path':str(source),'sha256':sha(data),'archive':str(dest.relative_to(OUT)),'archiveSHA256':sha(dest.read_bytes())})
save('helpers.json',{'offlineExecuted':helpers,'dependencyEntries':metrics['dependencies'],'comparatorSHA256':load(OUT/'provenance.json')['comparatorSha256'],'comparatorExecutedByReviewer':False})
assert all(sha(Path(p).read_bytes())==h for p,h in pins.items())
assert (OUT/'report.json').read_bytes()==(BASE/'report.json').read_bytes() and (OUT/'provenance.json').read_bytes()==(BASE/'provenance.json').read_bytes()
for r in retention['images']:
    path=OUT/r['file']; assert sha(path.read_bytes())==r['sha256'] and path.stat().st_size==r['bytes']
    assert sha(im(path).tobytes())==r['rgbaSHA256']
for r in load(OUT/'raw-retention.json'):
    path=OUT/r['file']; assert sha(path.read_bytes())==r['sha256'] and sha(gzip.decompress(path.read_bytes()))==r['originalSHA256']
assert all(r['alphaExtrema']==[255,255] for r in load(OUT/'original-images.json'))
assert len((OUT/'README.md').read_text().splitlines())<=65
hashes={str(p.relative_to(OUT)):sha(p.read_bytes()) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ['SHA256SUMS','final-check.json']}
save('final-check.json',{'status':'passed','utc':datetime.now(timezone.utc).isoformat(),'readmeLines':len((OUT/'README.md').read_text().splitlines()),'stablePinnedInputs':len(pins),'originalReportProvenanceUnchanged':True,'retainedFullRGBAHashesVerified':17,'rawArchivesVerified':len(load(OUT/'raw-retention.json'))+len(helpers),'filesBeforeFinalReceipt':len(hashes)})
hashes['final-check.json']=sha((OUT/'final-check.json').read_bytes())
(OUT/'SHA256SUMS').write_text(''.join(f'{h}  {p}\n' for p,h in sorted(hashes.items())))
print(json.dumps({'summary':load(OUT/'summary.json'),'regions':regional,'final':load(OUT/'final-check.json')},indent=2))
