// Offline supplied-image arithmetic only; no browser/comparator/application execution.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const repo = process.cwd(), require = createRequire(path.join(repo, 'package.json'));
const {PNG} = require('pngjs'), pixelmatch = (await import(require.resolve('pixelmatch'))).default;
const base = '/tmp/opencode/files-live/compare-corrected', old = '/tmp/opencode/current-full-compare-6d96535';
const out = '/tmp/opencode/files-compare-audit', sha = b => createHash('sha256').update(b).digest('hex');
const json = p => JSON.parse(fs.readFileSync(p)), rows = json(path.join(base, 'report.json'));
const historical = json(path.join(old, 'report.json')), hp = json(path.join(old, 'provenance.json'));
assert.equal(sha(fs.readFileSync(path.join(old, 'report.json'))), hp.reportSha256);
function image(root, file) {
  const bytes = fs.readFileSync(path.join(root, file.file));
  assert.equal(sha(bytes), file.sha256); assert.equal(bytes.length, file.bytes);
  const im = PNG.sync.read(bytes, {checkCRC: true}); assert.equal(im.width, 2880); assert.equal(im.height, 1800); return im;
}
function raw(a, b, rect = [0, 0, 2880, 1800]) {
  let count = 0, x0 = rect[2], y0 = rect[3], x1 = 0, y1 = 0;
  for (let y = rect[1]; y < rect[3]; y++) for (let x = rect[0]; x < rect[2]; x++) {
    const i = (y * 2880 + x) * 4;
    if (a.data[i] === b.data[i] && a.data[i+1] === b.data[i+1] && a.data[i+2] === b.data[i+2] && a.data[i+3] === b.data[i+3]) continue;
    count++; x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x+1); y1 = Math.max(y1, y+1);
  }
  return {rawPixels: count, rgbaExact: count === 0, bounds: count ? [x0, y0, x1, y1] : null};
}
function compare(a, b, withDiff = false) {
  const diff = new PNG({width: 2880, height: 1800});
  const count = pixelmatch(a.data, b.data, diff.data, 2880, 1800, {threshold: 0.15});
  return {thresholdPixels: count, exactPct: 100 * count / 5184000, roundedPct: +(100 * count / 5184000).toFixed(2), ...raw(a,b), ...(withDiff ? {diff} : {})};
}
const regions = [['header', [0,0,2880,150]], ['sidebar', [0,150,754,1800]], ['content', [754,150,2880,1800]]];
const result = rows.map(row => {
  const app = image(base, row.files.app), prior = historical.find(r => r.name === row.name);
  assert(prior); assert.deepEqual(row.reference, prior.reference);
  const previous = image(old, prior.files.app), history = compare(app, previous);
  history.regions = regions.map(([name, rect]) => ({name, rect, ...raw(app,previous,rect)}));
  const current = {name: row.name, appRGBA: sha(app.data), history: {root: old, original: prior, ...history}, frozen: null};
  if (row.status) { assert.equal(row.status, 'no-design-shot'); return current; }
  const reference = image(base, row.files.design), recordedDiff = image(base,row.files.diff), computed = compare(app,reference,true);
  assert.equal(computed.roundedPct,row.diffPct); const bytes = PNG.sync.write(computed.diff);
  assert.equal(sha(bytes),row.files.diff.sha256); assert.equal(bytes.length,row.files.diff.bytes); assert(computed.diff.data.equals(recordedDiff.data));
  computed.regions = regions.map(([name,rect]) => {
    let n = 0; for(let y=rect[1];y<rect[3];y++) for(let x=rect[0];x<rect[2];x++) {
      const i=(y*2880+x)*4; if(computed.diff.data[i]===255 && computed.diff.data[i+1]===0 && computed.diff.data[i+2]===0) n++;
    }
    return {name,rect,thresholdPixels:n,...raw(app,reference,rect)};
  });
  assert.equal(computed.regions.reduce((n,r)=>n+r.thresholdPixels,0),computed.thresholdPixels);
  delete computed.diff; current.frozen = {...computed,referenceRGBA:sha(reference.data),diffBytesReproduced:true};
  const oldFrozen = compare(previous,reference); assert.equal(oldFrozen.roundedPct,prior.diffPct); current.history.frozen = oldFrozen;
  return current;
});
const dependencies = ['pngjs','pixelmatch'].map(name => ({name, entry: require.resolve(name), sha256:sha(fs.readFileSync(require.resolve(name)))}));
fs.writeFileSync(path.join(out,'metrics.json'),JSON.stringify({threshold:0.15,pixelsPerFrame:5184000,policy:'Original whole-frame metrics, no masking or translated comparison.',historicalProvenance:hp,historicalReportSHA256:hp.reportSha256,dependencies,rows:result},null,2)+'\n');
console.log(JSON.stringify(result.map(r=>({name:r.name,frozen:r.frozen && {pixels:r.frozen.thresholdPixels,raw:r.frozen.rawPixels,exactPct:r.frozen.exactPct,regions:r.frozen.regions},history:{thresholdPixels:r.history.thresholdPixels,rawPixels:r.history.rawPixels,regions:r.history.regions}})),null,2));
