"""Offline exact-Activity archive/source admission; no application or network execution."""
import collections
import datetime
import hashlib
import io
import json
from pathlib import Path
import posixpath
import runpy
import stat
import tarfile
import zipfile

HELPER = Path('/tmp/opencode/memory-package-audit/verify.py')
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == 'b20590f51922c9f2df1322c1803014ed9754346427ced4d1da25f0e2d536be0a'
h = runpy.run_path(str(HELPER), run_name='offline_helpers')
ROOT, sha, file_sha, git, blob, load, unique, read_asar, files_at, RENDER_PATHS, EXTRA_PATHS = (h[n] for n in ['ROOT', 'sha', 'file_sha', 'git', 'blob', 'load', 'unique', 'read_asar', 'files_at', 'RENDER_PATHS', 'EXTRA_PATHS'])
OUT = Path(__file__).parent
PACKAGE = Path('/tmp/opencode/activity-mac-package-9ba8e59')
FROZEN = Path('/tmp/opencode/build-work-activity')
ORIGINAL = ROOT / 'evidence/work-activity-followup/production'
APP = '9ba8e59fbec8c1f38f93ace25414d4a3489aede3'
PRIOR = '96df66ce727c42ddf647b2dcb4eeeff04fda4927'
DIRTY = '906987b94c04c3c4566ecb33394584ff0e93074e'
EXPECTED = {
    'artifact.zip': '775ddd8f7979fda1149a33474f3eaa4d22ce61e859ea87dc16a0b3bab85cc700',
    'Cortex.zip': 'd621a313d3a2b0beb1d17d27e8707943f4b5bdbb93c83df4f691f390612d6529',
    'app.asar': '22760335b8eef317c2c325cde1a7d4c09ecb888780226aaeb0e8ae4353a4bf26',
}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def tree(paths):
    return set(git('ls-tree', '-r', '--name-only', APP, '--', *paths).decode().splitlines())


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    prior_asar = Path('/tmp/opencode/memory-mac-package-96df66c/app.asar')
    prior_pins = Path('/tmp/opencode/build-memory-final/pinned-inputs.json')
    linux_asar = ROOT / 'dist/linux-unpacked/resources/app.asar'
    native, runbook = Path('/tmp/opencode/activity-native.mjs'), Path('/tmp/opencode/activity-native-runbook.md')
    watched = [*PACKAGE.iterdir(), *[FROZEN / n for n in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json', 'linux-package.json']],
        *[ORIGINAL / n for n in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json', 'linux-package.json']],
        prior_asar, prior_pins, linux_asar, native, runbook, HELPER, h['HELPER'], h['h']['HELPER'], Path(__file__),
        ROOT / 'vendor/cortex-sdk-0.3.5.tgz', ROOT / 'vendor/cortex-api-types-0.2.0.tgz']
    before = {str(p): file_sha(p) for p in watched}
    assert all(before[str(PACKAGE / n)] == digest for n, digest in EXPECTED.items())
    artifact, package = load(PACKAGE / 'artifact.json'), load(PACKAGE / 'package.json')
    assert artifact['workflow_run']['head_sha'] == package['applicationRevision'] == APP
    assert artifact['id'] == package['artifact'] == 11282756070 and artifact['workflow_run']['id'] == package['run'] == 37145831654
    assert artifact['size_in_bytes'] == (PACKAGE / 'artifact.zip').stat().st_size == 144694495
    assert artifact['digest'] == 'sha256:' + EXPECTED['artifact.zip']
    assert [package[k] for k in ['outerSHA256', 'innerSHA256', 'asarSHA256']] == list(EXPECTED.values())
    inner, asar = (PACKAGE / 'Cortex.zip').read_bytes(), (PACKAGE / 'app.asar').read_bytes()
    with zipfile.ZipFile(PACKAGE / 'artifact.zip') as archive:
        assert archive.namelist() == ['Cortex-0.2.0-arm64-mac.zip'] and archive.testzip() is None
        assert archive.read(archive.namelist()[0]) == inner
    entries, integrity = read_asar(asar)
    members = unique(package['members'])
    assert len(members) == 90 and set(entries) == set(members) | {'package.json'}
    for path in [PACKAGE / 'members.json', FROZEN / 'members.json']:
        receipt = load(path)
        assert receipt['revision'] == APP and unique(receipt['members']) == members
    assert {'packages/' + n: d for n, d in files_at(FROZEN / 'packages').items()} == members
    assert all(sha(entries[n]) == digest for n, digest in members.items())
    root_package = json.loads(entries['package.json'])
    assert root_package == {k: v for k, v in json.loads(blob(APP, 'package.json')).items() if k not in ['scripts', 'devDependencies']}
    resources = unique(package['resources'])
    with zipfile.ZipFile(io.BytesIO(inner)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)) and archive.testzip() is None
        assert all(n.startswith('Cortex.app/') and '..' not in n.split('/') and '\\' not in n for n in names)
        links = {i.filename: archive.read(i).decode() for i in archive.infolist() if stat.S_ISLNK(i.external_attr >> 16)}
        normalized = {n.rstrip('/') for n in names}
        resolved_links = []
        for name, target in links.items():
            assert name.startswith('Cortex.app/Contents/Frameworks/') and not target.startswith('/')
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(name), target))
            for _ in range(len(links) + 1):
                assert resolved.startswith('Cortex.app/Contents/Frameworks/')
                match = next((link for link in links if resolved == link or resolved.startswith(link + '/')), None)
                if match is None:
                    break
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(match), links[match]) + resolved[len(match):])
            else:
                raise AssertionError('ZIP link cycle')
            assert resolved in normalized
            resolved_links.append({'path': name, 'target': target, 'resolved': resolved})
        prefix = 'Cortex.app/Contents/Resources/'
        assert archive.read(prefix + 'app.asar') == asar and not any(n.startswith(prefix + 'app.asar.unpacked') for n in names)
        shipped = [n for n in names if n.startswith((prefix + 'locales/', prefix + 'skills/'))]
        assert all('/fixtures/' not in n and not n.endswith('.source.json') for n in shipped)
        assert {n[len(prefix):] for n in shipped if not n.endswith('/')} == set(resources) and len(resources) == 105
        for name, digest in resources.items():
            source = 'packages/i18n/' + name if name.startswith('locales/') else name
            assert sha(archive.read(prefix + name)) == digest == sha(blob(APP, source)), name
    catalogs = {n.removeprefix('packages/i18n/') for n in tree(['packages/i18n/locales']) if len(n.split('/')) == 5 and n.endswith('.json') and not n.endswith('.source.json')}
    assert set(resources) == catalogs | {'skills/summarize/SKILL.md'}
    locales = dict(sorted(collections.Counter(n.split('/')[1] for n in catalogs).items()))
    assert locales == {n: 13 for n in ['de', 'en', 'es', 'fr', 'ja', 'ko', 'pt-BR', 'zh-Hans']}
    pinned, renderer = load(FROZEN / 'pinned-inputs.json'), load(FROZEN / 'renderer-inputs.json')
    inputs, render_inputs = unique(pinned['inputs']), unique(renderer['files'])
    assert pinned['revision'] == renderer['revision'] == APP and not pinned['dirty'] and not renderer['dirty']
    assert len(inputs) == 517 and len(render_inputs) == renderer['sourceFileCount'] == 475
    assert set(inputs) == tree(RENDER_PATHS + EXTRA_PATHS) and set(render_inputs) == tree(RENDER_PATHS)
    assert all(sha(blob(APP, n)) == digest for n, digest in inputs.items())
    assert files_at(FROZEN / 'source') == inputs and all(inputs[n] == digest for n, digest in render_inputs.items())
    fingerprint = sha('\n'.join(f'{n}:{digest}' for n, digest in sorted(render_inputs.items())).encode())
    assert fingerprint == renderer['sourceFingerprint'] == 'a4a815bac24ce5f509f813d06371b8a754908b4b472c3d786f1325dbed53b8df'
    for filename in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json']:
        original, rebound = load(ORIGINAL / filename), load(FROZEN / filename)
        assert original['revision'] == DIRTY and original['dirty'] is True and rebound['revision'] == APP and rebound['dirty'] is False
        assert {k: v for k, v in original.items() if k not in ['revision', 'dirty']} == {k: v for k, v in rebound.items() if k not in ['revision', 'dirty']}
        assert (ORIGINAL / filename).read_bytes() == blob(APP, f'evidence/work-activity-followup/production/{filename}')
    previous = load(prior_pins); old_inputs = unique(previous['inputs'])
    assert previous['revision'] == PRIOR and set(inputs) == set(old_inputs) | {'packages/app/src/screens/work/activity.tsx'}
    assert all(sha(blob(PRIOR, n)) == digest for n, digest in old_inputs.items())
    changed = [n for n in sorted(inputs) if inputs[n] != old_inputs.get(n)]
    changed_rows = []
    for line in git('diff', '--no-ext-diff', '--numstat', PRIOR, APP, '--', *inputs).decode().splitlines():
        added, removed, n = line.split('\t')
        changed_rows.append({'path': n, 'added': int(added), 'removed': int(removed), 'beforeSHA256': old_inputs.get(n), 'afterSHA256': inputs[n]})
    assert [r['path'] for r in changed_rows] == changed and len(changed_rows) == 12
    runtime = [r for r in changed_rows if '/src/' in r['path']]
    assert [r['path'] for r in runtime] == ['packages/app/src/screens/work/' + n for n in ['activity.tsx', 'desk.tsx', 'home.tsx', 'work.css']]
    catalog_changes = [n for n in changed if n.startswith('packages/i18n/locales/')]
    assert len(catalog_changes) == 8
    added_keys = {}
    for n in catalog_changes:
        old_catalog, catalog = json.loads(blob(PRIOR, n)), json.loads(blob(APP, n))
        assert all(catalog[k] == v for k, v in old_catalog.items())
        added_keys[n] = sorted(set(catalog) - set(old_catalog)); assert len(added_keys[n]) == 7
    assert sum(map(len, added_keys.values())) == 56
    old_data = prior_asar.read_bytes()
    assert sha(old_data) == 'b55bda25290eaf90c821c9a79806d2aecdba5a1bb291da71f6b1abc251a16c44'
    old, _ = read_asar(old_data)
    assert entries['package.json'] == old['package.json']
    desktop = sorted(n for n in members if n.startswith('packages/desktop/dist/'))
    assert desktop == [f'packages/desktop/dist/{n}' for n in ['main.cjs', 'main.cjs.map', 'preload.cjs', 'preload.cjs.map']]
    assert all(entries[n] == old[n] for n in desktop)
    archives, archive_pins = {}, []
    for name, filename, version, expected in [('sdk', 'cortex-sdk-0.3.5.tgz', '0.3.5', '5c75f212a2669bcd6f5110fe6e5c8862e1ca6eba85a118b350e0ce38694596b8'), ('api-types', 'cortex-api-types-0.2.0.tgz', '0.2.0', '3e7359d204246a011706c1f3d6b959dbd2ad6b8512011acdc509316db8802877')]:
        path = 'vendor/' + filename; data = (ROOT / path).read_bytes()
        assert sha(data) == expected and data == blob(APP, path) == blob(PRIOR, path)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            files = [m for m in archive.getmembers() if m.isfile()]
            archives[name] = {m.name.removeprefix('package/'): archive.extractfile(m).read() for m in files}; assert len(archives[name]) == len(files)
        assert json.loads(archives[name]['package.json'])['version'] == version
        archive_pins.append({'path': path, 'sha256': expected})
    assert all(blob(APP, n) == blob(PRIOR, n) for n in ['bun.lock', 'packages/desktop/package.json'])
    maps = []
    for path in [n for n in desktop if n.endswith('.map')]:
        data = json.loads(entries[path]); assert len(data['sources']) == len(data['sourcesContent'])
        groups = {'workspace': [], 'sdk': 0, 'api-types': 0, 'synthetic': [], 'otherDependencies': 0}
        for source, content in zip(data['sources'], data['sourcesContent']):
            if source.startswith('<'):
                groups['synthetic'].append(source)
            elif '/node_modules/@cortex/sdk/' in source or '/node_modules/@cortex/api-types/' in source:
                name = 'sdk' if '/node_modules/@cortex/sdk/' in source else 'api-types'; member = source.split(f'/node_modules/@cortex/{name}/', 1)[1]
                assert content.encode() == archives[name][member]; groups[name] += 1
            elif 'node_modules/' not in source:
                member = posixpath.normpath(posixpath.join(posixpath.dirname(path), source)); assert content.encode() == blob(APP, member)
                groups['workspace'].append({'path': member, 'sha256': sha(content.encode())})
            else:
                groups['otherDependencies'] += 1
        maps.append({'path': path, 'sources': len(data['sources']), **groups})
    assert maps[0]['sources'] == 981 and len(maps[0]['workspace']) == 33 and maps[0]['sdk'] == maps[0]['api-types'] == 16
    assert maps[0]['otherDependencies'] == 915 and maps[0]['synthetic'] == ['<define:import.meta.env>'] and maps[1]['sources'] == len(maps[1]['workspace']) == 1
    index_path = next(n for n in entries if '/assets/index-' in n and n.endswith('.js')); index = entries[index_path]
    css_path = next(n for n in entries if n.endswith('.css')); css = entries[css_path]
    production = ['Minified React error #', 'bundleType:0,version:`19.3.0`,rendererPackageName:`react-dom`']
    development = ['act(...) is not supported', 'actQueue', '_debugStack', '__DEV__', 'You are calling ReactDOMClient.createRoot()']
    assert len(index) == 2483021 and all(m.encode() in index for m in production) and all(m.encode() not in index for m in development)
    assert file_sha(native) == '82b24a9417597ab6c9ba6f0754b36b1fa2ef7dc723118e03037e3cc642f04ac5'
    assert file_sha(runbook) == '0e9149fa54cac725b0e310c3d4f4db70a836cce1bc5990d7aa60afa21821b30c'
    assert inputs['packages/app/src/screens/work/activity.tsx'] == 'ac08eb0411325df215cce7bcb16dae8b47f562621fd7ea87b1b74d59dc09d904'
    assert inputs['packages/app/src/screens/work/home.tsx'] == 'b3d1f50d603e03bd3335f299c7f80f333a7d2dd66a34e625900baf9ec2a60079'
    assert inputs['packages/app/src/screens/work/work.css'] == 'b030e5979a31fb9d5cebc2a38d6922766d34cf693c1ab5c2fafb9efa4f0be5c3'
    en = json.loads(blob(APP, 'packages/i18n/locales/en/work.json'))
    labels = {k: en[k] for k in ['act.recentScope', 'act.recentEmptyTitle', 'act.recentEmptyText', 'act.completed', 'act.failed', 'act.type.all', 'act.type.errors', 'act.clear', 'act.export']}
    assert all(v in native.read_text() for v in labels.values())
    linux = load(FROZEN / 'linux-package.json')
    assert linux == load(ORIGINAL / 'linux-package.json') and linux['dirty'] is True and linux['production'] is True and linux['revision'] == DIRTY
    assert linux['asarSHA256'] == sha(asar) and linux['members'] == len(members) and linux['packageInputs'] == len(inputs) and linux['renderer'] == fingerprint
    assert linux_asar.read_bytes() == asar
    assert {'packages/' + n: d for n, d in files_at(FROZEN / 'packages').items()} == members and files_at(FROZEN / 'source') == inputs
    assert {str(p): file_sha(p) for p in watched} == before
    save('integrity.json', {'beforeSHA256': before, 'afterAllEqual': True, 'asarFiles': integrity, 'resources': resources, 'zipLinks': resolved_links})
    save('source-hashes.json', {'maps': maps, 'archives': archive_pins, 'rootPackageMetadata': root_package, 'rendererPaths': RENDER_PATHS, 'additionalPackagePaths': EXTRA_PATHS, 'changedInputs': changed_rows, 'addedCatalogKeys': added_keys, 'nativeLabels': labels})
    summary = {'status': 'approved', 'scope': 'Offline exact-Activity package/source admission for installation; native verification remains separate',
        'applicationRevision': APP, 'baselineApplication': PRIOR, 'workflowRunID': artifact['workflow_run']['id'], 'artifactID': artifact['id'],
        'outerBytes': artifact['size_in_bytes'], 'archiveSHA256': EXPECTED, 'outerCRC': 'passed', 'innerCRC': 'passed', 'innerZipEntries': len(names), 'safeFrameworkSymlinks': len(links),
        'asarFiles': len(entries), 'verifiedIntegrityBlocks': sum(r['verifiedBlocks'] for r in integrity), 'asarContiguousPayload': True, 'asarLinks': 0, 'asarUnpackedEntries': 0,
        'buildMembers': len(members), 'completeBuildMemberSetMatches': True, 'rootPackageMatchesGit': True, 'rootPackageIdenticalToBaseline': True,
        'catalogs': len(catalogs), 'localeCounts': locales, 'skills': 1, 'extraLocaleOrSkillFiles': 0, 'resourceFixturesOrSourceStamps': 0,
        'packageInputsMatchingGit': len(inputs), 'frozenSourceFilesMatchingGit': len(inputs), 'packageInputPathSetIndependentlyEnumerated': True, 'rendererInputs': len(render_inputs),
        'rendererFingerprintAlgorithm': 'sha256(LF-joined sorted path:sha256, no trailing LF)', 'rendererFingerprint': fingerprint, 'changedInputs': changed_rows,
        'newPackageInput': 'packages/app/src/screens/work/activity.tsx', 'runtimeSourceFilesChanged': len(runtime), 'runtimeLineDelta': {k: sum(r[k] for r in runtime) for k in ['added', 'removed']},
        'catalogFilesChanged': 8, 'catalogKeysAdded': 56, 'existingCatalogValuesUnchanged': True, 'desktopMembersIdenticalToBaseline': {n: sha(entries[n]) for n in desktop},
        'mainWorkspaceSourcesMatchingGit': 33, 'preloadWorkspaceSourcesMatchingGit': 1, 'sdkSources': 16, 'apiTypesSources': 16, 'otherEmbeddedDependencySourcesUnchanged': 915, 'dependencyPinsUnchanged': True,
        'productionRenderer': {'path': index_path, 'bytes': len(index), 'sha256': sha(index), 'presentMarkers': production, 'absentDevelopmentMarkers': development},
        'compiledCSS': {'path': css_path, 'bytes': len(css), 'sha256': sha(css)},
        'nativePreparation': {'driverSHA256': file_sha(native), 'runbookSHA256': file_sha(runbook), 'sourceReadbackMatchesApprovedRevision': True, 'nineEnglishLabelsMatch': True, 'scope': 'Previously approved preparation now has its matching admitted package; no collector execution'},
        'linuxAsarBytesIdentical': True, 'originalDirtyReceiptsPreserved': True, 'originalDirtyBase': DIRTY, 'inputArtifactsStableBeforeAfter': True,
        'executedBuilds': 0, 'executedApplicationTests': 0, 'nativeExecution': False, 'networkRequests': 0,
        'startedUTC': started, 'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'verifier': {'path': str(Path(__file__)), 'sha256': file_sha(Path(__file__)), 'helperSHA256': file_sha(HELPER)},
        'detailReceipts': {n: file_sha(OUT / n) for n in ['integrity.json', 'source-hashes.json']}}
    save('summary.json', summary); print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
