"""Offline archive/Git provenance audit; no app launch or test execution."""
import collections
import datetime
import hashlib
import io
import json
from pathlib import Path
import posixpath
import struct
import subprocess
import tarfile
import zipfile

ROOT = Path('/root/.local/share/opencode/worktree/b489da9add1907e124bad2dfd49e8423fbd978b1/goal-desktop-rewrite')
OUT = Path(__file__).parent
PACKAGE = Path('/tmp/opencode/mac-37c22c2')
FROZEN = Path('/tmp/opencode/build-provider-draft-final')
OLD_FREEZE = Path('/tmp/opencode/build-terminal-state-final')
APP = '37c22c2fcff92fb76b10ffc97ec0643ac325d62f'
PRIOR = '2956564fbe31f882014d74ff3a7f920e839fd634'
F5 = 'f5bf305473db12fddfddcda890a01794f02f578f'
SETTINGS = 'packages/app/src/screens/system/settings.tsx'
EXPECTED = {
    'artifact.zip': '401e565fc214b2958e7115e82dd28beef7abe08c2635ce440c5664c87482ed69',
    'Cortex.zip': '216d6a52fe0ed3b3c3b2beddcfb75262f23ef8fdcdc9ec452a74f0d07c999395',
    'app.asar': 'd1e6987ac728723b5c9b1132aa532fc63c3db55d863c9b264c48fdc631eea1f7',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-pager', *args], cwd=ROOT)


def blob(revision, path):
    return git('show', f'{revision}:{path}')


def load(path):
    return json.loads(Path(path).read_bytes())


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')


def unique(rows):
    result = {r['path']: r['sha256'] for r in rows}
    assert len(result) == len(rows), 'Duplicate receipt path'
    return result


def read_asar(data):
    size_pickle, header_size, payload_size, json_size = struct.unpack('<4I', data[:16])
    assert size_pickle == 4 and payload_size + 4 == header_size
    assert json_size <= payload_size - 4
    header = json.loads(data[16:16 + json_size])
    start = 8 + header_size
    entries, rows, ranges = {}, [], []

    def visit(tree, prefix=''):
        for name, entry in tree.items():
            assert name not in ['', '.', '..'] and '/' not in name
            path = prefix + name
            if 'files' in entry:
                visit(entry['files'], path + '/')
                continue
            assert path not in entries and 'link' not in entry and not entry.get('unpacked')
            offset, size = int(entry['offset']), entry['size']
            assert offset >= 0 and size >= 0
            content = data[start + offset:start + offset + size]
            assert len(content) == size
            integrity = entry['integrity']
            assert integrity['algorithm'] == 'SHA256' and integrity['blockSize'] > 0
            digest, block = sha(content), integrity['blockSize']
            assert digest == integrity['hash'], path
            blocks = [sha(content[i:i + block]) for i in range(0, size, block)]
            assert blocks == integrity['blocks'], path
            entries[path] = content
            ranges.append((offset, size))
            rows.append({'path': path, 'bytes': size, 'sha256': digest, 'blockSize': block, 'verifiedBlocks': len(blocks)})

    visit(header['files'])
    position = 0
    for offset, size in sorted(ranges):
        assert offset == position, 'ASAR payload gap or overlap'
        position += size
    assert start + position == len(data), 'Trailing/unindexed ASAR payload'
    return entries, sorted(rows, key=lambda r: r['path'])


def frozen_members():
    return {p.relative_to(FROZEN).as_posix(): file_sha(p) for p in (FROZEN / 'packages').rglob('*') if p.is_file()}


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    linux_asar = ROOT / 'dist/linux-unpacked/resources/app.asar'
    watched = [PACKAGE / name for name in [*EXPECTED, 'artifact.json', 'package.json', 'members.json']]
    watched += [FROZEN / name for name in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json', 'linux-package.json']]
    watched += [OLD_FREEZE / 'pinned-inputs.json', Path(__file__), linux_asar]
    watched += [ROOT / 'vendor' / name for name in ['cortex-sdk-0.3.5.tgz', 'cortex-api-types-0.2.0.tgz']]
    watched += [Path(f'/tmp/opencode/mac-{short}/app.asar') for short in ['2956564', 'f5bf305']]
    watched += [ROOT / f'evidence/mac/{short}/package.json' for short in ['2956564', 'f5bf305']]
    watched += [ROOT / 'evidence/mac/f5bf305/renderer-inputs.json']
    before = {str(p): file_sha(p) for p in watched}
    assert all(before[str(PACKAGE / name)] == digest for name, digest in EXPECTED.items())
    artifact, package = load(PACKAGE / 'artifact.json'), load(PACKAGE / 'package.json')
    assert artifact['workflow_run']['head_sha'] == package['applicationRevision'] == APP
    assert artifact['id'] == package['artifact'] == 11272761294
    assert artifact['workflow_run']['id'] == package['run'] == 37118586276
    assert artifact['size_in_bytes'] == (PACKAGE / 'artifact.zip').stat().st_size == 144676511
    assert artifact['digest'] == 'sha256:' + EXPECTED['artifact.zip']
    assert [package[n] for n in ['outerSHA256', 'innerSHA256', 'asarSHA256']] == list(EXPECTED.values())
    inner, asar = (PACKAGE / 'Cortex.zip').read_bytes(), (PACKAGE / 'app.asar').read_bytes()
    with zipfile.ZipFile(PACKAGE / 'artifact.zip') as archive:
        assert archive.namelist() == ['Cortex-0.2.0-arm64-mac.zip']
        assert archive.read(archive.namelist()[0]) == inner
    entries, integrity = read_asar(asar)
    members = unique(package['members'])
    assert len(members) == 90 and set(entries) == set(members) | {'package.json'}
    for path in [PACKAGE / 'members.json', FROZEN / 'members.json']:
        receipt = load(path)
        assert receipt['revision'] == APP and unique(receipt['members']) == members
    assert frozen_members() == members
    assert all(sha(entries[name]) == expected for name, expected in members.items())
    root_package = json.loads(entries['package.json'])
    source_package = json.loads(blob(APP, 'package.json'))
    assert root_package == {k: v for k, v in source_package.items() if k not in ['scripts', 'devDependencies']}

    resources = unique(package['resources'])
    with zipfile.ZipFile(io.BytesIO(inner)) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert all(not n.startswith('/') and '..' not in n.split('/') for n in names)
        assert archive.testzip() is None
        prefix = 'Cortex.app/Contents/Resources/'
        assert archive.read(prefix + 'app.asar') == asar
        shipped = [n for n in names if n.startswith((prefix + 'locales/', prefix + 'skills/'))]
        assert all('/fixtures/' not in n and not n.endswith('.source.json') for n in shipped)
        files = [n[len(prefix):] for n in shipped if not n.endswith('/')]
        assert len(files) == len(set(files)) == len(resources) == 105 and set(files) == set(resources)
        for name, expected in resources.items():
            source = 'packages/i18n/' + name if name.startswith('locales/') else name
            assert sha(archive.read(prefix + name)) == expected == sha(blob(APP, source)), name
    catalog_paths = git('ls-tree', '-r', '--name-only', APP, '--', 'packages/i18n/locales').decode().splitlines()
    catalogs = {n.removeprefix('packages/i18n/') for n in catalog_paths if len(n.split('/')) == 5 and n.endswith('.json') and not n.endswith('.source.json')}
    assert set(resources) == catalogs | {'skills/summarize/SKILL.md'}
    locales = dict(sorted(collections.Counter(n.split('/')[1] for n in catalogs).items()))
    assert locales == {n: 13 for n in ['de', 'en', 'es', 'fr', 'ja', 'ko', 'pt-BR', 'zh-Hans']}

    pinned, renderer = load(FROZEN / 'pinned-inputs.json'), load(FROZEN / 'renderer-inputs.json')
    assert pinned['revision'] == renderer['revision'] == APP
    inputs, render_inputs = unique(pinned['inputs']), unique(renderer['files'])
    assert len(inputs) == 514 and len(render_inputs) == renderer['sourceFileCount'] == 473
    assert all(sha(blob(APP, path)) == digest for path, digest in inputs.items())
    assert all(inputs[path] == digest for path, digest in render_inputs.items())
    render_paths = load(ROOT / 'evidence/mac/f5bf305/renderer-inputs.json')['paths']
    assert set(git('ls-tree', '-r', '--name-only', APP, '--', *render_paths).decode().splitlines()) == set(render_inputs)
    fingerprint = sha('\n'.join(f'{path}:{digest}' for path, digest in sorted(render_inputs.items())).encode())
    assert fingerprint == renderer['sourceFingerprint'] == '5538c5298dbad432d82cf18781b9f7e62b5a861311ad61c6fc518c0cdb6e1ae7'
    previous = load(OLD_FREEZE / 'pinned-inputs.json')
    old_inputs = unique(previous['inputs'])
    assert previous['revision'] == PRIOR and old_inputs.keys() == inputs.keys()
    assert all(sha(blob(PRIOR, path)) == digest for path, digest in old_inputs.items())
    changed = [path for path in sorted(inputs) if inputs[path] != old_inputs[path]]
    assert changed == [SETTINGS]
    assert git('diff', '--no-ext-diff', '--name-only', PRIOR, APP, '--', *inputs).decode().splitlines() == changed
    assert git('diff', '--no-ext-diff', '--numstat', PRIOR, APP, '--', SETTINGS).decode().strip() == f'3\t3\t{SETTINGS}'
    delta = git('diff', '--no-ext-diff', '--unified=3', PRIOR, APP, '--', SETTINGS)
    assert inputs[SETTINGS].startswith('b859cf')

    desktop = {n for n in members if n.startswith('packages/desktop/dist/')}
    assert desktop == {f'packages/desktop/dist/{n}' for n in ['main.cjs', 'main.cjs.map', 'preload.cjs', 'preload.cjs.map']}
    previous_packages = {}
    for short in ['2956564', 'f5bf305']:
        data = Path(f'/tmp/opencode/mac-{short}/app.asar').read_bytes()
        assert sha(data) == load(ROOT / f'evidence/mac/{short}/package.json')['asarSHA256']
        old_entries, _ = read_asar(data)
        assert entries['package.json'] == old_entries['package.json']
        assert all(entries[name] == old_entries[name] for name in desktop)
        previous_packages[short] = {'asarSHA256': sha(data), 'desktopMembersIdentical': 4, 'rootPackageIdentical': True}

    archives, archive_pins = {}, []
    for name, filename, version, expected in [
        ('sdk', 'cortex-sdk-0.3.5.tgz', '0.3.5', '5c75f212a2669bcd6f5110fe6e5c8862e1ca6eba85a118b350e0ce38694596b8'),
        ('api-types', 'cortex-api-types-0.2.0.tgz', '0.2.0', '3e7359d204246a011706c1f3d6b959dbd2ad6b8512011acdc509316db8802877'),
    ]:
        path = 'vendor/' + filename
        data = (ROOT / path).read_bytes()
        assert sha(data) == expected and data == blob(APP, path) == blob(PRIOR, path) == blob(F5, path)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            files = [m for m in archive.getmembers() if m.isfile()]
            archives[name] = {m.name.removeprefix('package/'): archive.extractfile(m).read() for m in files}
            assert len(archives[name]) == len(files)
        assert json.loads(archives[name]['package.json'])['version'] == version
        archive_pins.append({'path': path, 'version': version, 'sha256': expected})
    for path in ['bun.lock', 'packages/desktop/package.json']:
        assert blob(APP, path) == blob(PRIOR, path) == blob(F5, path)
    maps = []
    for path in sorted(n for n in desktop if n.endswith('.map')):
        data = json.loads(entries[path])
        assert len(data['sources']) == len(data['sourcesContent'])
        groups = {'workspace': [], 'sdk': [], 'api-types': [], 'synthetic': [], 'otherDependencies': 0}
        for source, content in zip(data['sources'], data['sourcesContent']):
            if source.startswith('<'):
                groups['synthetic'].append(source)
            elif '/node_modules/@cortex/sdk/' in source or '/node_modules/@cortex/api-types/' in source:
                name = 'sdk' if '/node_modules/@cortex/sdk/' in source else 'api-types'
                member = source.split(f'/node_modules/@cortex/{name}/', 1)[1]
                assert content.encode() == archives[name][member]
                groups[name].append({'path': member, 'sha256': sha(content.encode())})
            elif 'node_modules/' not in source:
                member = posixpath.normpath(posixpath.join(posixpath.dirname(path), source))
                assert content.encode() == blob(APP, member) == blob(PRIOR, member) == blob(F5, member)
                groups['workspace'].append({'path': member, 'sha256': sha(content.encode())})
            else:
                groups['otherDependencies'] += 1
        maps.append({'path': path, 'sources': len(data['sources']), **groups})
    assert maps[0]['sources'] == 980 and len(maps[0]['workspace']) == 32
    assert len(maps[0]['sdk']) == len(maps[0]['api-types']) == 16
    assert maps[0]['synthetic'] == ['<define:import.meta.env>'] and maps[0]['otherDependencies'] == 915
    assert maps[1]['sources'] == len(maps[1]['workspace']) == 1
    linux = load(FROZEN / 'linux-package.json')
    assert linux['revision'] == APP and linux['asarSHA256'] == sha(asar)
    assert unique(linux['members']) == members and unique(linux['resources']) == resources
    assert linux_asar.read_bytes() == asar
    assert frozen_members() == members and {str(p): file_sha(p) for p in watched} == before

    (OUT / 'settings.diff').write_bytes(delta)
    save('summary.json', {'status': 'passed', 'scope': 'Offline package/source provenance only; no installed/native execution',
        'application': APP, 'prior': PRIOR, 'artifactID': 11272761294, 'workflowRunID': 37118586276,
        'outerBytes': 144676511, 'archiveSHA256': EXPECTED, 'asarFiles': len(entries), 'buildMembers': len(members),
        'verifiedFileIntegrity': len(integrity), 'verifiedBlocks': sum(r['verifiedBlocks'] for r in integrity),
        'catalogs': len(catalogs), 'localeCounts': locales, 'skills': 1, 'packageInputs': len(inputs),
        'rendererInputs': len(render_inputs), 'rendererFingerprint': fingerprint, 'changedInputs': changed,
        'settingsSHA256': inputs[SETTINGS], 'settingsLineDelta': {'added': 3, 'removed': 3},
        'desktopMembersIdenticalTo2956564AndF5': 4, 'mainWorkspaceSources': 32, 'preloadWorkspaceSources': 1,
        'sdkSources': 16, 'apiTypesSources': 16, 'linuxAsarBytesIdentical': True,
        'inputArtifactsStableBeforeAfter': True, 'started': started, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    save('source-hashes.json', {'maps': maps, 'archives': archive_pins, 'previousPackages': previous_packages,
        'rootPackageMetadata': root_package, 'rootPackageSHA256': sha(entries['package.json']),
        'changedInputs': [{'path': SETTINGS, 'beforeSHA256': old_inputs[SETTINGS], 'afterSHA256': inputs[SETTINGS]}],
        'settingsDiffSHA256': sha(delta)})
    save('integrity.json', {'beforeSHA256': before, 'afterAllEqual': True, 'asarFiles': integrity,
        'resources': resources, 'verifierSHA256': file_sha(Path(__file__))})
    print(json.dumps(load(OUT / 'summary.json'), indent=2))


if __name__ == '__main__':
    main()
