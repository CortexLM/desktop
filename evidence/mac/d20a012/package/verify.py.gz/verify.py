"""Offline Files archive/source admission; reuses hash-pinned historical data readers."""
import collections
import datetime
import io
import json
from pathlib import Path
import posixpath
import runpy
import stat
import struct
import tarfile
import zipfile
import hashlib

HELPER = Path('/tmp/opencode/activity-package-audit/verify.py')
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '9aa591f51cee8ce77fc52c5053d0076d5f75846bf4026aa0ff71e23021e4cfb4'
h = runpy.run_path(str(HELPER), run_name='offline_helpers')
ROOT, sha, file_sha, git, blob, load, unique, read_asar, files_at, RENDER_PATHS, EXTRA_PATHS = (h[n] for n in ['ROOT', 'sha', 'file_sha', 'git', 'blob', 'load', 'unique', 'read_asar', 'files_at', 'RENDER_PATHS', 'EXTRA_PATHS'])
OUT = Path(__file__).parent
PACKAGE = Path('/tmp/opencode/files-mac-package-d20a012')
FROZEN = Path('/tmp/opencode/build-files-corrected')
ORIGINAL = ROOT / 'evidence/files-live-followup/production'
APP, PRIOR, DIRTY = 'd20a012fbb774aa9b348fe1913f85d3476430098', '9ba8e59fbec8c1f38f93ace25414d4a3489aede3', 'd390cce590600cf5896fa19acf0ddd44d7057e2c'
EXPECTED = {'artifact.zip': 'bca22424621e7fd49f6490ab606257efb6ca84c9203892021b2dc39140a8a58b', 'Cortex.zip': '90f74a9796f1c1753885d0c0679ab2aa35130d826485c529794f45c3701f2429', 'app.asar': '9eeffe464327d09642b8f7ac27facbbf7d54f3c776d3d507e19083b92c11c893'}
def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
def tree(revision, paths):
    return set(git('ls-tree', '-r', '--name-only', revision, '--', *paths).decode().splitlines())

def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    previous = Path('/tmp/opencode/activity-mac-package-9ba8e59')
    prior_pins = Path('/tmp/opencode/build-work-activity/pinned-inputs.json')
    linux_asar = ROOT / 'dist/linux-unpacked/resources/app.asar'
    helpers = [HELPER, h['HELPER'], h['h']['HELPER'], h['h']['h']['HELPER']]
    watched = [*PACKAGE.iterdir(), *[FROZEN / n for n in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json', 'linux-package.json']],
        *[ORIGINAL / n for n in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json', 'linux-package.json', 'application-pin.json', 'source-delta.json']],
        previous / 'app.asar', previous / 'Cortex.zip', prior_pins, linux_asar, *helpers, Path(__file__), ROOT / 'vendor/cortex-sdk-0.3.5.tgz', ROOT / 'vendor/cortex-api-types-0.2.0.tgz']
    before = {str(p): file_sha(p) for p in watched}
    assert all(before[str(PACKAGE / n)] == digest for n, digest in EXPECTED.items())
    artifact, package = load(PACKAGE / 'artifact.json'), load(PACKAGE / 'package.json')
    assert artifact['workflow_run']['head_sha'] == package['applicationRevision'] == APP
    assert artifact['id'] == package['artifact'] == 11284474514 and artifact['workflow_run']['id'] == package['run'] == 37153526225
    assert artifact['size_in_bytes'] == (PACKAGE / 'artifact.zip').stat().st_size == 144707245
    assert artifact['digest'] == 'sha256:' + EXPECTED['artifact.zip']
    assert [package[k] for k in ['outerSHA256', 'innerSHA256', 'asarSHA256']] == list(EXPECTED.values())
    inner, asar = (PACKAGE / 'Cortex.zip').read_bytes(), (PACKAGE / 'app.asar').read_bytes()
    with zipfile.ZipFile(PACKAGE / 'artifact.zip') as archive:
        assert archive.namelist() == ['Cortex-0.2.0-arm64-mac.zip'] and archive.testzip() is None
        assert archive.read(archive.namelist()[0]) == inner
    entries, integrity = read_asar(asar)
    members, resources = unique(package['members']), unique(package['resources'])
    assert len(members) == 90 and set(entries) == set(members) | {'package.json'}
    for path in [PACKAGE / 'members.json', FROZEN / 'members.json']:
        receipt = load(path); assert receipt['revision'] == APP and unique(receipt['members']) == members
    assert {'packages/' + n: d for n, d in files_at(FROZEN / 'packages').items()} == members
    assert all(sha(entries[n]) == digest for n, digest in members.items())
    root_package = json.loads(entries['package.json'])
    assert root_package == {k: v for k, v in json.loads(blob(APP, 'package.json')).items() if k not in ['scripts', 'devDependencies']}
    zip_files, native_binaries, resolved_links = [], [], []
    with zipfile.ZipFile(io.BytesIO(inner)) as archive:
        names = archive.namelist(); normalized = {n.rstrip('/') for n in names}
        assert len(names) == len(set(names)) == len(normalized) and archive.testzip() is None
        assert all(n.startswith('Cortex.app/') and '\\' not in n and posixpath.normpath(n) == n.rstrip('/') for n in names)
        links = {i.filename: archive.read(i).decode() for i in archive.infolist() if stat.S_ISLNK(i.external_attr >> 16)}
        for name, target in links.items():
            assert name.startswith('Cortex.app/Contents/Frameworks/') and not target.startswith('/') and '\\' not in target
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(name), target))
            for _ in range(len(links) + 1):
                assert resolved.startswith('Cortex.app/Contents/Frameworks/')
                match = next((link for link in links if resolved == link or resolved.startswith(link + '/')), None)
                if match is None: break
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(match), links[match]) + resolved[len(match):])
            else: raise AssertionError('ZIP link cycle')
            assert resolved in normalized and not any(n.startswith(name + '/') for n in names)
            resolved_links.append({'path': name, 'target': target, 'resolved': resolved})
        for info in archive.infolist():
            mode = info.external_attr >> 16
            assert stat.S_ISREG(mode) or stat.S_ISDIR(mode) or stat.S_ISLNK(mode)
            if stat.S_ISREG(mode):
                data = archive.read(info); zip_files.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data), 'mode': oct(mode)})
                if data[:4] == b'\xcf\xfa\xed\xfe':
                    cpu = struct.unpack_from('<I', data, 4)[0]; assert cpu == 0x100000c
                    native_binaries.append({**zip_files[-1], 'architecture': 'arm64'})
                else: assert data[:4] not in [b'\xfe\xed\xfa\xce', b'\xfe\xed\xfa\xcf', b'\xce\xfa\xed\xfe', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca']
        prefix = 'Cortex.app/Contents/Resources/'
        assert archive.read(prefix + 'app.asar') == asar and not any(n.startswith(prefix + 'app.asar.unpacked') for n in names)
        shipped = [n for n in names if n.startswith((prefix + 'locales/', prefix + 'skills/'))]
        assert all('/fixtures/' not in n and not n.endswith('.source.json') for n in shipped)
        assert {n[len(prefix):] for n in shipped if not n.endswith('/')} == set(resources) and len(resources) == 105
        for name, digest in resources.items():
            source = 'packages/i18n/' + name if name.startswith('locales/') else name
            assert sha(archive.read(prefix + name)) == digest == sha(blob(APP, source))
    catalogs = {n.removeprefix('packages/i18n/') for n in tree(APP, ['packages/i18n/locales']) if len(n.split('/')) == 5 and n.endswith('.json') and not n.endswith('.source.json')}
    assert set(resources) == catalogs | {'skills/summarize/SKILL.md'}
    locales = dict(sorted(collections.Counter(n.split('/')[1] for n in catalogs).items()))
    assert locales == {n: 13 for n in ['de', 'en', 'es', 'fr', 'ja', 'ko', 'pt-BR', 'zh-Hans']}
    pinned, renderer = load(FROZEN / 'pinned-inputs.json'), load(FROZEN / 'renderer-inputs.json')
    inputs, render_inputs = unique(pinned['inputs']), unique(renderer['files'])
    assert pinned['revision'] == renderer['revision'] == APP and not pinned['dirty'] and not renderer['dirty']
    assert len(inputs) == 520 and len(render_inputs) == renderer['sourceFileCount'] == 478
    assert set(inputs) == tree(APP, RENDER_PATHS + EXTRA_PATHS) and set(render_inputs) == tree(APP, RENDER_PATHS)
    assert all(sha(blob(APP, n)) == digest for n, digest in inputs.items()) and files_at(FROZEN / 'source') == inputs
    assert all(inputs[n] == digest for n, digest in render_inputs.items())
    fingerprint = sha('\n'.join(f'{n}:{digest}' for n, digest in sorted(render_inputs.items())).encode())
    assert fingerprint == renderer['sourceFingerprint'] == '087587293bfb7c2ccf85176cece73982ae75db48318e1c381270caa5196a0d73'
    for filename in ['members.json', 'pinned-inputs.json', 'renderer-inputs.json']:
        original, rebound = load(ORIGINAL / filename), load(FROZEN / filename)
        assert original['revision'] == DIRTY and original['dirty'] is True and rebound['revision'] == APP and rebound['dirty'] is False
        assert {k: v for k, v in original.items() if k not in ['revision', 'dirty']} == {k: v for k, v in rebound.items() if k not in ['revision', 'dirty']}
        assert (ORIGINAL / filename).read_bytes() == blob(APP, f'evidence/files-live-followup/production/{filename}')
    old_pins = load(prior_pins); old_inputs = unique(old_pins['inputs'])
    assert old_pins['revision'] == PRIOR and set(old_inputs) == tree(PRIOR, RENDER_PATHS + EXTRA_PATHS)
    assert all(sha(blob(PRIOR, n)) == digest for n, digest in old_inputs.items())
    changed = [n for n in sorted(inputs) if inputs[n] != old_inputs.get(n)]
    delta, pin = load(ORIGINAL / 'source-delta.json'), load(ORIGINAL / 'application-pin.json')
    assert delta['applicationRevision'] == pin['applicationRevision'] == APP and delta['previousApplication'] == PRIOR
    assert delta['changedPackageInputs'] == changed and len(changed) == 17
    assert sorted(set(inputs) - set(old_inputs)) == delta['newInputs'] and not set(old_inputs) - set(inputs)
    source_changes = [n for n in changed if n.startswith('packages/app/src/')]
    assert source_changes == ['packages/app/src/screens/' + n for n in ['chat/chat.css', 'chat/live-chat.tsx', 'chat/model-composer.tsx', 'files/files.css', 'files/image.tsx', 'files/index.tsx', 'files/media.tsx', 'files/raster.test.ts', 'files/raster.ts']]
    changed_rows = []
    for line in git('diff', '--no-ext-diff', '--numstat', PRIOR, APP, '--', *inputs).decode().splitlines():
        added, removed, n = line.split('\t'); changed_rows.append({'path': n, 'added': int(added), 'removed': int(removed), 'beforeSHA256': old_inputs.get(n), 'afterSHA256': inputs[n]})
    assert [r['path'] for r in changed_rows] == changed
    added_keys = {}
    for n in [n for n in changed if n not in source_changes]:
        assert n.startswith('packages/i18n/locales/') and n.endswith('/files.json')
        old_catalog, catalog = json.loads(blob(PRIOR, n)), json.loads(blob(APP, n))
        assert all(catalog[k] == v for k, v in old_catalog.items())
        added_keys[n] = sorted(set(catalog) - set(old_catalog)); assert len(added_keys[n]) == 19
    assert len(added_keys) == 8 and len({tuple(v) for v in added_keys.values()}) == 1
    old_asar = (previous / 'app.asar').read_bytes()
    assert sha(old_asar) == '22760335b8eef317c2c325cde1a7d4c09ecb888780226aaeb0e8ae4353a4bf26'
    old, _ = read_asar(old_asar); assert entries['package.json'] == old['package.json']
    desktop = sorted(n for n in members if n.startswith('packages/desktop/dist/'))
    assert desktop == ['packages/desktop/dist/' + n for n in ['main.cjs', 'main.cjs.map', 'preload.cjs', 'preload.cjs.map']]
    assert all(entries[n] == old[n] for n in desktop) and delta['desktopMembersUnchanged'] is True
    assert file_sha(previous / 'Cortex.zip') == 'd621a313d3a2b0beb1d17d27e8707943f4b5bdbb93c83df4f691f390612d6529'
    with zipfile.ZipFile(previous / 'Cortex.zip') as archive:
        for row in native_binaries: assert sha(archive.read(row['path'])) == row['sha256']
    archives, archive_pins = {}, []
    for name, filename, version, expected in [('sdk', 'cortex-sdk-0.3.5.tgz', '0.3.5', '5c75f212a2669bcd6f5110fe6e5c8862e1ca6eba85a118b350e0ce38694596b8'), ('api-types', 'cortex-api-types-0.2.0.tgz', '0.2.0', '3e7359d204246a011706c1f3d6b959dbd2ad6b8512011acdc509316db8802877')]:
        path = 'vendor/' + filename; data = (ROOT / path).read_bytes(); assert sha(data) == expected and data == blob(APP, path) == blob(PRIOR, path)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            files = [m for m in archive.getmembers() if m.isfile()]; archives[name] = {m.name.removeprefix('package/'): archive.extractfile(m).read() for m in files}; assert len(archives[name]) == len(files)
        assert json.loads(archives[name]['package.json'])['version'] == version; archive_pins.append({'path': path, 'sha256': expected})
    maps = []
    for path in [n for n in desktop if n.endswith('.map')]:
        data = json.loads(entries[path]); assert len(data['sources']) == len(data['sourcesContent'])
        groups = {'workspace': [], 'sdk': 0, 'api-types': 0, 'synthetic': [], 'otherDependencies': 0}
        for source, content in zip(data['sources'], data['sourcesContent']):
            if source.startswith('<'): groups['synthetic'].append(source)
            elif '/node_modules/@cortex/sdk/' in source or '/node_modules/@cortex/api-types/' in source:
                name = 'sdk' if '/node_modules/@cortex/sdk/' in source else 'api-types'; member = source.split(f'/node_modules/@cortex/{name}/', 1)[1]
                assert content.encode() == archives[name][member]; groups[name] += 1
            elif 'node_modules/' not in source:
                member = posixpath.normpath(posixpath.join(posixpath.dirname(path), source)); assert content.encode() == blob(APP, member); groups['workspace'].append({'path': member, 'sha256': sha(content.encode())})
            else: groups['otherDependencies'] += 1
        maps.append({'path': path, 'sources': len(data['sources']), **groups})
    assert maps[0]['sources'] == 981 and len(maps[0]['workspace']) == 33 and maps[0]['sdk'] == maps[0]['api-types'] == 16
    assert maps[0]['otherDependencies'] == 915 and maps[0]['synthetic'] == ['<define:import.meta.env>'] and maps[1]['sources'] == len(maps[1]['workspace']) == 1
    index_path = next(n for n in entries if '/assets/index-' in n and n.endswith('.js')); index = entries[index_path]
    css_path = next(n for n in entries if n.endswith('.css')); css = entries[css_path]
    production = ['Minified React error #', 'bundleType:0,version:`19.3.0`,rendererPackageName:`react-dom`']
    development = ['act(...) is not supported', 'actQueue', '_debugStack', '__DEV__', 'You are calling ReactDOMClient.createRoot()']
    assert all(m.encode() in index for m in production) and all(m.encode() not in index for m in development)
    raster = blob(APP, 'packages/app/src/screens/files/raster.ts'); raster_test = blob(APP, 'packages/app/src/screens/files/raster.test.ts')
    assert sha(raster) == '3aaacb7094d26554ebb1e61973e026a05a4067fe0f13714ebca4f2f26388ced7' and sha(raster_test) == '619ec5fe7d970224ef1309e862c24130a01bfda18aa6a0c4656e54c6ba38f031'
    assert sha(raster.replace(b'.replace(/^[ .]+/, "")', b'.replace(/^[ .]+|[ .]+$/g, "")')) == 'ee05e29a8d4c4d5b25d588df1f2d100cf9c717a4c82213d3306ba4200179794e'
    assert sha(raster_test.replace(b'    expect(rasterFilename(`a${" ".repeat(200_000)}b.png`, "image/png")).toBe("a.png");\n', b'')) == '5c2f28910314b5f7005944c5d3d750a0466fd0eb4c13e9cf691c92f138e04981'
    linux = load(FROZEN / 'linux-package.json'); assert linux == load(ORIGINAL / 'linux-package.json') and linux['revision'] == DIRTY and linux['dirty'] is True
    assert pin['originalRunBase'] == DIRTY and all(pin[k] == linux[k] for k in ['packageInputs', 'rendererFingerprint', 'buildMembers', 'asarSHA256'])
    assert linux['packageInputs'] == len(inputs) and linux['rendererFingerprint'] == fingerprint and linux['buildMembers'] == len(members) and linux['asarSHA256'] == sha(asar)
    assert linux_asar.read_bytes() == asar
    assert files_at(FROZEN / 'source') == inputs and {'packages/' + n: d for n, d in files_at(FROZEN / 'packages').items()} == members
    assert {str(p): file_sha(p) for p in watched} == before
    save('integrity.json', {'beforeSHA256': before, 'afterAllEqual': True, 'asarFiles': integrity, 'resources': resources, 'zipLinks': resolved_links, 'zipFiles': zip_files, 'nativeBinaries': native_binaries})
    save('source-hashes.json', {'maps': maps, 'vendorArchives': archive_pins, 'rootPackageMetadata': root_package, 'rendererPaths': RENDER_PATHS, 'additionalPackagePaths': EXTRA_PATHS, 'changedInputs': changed_rows, 'addedCatalogKeys': added_keys, 'rasterSHA256': sha(raster), 'rasterTestSHA256': sha(raster_test)})
    summary = {'status': 'approved-for-installation', 'applicationRevision': APP, 'baselineApplication': PRIOR, 'workflowRunID': artifact['workflow_run']['id'], 'artifactID': artifact['id'], 'outerBytes': artifact['size_in_bytes'], 'archiveSHA256': EXPECTED,
        'zip': {'outerCRC': 'passed', 'innerCRC': 'passed', 'innerEntries': len(names), 'regularFiles': len(zip_files), 'frameworkSymlinks': len(links), 'symlinksContainedAndExisting': True, 'arm64MachOBinaries': len(native_binaries), 'nativeBinariesIdenticalToActivity': True},
        'asar': {'files': len(entries), 'integrityBlocks': sum(r['verifiedBlocks'] for r in integrity), 'completeContiguousPayload': True, 'links': 0, 'unpacked': 0, 'buildMembers': len(members), 'extraRootPackageMatchesGit': True, 'linuxBytesIdentical': True},
        'resources': {'catalogs': len(catalogs), 'locales': locales, 'skills': 1, 'extraCatalogOrSkillFiles': 0, 'fixturesOrSourceStamps': 0},
        'source': {'packageInputs': len(inputs), 'rendererInputs': len(render_inputs), 'allFrozenSourceBytesMatchGit': True, 'pathSetsIndependentlyEnumerated': True, 'rendererFingerprint': fingerprint, 'fingerprintAlgorithm': 'sha256(LF-joined sorted path:sha256, no trailing LF)', 'changedInputs': changed_rows, 'sourceFilesChanged': len(source_changes), 'runtimeFilesChanged': len(source_changes) - 1, 'testFilesChanged': 1, 'newInputs': delta['newInputs'], 'catalogFilesChanged': len(added_keys), 'newKeysPerLocale': 19, 'newCatalogValues': sum(map(len, added_keys.values())), 'priorCatalogValuesUnchanged': True, 'dependencyPinsUnchanged': True, 'rasterFilenameOnlyCorrectionFromOriginalAuthor': True},
        'desktopIdenticalToActivity': {n: sha(entries[n]) for n in desktop}, 'maps': {'mainWorkspace': 33, 'preloadWorkspace': 1, 'sdk': 16, 'apiTypes': 16, 'otherDependencySourcesUnchanged': 915},
        'productionRenderer': {'path': index_path, 'bytes': len(index), 'sha256': sha(index), 'presentMarkers': production, 'absentDevelopmentMarkers': development}, 'compiledCSS': {'path': css_path, 'bytes': len(css), 'sha256': sha(css)},
        'receipts': {'originalDirtyBase': DIRTY, 'originalCommittedReceiptsPreserved': True, 'reboundHeadersOnly': True, 'applicationPinAndSourceDeltaVerified': True, 'inputsStableBeforeAfter': True},
        'scope': {'offlinePackageAdmissionOnly': True, 'ciPass': 'coordinator-reported; retained artifact identity checked, no CI query', 'nativeCollectorSourceApproval': 'separate pending work', 'installedNativeAcceptance': False, 'fullProductGoalComplete': False, 'executedBuilds': 0, 'executedApplicationTests': 0, 'networkRequests': 0, 'deviceOrLeaseActions': 0},
        'startedUTC': started, 'finishedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'verifier': {'path': str(Path(__file__)), 'sha256': file_sha(Path(__file__)), 'historicalHelpers': {str(p): file_sha(p) for p in helpers}}, 'detailReceipts': {n: file_sha(OUT / n) for n in ['integrity.json', 'source-hashes.json']}}
    save('summary.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in ['source', 'desktopIdenticalToActivity', 'verifier']}, indent=2))

if __name__ == '__main__':
    main()
