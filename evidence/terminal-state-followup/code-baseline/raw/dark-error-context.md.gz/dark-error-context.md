# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: code-models.spec.ts >> Code persisted provider failure stays Failed across reload and recovers after a successful follow-up — dark
- Location: tests/e2e/code-models.spec.ts:257:40

# Error details

```
Error: A persisted failed Code result must not be green Ready

expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "className": "badge err",
-   "text": "Failed",
+   "className": "badge ok",
+   "text": "Ready",
  }
```

```
Error: Reload must derive Failed from the persisted assistant error

expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "className": "badge err",
-   "text": "Failed",
+   "className": "badge ok",
+   "text": "Ready",
  }
```

# Page snapshot

```yaml
- generic [active] [ref=f1e1]:
  - generic [ref=f1e4]:
    - generic [ref=f1e5]:
      - generic [ref=f1e7]:
        - button "Hide sidebar" [ref=f1e8]
        - button "Back" [ref=f1e12]
        - button "Forward" [disabled] [ref=f1e18]
      - generic [ref=f1e23]:
        - button "Share" [ref=f1e24]
        - button "Focus mode" [ref=f1e30]
    - generic [ref=f1e39]:
      - navigation "Main navigation" [ref=f1e40]:
        - button "Home" [ref=f1e41]
        - button "Library" [ref=f1e48]
        - button "History" [ref=f1e54]
        - button "Bot team" [ref=f1e61]
        - button "Activity" [ref=f1e71]
        - button "More" [ref=f1e77]
        - radiogroup "Theme" [ref=f1e83]:
          - generic [ref=f1e84]:
            - radio "Light" [ref=f1e85]
            - radio "System" [ref=f1e98]
            - radio "Dark" [checked] [ref=f1e102]
        - button "Settings" [ref=f1e107]
      - generic [ref=f1e118]:
        - complementary "Sidebar" [ref=f1e119]:
          - generic [ref=f1e120]:
            - generic [ref=f1e121]:
              - button "Cortex Code" [ref=f1e122]
              - generic [ref=f1e129]:
                - button "Notifications" [ref=f1e130]
                - button "Search" [ref=f1e137]
            - generic [ref=f1e143]:
              - generic [ref=f1e144]:
                - button "New task" [ref=f1e145]
                - button "Code reviews" [ref=f1e154]
                - button "All tasks" [ref=f1e165]
              - generic [ref=f1e173]:
                - generic [ref=f1e174]: Sessions
                - button "Persist this failed Code request" [ref=f1e176]
                - generic [ref=f1e178]: Environments
                - button "This computer ready" [ref=f1e180]:
                  - generic [ref=f1e186]: This computer
                  - generic [ref=f1e187]: ready
            - button "Getting started 0 of 5" [ref=f1e190]:
              - generic [ref=f1e194]: Getting started
              - generic [ref=f1e195]: 0 of 5
        - main [ref=f1e196]:
          - generic [ref=f1e197]:
            - generic [ref=f1e198]: Persist this failed Code request
            - generic [ref=f1e199]: Ready
          - generic [ref=f1e200]:
            - generic [ref=f1e201]:
              - generic [ref=f1e202]: Persist this failed Code request
              - generic [ref=f1e203]: Recover in the same Code session
              - generic [ref=f1e204]: Hello from the streaming test provider. Everything works.
              - generic [ref=f1e207]:
                - button "Add" [ref=f1e208]
                - textbox "Ask for a change" [ref=f1e212]
                - button "Reasoner Large" [ref=f1e213]
                - button "Dictate" [ref=f1e218]
                - button "Voice mode" [ref=f1e224]
            - generic [ref=f1e234]:
              - tablist [ref=f1e237]:
                - tab "Changes" [selected] [ref=f1e238]
                - tab "Terminal" [ref=f1e239]
              - paragraph [ref=f1e245]: No file changed yet.
  - generic:
    - region "Notifications"
```

# Test source

```ts
  235 |   const fake = await startFakeProvider();
  236 |   const { app, page, dataDir } = await launch({ hash: "#/code", env: { CORTEX_CATALOG_URL: CATALOG_URL, CORTEX_TEST_PROVIDER_BASEURL: "" } });
  237 |   try {
  238 |     await call(page, "/api/providers/fake", "PATCH", { baseURL: fake.url });
  239 |     await call(page, "/api/providers/mistralish", "PATCH", { baseURL: fake.url });
  240 |     for (const model of [{ providerID: "mistralish", modelID: "m" }, { providerID: "fake", modelID: "missing" }] satisfies ModelRef[]) {
  241 |       const session = await call<Session>(page, "/api/sessions", "POST", { kind: "code", directory: dataDir, model });
  242 |       await page.goto(`${page.url().split("#")[0]}#/code-session?id=${session.id}`);
  243 |       await page.reload();
  244 |       await expect(page.locator(".composer .model")).toHaveText(model.modelID === "m" ? "M" : "No model", { timeout: 2500 });
  245 |       const input = page.getByTestId("code-composer-input");
  246 |       await input.fill("Keep this unsupported request");
  247 |       await input.press("Enter");
  248 |       await expect(page.getByText("Message not sent", { exact: true })).toBeVisible();
  249 |       await expect(input).toHaveValue("Keep this unsupported request");
  250 |       expect((await call<Session>(page, `/api/sessions/${session.id}`)).model).toEqual(model);
  251 |       expect(await call<MessageWithParts[]>(page, `/api/sessions/${session.id}/messages`)).toEqual([]);
  252 |       expect(fake.requests).toHaveLength(0);
  253 |     }
  254 |   } finally { await app.close(); await fake.close(); }
  255 | });
  256 | 
  257 | for (const theme of ["light", "dark"]) test(`Code persisted provider failure stays Failed across reload and recovers after a successful follow-up — ${theme}`, async () => {
  258 |   type EngineEvent = import("@cortex/schema").Event;
  259 |   type Probe = { buffer: string; events: EngineEvent[] };
  260 |   const fake = await startFakeProvider({ rejectFirst: true });
  261 |   const { app, page, dataDir } = await launch({ hash: `#/code?theme=${theme}`, locale: "en", env: {
  262 |     CORTEX_CATALOG_URL: CATALOG_URL, CORTEX_TEST_PROVIDER_BASEURL: `fake=${fake.url}`, CORTEX_TEST_PICK_DIRECTORY: "",
  263 |   } }).catch(async (error) => { await fake.close(); throw error; });
  264 |   const errors: string[] = [], rendererHttp: string[] = [], evidence: Record<string, unknown> = { theme };
  265 |   const key = "sk-test-code-failure", first = "Persist this failed Code request", next = "Recover in the same Code session";
  266 |   const answer = "Hello from the streaming test provider. Everything works.";
  267 |   page.on("pageerror", (error) => errors.push(error.message));
  268 |   page.on("console", (message) => { if (message.type() === "error") errors.push(message.text()); });
  269 |   page.on("request", (request) => { if (/^https?:/.test(request.url())) rendererHttp.push(request.url()); });
  270 |   const capture = async (name: string) => {
  271 |     const image = test.info().outputPath(`${name}-${theme}.png`);
  272 |     await page.screenshot({ path: image, animations: "disabled" });
  273 |     await test.info().attach(name, { path: image, contentType: "image/png" });
  274 |   };
  275 |   try {
  276 |     const directory = path.join(dataDir, "project"); fs.mkdirSync(directory);
  277 |     await page.emulateMedia({ reducedMotion: "reduce" });
  278 |     await app.evaluate(({ BrowserWindow, dialog }, directory) => {
  279 |       const window = BrowserWindow.getAllWindows()[0], contents = window.webContents, send = contents.send.bind(contents);
  280 |       window.setContentSize(960, 640);
  281 |       dialog.showOpenDialog = (async () => ({ canceled: false, filePaths: [directory] })) as typeof dialog.showOpenDialog;
  282 |       const probe: Probe = { buffer: "", events: [] };
  283 |       (globalThis as unknown as { codeFailureProbe: Probe }).codeFailureProbe = probe;
  284 |       // Observe the existing SSE delivery channel without resubscribing or changing chunks.
  285 |       contents.send = (channel, ...args) => {
  286 |         if (channel === "cortex:events:chunk") {
  287 |           probe.buffer += args[0] as string;
  288 |           let end: number;
  289 |           while ((end = probe.buffer.indexOf("\n\n")) >= 0) {
  290 |             const frame = probe.buffer.slice(0, end); probe.buffer = probe.buffer.slice(end + 2);
  291 |             const data = frame.split("\n").find((line) => line.startsWith("data:"))?.slice(5);
  292 |             if (data) probe.events.push(JSON.parse(data) as EngineEvent);
  293 |           }
  294 |         }
  295 |         send(channel, ...args);
  296 |       };
  297 |     }, directory);
  298 |     await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  299 |     await call(page, "/api/providers/fake/key", "PUT", { key });
  300 |     await select(page, "Reasoner Large");
  301 |     const input = page.getByTestId("code-composer-input"), badge = page.locator(".content-top .badge"), banner = page.locator(".code-banner");
  302 |     const badgeState = () => badge.evaluate((el) => ({ text: el.textContent, className: el.className }));
  303 |     const fence = async () => {
  304 |       await call(page, "/api/health");
  305 |       await page.evaluate(() => new Promise<void>((resolve) => queueMicrotask(() => requestAnimationFrame(() => requestAnimationFrame(() => resolve())))));
  306 |     };
  307 |     await input.fill(first); await input.press("Enter");
  308 |     await expect(page).toHaveURL(/#\/code-session\?/);
  309 |     const id = new URLSearchParams(page.url().split("?")[1]).get("id")!;
  310 |     const messages = () => call<MessageWithParts[]>(page, `/api/sessions/${id}/messages`);
  311 |     const events = () => app.evaluate(() => (globalThis as unknown as { codeFailureProbe: Probe }).codeFailureProbe.events);
  312 |     const statuses = async () => (await events()).filter((e) => e.type === "session.status" && e.properties.sessionID === id).map((e) => e.type === "session.status" && e.properties.status.type);
  313 |     await expect.poll(async () => {
  314 |       const rows = await messages(), last = rows.at(-1);
  315 |       return rows.length === 2 && last?.info.time.completed !== undefined ? last.info.error?.code : undefined;
  316 |     }).toBe("provider_error"); // Existing rejectFirst fixture is a real HTTP400, not an auth401.
  317 |     await expect.poll(statuses).toEqual(["busy", "error", "idle"]);
  318 |     await expect(banner).toContainText("The task stopped"); await expect(page.getByTestId("code-stop")).toHaveCount(0);
  319 |     await fence();
  320 |     const failed = await messages();
  321 |     expect(failed.map((m) => m.info.role)).toEqual(["user", "assistant"]);
  322 |     expect(failed[0].parts.filter((p) => p.type === "text")).toMatchObject([{ text: first }]);
  323 |     expect(fake.requests).toHaveLength(1);
  324 |     expect(await call<Session>(page, `/api/sessions/${id}`)).toMatchObject({ kind: "code", model: B, directory, agent: "build" });
  325 |     evidence.id = id; evidence.failed = failed; evidence.initialBadge = await badgeState();
  326 |     // Soft assertions reach the successful follow-up even on the original contradictory badge.
  327 |     expect.soft(evidence.initialBadge, "A persisted failed Code result must not be green Ready").toEqual({ text: "Failed", className: "badge err" });
  328 |     await page.reload();
  329 |     await expect(page.locator("html")).toHaveAttribute("data-theme", theme);
  330 |     await expect(banner).toContainText("The task stopped"); await expect(page.getByTestId("code-stop")).toHaveCount(0);
  331 |     await expect(page.getByTestId("model-trigger")).toHaveText("Reasoner Large");
  332 |     await fence();
  333 |     expect(await messages()).toEqual(failed); expect(fake.requests).toHaveLength(1);
  334 |     evidence.reloadedBadge = await badgeState();
> 335 |     expect.soft(evidence.reloadedBadge, "Reload must derive Failed from the persisted assistant error").toEqual({ text: "Failed", className: "badge err" });
      |                                                                                                         ^ Error: Reload must derive Failed from the persisted assistant error
  336 |     await capture("failed-reload");
  337 |     await input.fill(next); await input.press("Enter");
  338 |     await expect(badge).toHaveText("Running"); await expect(badge).toHaveClass("badge run");
  339 |     await expect(page.getByTestId("code-stop")).toBeVisible(); await expect(banner).toHaveCount(0);
  340 |     evidence.runningBadge = await badgeState();
  341 |     await expect.poll(async () => {
  342 |       const rows = await messages(), last = rows.at(-1);
  343 |       return rows.length === 4 && last?.info.time.completed !== undefined && !last.info.error ? last.parts.filter((p) => p.type === "text").map((p) => p.text).join("") : "";
  344 |     }).toBe(answer);
  345 |     await expect.poll(statuses).toEqual(["busy", "error", "idle", "busy", "idle"]);
  346 |     await expect(badge).toHaveText("Ready"); await expect(badge).toHaveClass("badge ok"); await expect(banner).toHaveCount(0);
  347 |     await expect(page.getByTestId("code-stop")).toHaveCount(0); await expect(input).toHaveValue("");
  348 |     const recovered = await messages();
  349 |     expect(recovered.slice(0, 2)).toEqual(failed);
  350 |     expect(recovered.map((m) => m.info.sessionID)).toEqual([id, id, id, id]);
  351 |     expect(recovered[2].parts.filter((p) => p.type === "text")).toMatchObject([{ text: next }]);
  352 |     expect(recovered[3].info.error).toBeUndefined();
  353 |     expect(await call<Session[]>(page, "/api/sessions?kind=code")).toMatchObject([{ id, model: B, directory }]);
  354 |     expect(fake.requests).toHaveLength(2);
  355 |     for (const request of fake.requests) { expect(request.body.model).toBe(B.modelID); expect(request.auth).toBe(`Bearer ${key}`); }
  356 |     const streamed = (await events()).filter((e) => e.type === "part.delta" && e.properties.messageID === recovered[3].info.id);
  357 |     expect(streamed.length).toBeGreaterThan(0);
  358 |     await expect(page.locator(".split-l .msg-user")).toHaveText([first, next]); await expect(page.locator(".split-l .msg-bot")).toHaveText([answer]);
  359 |     evidence.recovered = recovered; evidence.recoveredBadge = await badgeState();
  360 |     expect(errors).toEqual([]); expect(rendererHttp).toEqual([]);
  361 |     await capture("recovered");
  362 |   } finally {
  363 |     try {
  364 |       const events = await app.evaluate(() => (globalThis as unknown as { codeFailureProbe?: Probe }).codeFailureProbe?.events ?? []);
  365 |       await test.info().attach("code-failure-evidence", { body: JSON.stringify({ ...evidence, events, errors, rendererHttp, requests: fake.requests }, null, 2), contentType: "application/json" });
  366 |     } finally { try { await app.close(); fs.rmSync(dataDir, { recursive: true, force: true }); } finally { await fake.close(); } }
  367 |   }
  368 | });
  369 | 
```