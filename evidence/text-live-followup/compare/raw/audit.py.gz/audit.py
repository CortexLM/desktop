"""Offline audit of supplied preview receipts; no application or browser execution."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlsplit, unquote
import difflib, gzip, hashlib, json, os, subprocess
from PIL import Image, ImageDraw, ImageFont

REPO = Path.cwd()
OUT = REPO / 'evidence/text-live-followup/compare'
TMP = Path('/tmp/opencode/text-compare-audit')
BASE = Path('/tmp/opencode/files-text/compare-initial')
BUILD = Path('/tmp/opencode/build-files-text-initial')
SOURCE = BUILD / 'source'
FREEZE = Path('/root/cortex-ui-freezes/2026-10-02-7b388e2d9674')
PRIOR = REPO / 'evidence/files-live-followup/compare'
REV = 'f2c1bc828d2eb64fbe0792031c2e33de63c54957'
FP = 'e19de38f6a5cd68b770c9a960bc9e9e62e5e88b27885602c3a6b8e6845354c4b'
sha = lambda b: hashlib.sha256(b).hexdigest()
fp = lambda rows: sha('\n'.join(f'{p}:{h}' for p,h in sorted(rows.items())).encode())
pins = {}

def read(p):
    p = Path(p); data = p.read_bytes(); digest = sha(data)
    assert str(p) not in pins or pins[str(p)] == digest, f'Input changed: {p}'
    pins[str(p)] = digest
    return data

def load(p): return json.loads(read(p))

def save(name, data):
    p = OUT/name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')

def copy(p, name):
    dst = OUT/name; dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(read(p))

def rgba(p):
    read(p)
    with Image.open(p) as im:
        im.load(); assert im.size == (2880,1800)
        return im.convert('RGBA')

started = datetime.now(timezone.utc).isoformat()
assert not OUT.exists(), 'Fresh evidence destination required'
OUT.mkdir(parents=True)
# Original receipts are retained before any inventory checks; never relabel them as a future commit.
for name in ['report.json','provenance.json']: copy(BASE/name, name)
copy('/tmp/opencode/files-text/compare-initial.log', 'capture.log')
copy('/tmp/opencode/files-text/build-initial.log', 'binding/build.log')
for name in ['pinned-inputs.json','renderer-inputs.json','members.json']: copy(BUILD/name,'binding/'+name)
rows = load(BASE/'report.json'); prov = load(BASE/'provenance.json'); run = prov['runs'][0]
assert len(rows)==len({r['name'] for r in rows})==13 and len(prov['runs'])==1
assert sha(read(BASE/'report.json')) == prov['reportSha256']
assert prov['counts']==dict(registered=426,optionalInteractions=5,capturedThisRun=13,retainedRows=13,compared=12,noDesignShot=1)
assert run['baseUrl']=='http://127.0.0.1:5434/' and run['only']==['file-code','file-image','chat'] and run['jobCount']==13
clock = dict(mode='fixed',source='cli',time='2026-10-02T12:00:00.000Z',timezone='UTC',timers='real')
assert prov['clock']==run['clock']==clock
assert prov['render']==dict(viewport=dict(width=1440,height=900),deviceScaleFactor=2,locale='fr-FR',catalogLocale='fr',pixelmatchThreshold=0.15)
assert sha(read(REPO/'scripts/compare-shots.mjs'))==prov['comparatorSha256']
docs={name:load(BUILD/name) for name in ['pinned-inputs.json','renderer-inputs.json','members.json']}
assert all(d['revision']==REV and d['dirty'] is True for d in docs.values())
imap={r['path']:r['sha256'] for r in docs['pinned-inputs.json']['inputs']}
bmap={r['path']:r['sha256'] for r in docs['members.json']['members']}
assert len(imap)==len(docs['pinned-inputs.json']['inputs'])==524
assert len(bmap)==len(docs['members.json']['members'])==90
actual={str(p.relative_to(SOURCE)):sha(read(p)) for p in SOURCE.rglob('*') if p.is_file()}
assert actual==imap
roots=['packages/app/src','packages/app/public','packages/client/src','packages/core/src','packages/desktop/src','packages/i18n/src','packages/i18n/locales','packages/protocol/src','packages/schema/src','packages/server/src','skills']
singles=['bun.lock','electron-builder.yml','package.json','packages/app/index.html','packages/app/package.json','packages/app/vite.config.ts','packages/client/package.json','packages/core/README.md','packages/core/package.json','packages/desktop/build.mjs','packages/desktop/package.json','packages/i18n/package.json','packages/protocol/package.json','packages/schema/package.json','packages/server/package.json','tsconfig.json']
assert {str(p.relative_to(SOURCE)) for root in roots for p in (SOURCE/root).rglob('*') if p.is_file()} | set(singles)==set(imap)
current={p:sha(read(REPO/p)) for p in imap}
current_delta=[dict(path=p,captured=h,current=current[p]) for p,h in imap.items() if current[p]!=h]
current_paths={str(p.relative_to(REPO)) for root in roots for p in (REPO/root).rglob('*') if p.is_file()} | set(singles)
assert {str(p.relative_to(BUILD)):sha(read(p)) for root in ['packages/app/dist','packages/desktop/dist'] for p in (BUILD/root).rglob('*') if p.is_file()}==bmap
rmap={}
for name in prov['application']['sourcePaths']:
    p=SOURCE/name
    for f in p.rglob('*') if p.is_dir() else [p]:
        if f.is_file(): rmap[str(f.relative_to(SOURCE))]=sha(read(f))
assert rmap=={r['path']:r['sha256'] for r in docs['renderer-inputs.json']['files']}
assert len(rmap)==docs['renderer-inputs.json']['sourceFileCount']==prov['application']['sourceFileCount']==482
assert fp(rmap)==docs['renderer-inputs.json']['sourceFingerprint']==prov['application']['sourceFingerprint']==FP
assert prov['application']['revision']==run['applicationRevision']==REV
assets=[]
for a in run['build']['files']:
    u=urlsplit(a['url']); assert u.scheme=='http' and u.netloc=='127.0.0.1:5434' and not u.query and not u.fragment
    name='packages/app/dist/'+(unquote(u.path).lstrip('/') or 'index.html')
    assert '..' not in Path(name).parts and name in bmap
    data=read(BUILD/name); assert sha(data)==bmap[name]==a['sha256'] and len(data)==a['bytes']
    assets.append({**a,'frozenMember':name})
assert len(assets)==20 and sha('\n'.join(f"{a['url']}:{a['sha256']}" for a in run['build']['files']).encode())==run['build']['sha256']
errors=run['ignoredPreviewApiErrors']
assert all(urlsplit(e['url']).path.startswith('/api/') and '404' in e['message'] for e in errors)
# Source preservation is compared to the actual dirty base, not inferred from future Git metadata.
batch=subprocess.Popen(['git','cat-file','--batch'],cwd=REPO,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
before={}
for p in sorted(imap):
    batch.stdin.write((REV+':'+p+'\n').encode()); batch.stdin.flush(); head=batch.stdout.readline()
    if head.endswith(b' missing\n'): continue
    assert b' blob ' in head, head
    before[p]=batch.stdout.read(int(head.split()[-1])); assert batch.stdout.read(1)==b'\n'
batch.stdin.close(); assert batch.wait()==0
added=sorted(set(imap)-set(before)); changed=sorted(p for p in before if sha(before[p])!=imap[p])
media='packages/app/src/screens/files/media.tsx'; css='packages/app/src/screens/files/files.css'; chat='packages/app/src/screens/chat/live-chat.tsx'
assert sha(before[media])==imap[media]
new_css=read(SOURCE/css).decode(); start=new_css.index('.medias-text-live {'); end=new_css.index('\n\n',start)+2
assert (new_css[:start]+new_css[end:]).encode()==before[css]
fragment=lambda text:text.split('function PreviewChat(',1)[1].split('const textOf',1)[0]
assert fragment(read(SOURCE/chat).decode())==fragment(before[chat].decode())
assert imap['packages/app/src/screens/chat/states.tsx']==sha(before['packages/app/src/screens/chat/states.tsx'])
source_patch=''.join(''.join(difflib.unified_diff(before[p].decode().splitlines(True),read(SOURCE/p).decode().splitlines(True),fromfile=REV+'/'+p,tofile='captured-dirty/'+p)) for p in changed if p.endswith(('.tsx','.css')))
(OUT/'binding/source.patch').write_text(source_patch)
save('binding/source-delta.json',dict(baseRevision=REV,dirty=True,added=[dict(path=p,sha256=imap[p]) for p in added],changed=[dict(path=p,before=sha(before[p]),captured=imap[p]) for p in changed],unchangedInputs=len(before)-len(changed),mediaSourceByteIdentical=True,allPreexistingFilesCSSByteIdentical=True,PreviewChatFunctionByteIdentical=True,chatStatesByteIdentical=True,newTextCSSRuleCount=new_css[start:end].count('{'),capturedTextSHA256=imap['packages/app/src/screens/files/text.tsx'],capturedCSSSHA256=imap[css]))
freeze=load(FREEZE/'freeze.json'); fsource={str(p.relative_to(FREEZE)):sha(read(p)) for p in (FREEZE/'src').rglob('*') if p.is_file()}
assert len(fsource)==freeze['sourceFileCount']==prov['reference']['sourceFileCount']==106
assert fp(fsource)==freeze['sourceFingerprint']==prov['reference']['sourceFingerprint']=='7b388e2d967400d20bf5f2cc7cd44c56ba74859889908c220964f8d12abfc768'
meta={'freezeSha256':'freeze.json','manifestSha256':'shots/manifest.json','registrySha256':'shots/registry.json','coverageSha256':'review/cmp/coverage.json','motionIndexSha256':'public/states/index.json'}
for key,name in meta.items(): assert sha(read(FREEZE/name))==prov['reference'][key]
manifest=load(FREEZE/'shots/manifest.json')['images']; registry=load(FREEZE/'shots/registry.json')
assert len(manifest)==freeze['captures']['images']==410 and freeze['captures']['states']==205
assert len({(r['route'],r['variant']) for r in manifest.values()})==205
assert len(registry['routes'])==61
assert all(r['sourceFingerprint']==fp(fsource) and r['viewport']==prov['render']['viewport'] and r['deviceScaleFactor']==2 and not r['consoleErrors'] for r in manifest.values())
assert freeze['captures']['status']=='passed'
for key in ['manifestSha256','coverageSha256','motionIndexSha256']: assert freeze['captures'][key]==prov['reference'][key]
assert {p.name for p in (FREEZE/'shots').glob('*.png')}==set(manifest)
for name,record in manifest.items(): assert sha(read(FREEZE/'shots'/name))==record['sha256']
originals=[]
expected=[('chat-'+t,'chat','',t,None) for t in ['dark','light']]+[(f'file-image~{a}-{t}','file-image',v,t,None) for a,v in [('view','affichage'),('zoom','zoom'),('compare','comparaison')] for t in ['dark','light']]+[(f'file-code~{a}-{t}','file-code',v,t,None) for a,v in [('view','affichage'),('diff','diff')] for t in ['dark','light']]+[('file-image+ask-light','file-image','affichage','light','ask')]
assert [r['name'] for r in rows]==[e[0] for e in expected]
for row,(_,route,variant,theme,interaction) in zip(rows,expected):
    state=dict(route=route,variant=variant,theme=theme,interaction=interaction)
    assert row['clock']==clock and row['run']==run['id'] and all(row['reference'][k]==v for k,v in state.items())
    matches=[(n,r) for n,r in manifest.items() if all(r[k]==v for k,v in state.items())]
    if row.get('status'): assert not matches and row['status']=='no-design-shot' and list(row['files'])==['app']
    else:
        assert len(matches)==1; name,ref=matches[0]
        assert row['reference']=={**ref,'file':name} and row['ref']==name
        assert sha(read(FREEZE/'shots'/name))==ref['sha256'] and read(BASE/row['files']['design']['file'])==read(FREEZE/'shots'/name)
    for kind,f in row['files'].items():
        p=BASE/f['file']; data=read(p); assert sha(data)==f['sha256'] and len(data)==f['bytes']
        with Image.open(p) as im: im.verify()
        image=rgba(p); originals.append(dict(state=row['name'],kind=kind,**f,width=2880,height=1800,rgbaSHA256=sha(image.tobytes()),alphaExtrema=list(image.getchannel('A').getextrema())))
assert len(originals)==37
save('original-images.json',originals)
# Prior same-state archive is a reuse candidate, never a substitute without exact decoded equality.
prior=load(PRIOR/'retained.json')['images']; retained=[]; previous_app=[]
for original in originals:
    if original['kind']=='diff': continue
    im=rgba(BASE/original['file']); payload=im.tobytes(); candidate=next((r for r in prior if r['state']==original['state'] and r['kind']==original['kind']),None)
    canonical=None
    if candidate:
        p=(PRIOR/candidate['file']).resolve(); assert sha(read(p))==candidate['sha256']
        old=rgba(p); assert sha(old.tobytes())==candidate['rgbaSHA256']
        if old.tobytes()==payload: canonical=p
        if original['kind']=='app':
            target=TMP/(original['state']+'.previous.png'); old.save(target)
            previous_app.append(dict(name=original['state'],file=str(target),sha256=sha(target.read_bytes()),archive=os.path.relpath(p,OUT),archiveSHA256=candidate['sha256'],rgbaSHA256=candidate['rgbaSHA256']))
    if canonical is None:
        target=OUT/'images'/f"{original['state']}.{original['kind']}.webp"; target.parent.mkdir(exist_ok=True)
        im.save(target,format='WEBP',lossless=True,method=6,exact=True); storage='new-lossless-WebP'
    else: target=canonical; storage='existing-RGBA-exact-canonical'
    with Image.open(target) as check: assert check.convert('RGBA').tobytes()==payload
    retained.append(dict(state=original['state'],kind=original['kind'],sourcePNG=original['file'],sourceSHA256=original['sha256'],sourceBytes=original['bytes'],rgbaSHA256=original['rgbaSHA256'],file=os.path.relpath(target,OUT),sha256=sha(target.read_bytes()),bytes=target.stat().st_size,width=2880,height=1800,rgbaExact=True,storage=storage))
save('retained.json',dict(policy='Only exact decoded RGBA permits canonical reuse. WebPs are lossless; original diff PNG hashes and reproducible arithmetic retained separately.',newWebPs=sum(r['storage']=='new-lossless-WebP' for r in retained),canonicalReuses=sum(r['storage']=='existing-RGBA-exact-canonical' for r in retained),images=retained))
(TMP/'previous-app.json').write_text(json.dumps(previous_app,indent=2)+'\n')
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16); contacts=[]
for page,start in enumerate([0,7],1):
    group=rows[start:start+7]; sheet=Image.new('RGB',(1740,len(group)*389),(238,238,238)); draw=ImageDraw.Draw(sheet)
    for y,row in enumerate(group):
        draw.text((8,y*389+4),row['name']+' | app / frozen / diff | '+str(row.get('diffPct','gap')),fill=(20,20,20),font=font)
        for col,kind in enumerate(['app','design','diff']):
            if kind not in row['files']: continue
            image=rgba(BASE/row['files'][kind]['file']).convert('RGB'); image.thumbnail((568,355),Image.Resampling.LANCZOS); sheet.paste(image,(8+col*580,y*389+27))
    target=OUT/'contacts'/f'pairs-{page:02d}.jpg'; target.parent.mkdir(exist_ok=True); sheet.save(target,quality=90)
    contacts.append(dict(file=str(target.relative_to(OUT)),sha256=sha(target.read_bytes()),states=[r['name'] for r in group],derivedFromOriginalPNGs=True))
save('contacts.json',contacts)
archives=[]
for src,name in [(REPO/'scripts/compare-shots.mjs','comparator.mjs.gz'),(FREEZE/'shots/manifest.json','reference-manifest.json.gz'),(FREEZE/'freeze.json','reference-freeze.json.gz'),(BASE/'index.html','original-index.html.gz')]:
    data=read(src); target=OUT/'raw'/name; target.parent.mkdir(exist_ok=True); target.write_bytes(gzip.compress(data,mtime=0)); assert gzip.decompress(target.read_bytes())==data
    archives.append(dict(source=str(src),originalSHA256=sha(data),originalBytes=len(data),file='raw/'+name,sha256=sha(target.read_bytes())))
save('raw-retention.json',archives)
save('binding/verified.json',dict(status='passed',captureDirtyBase=REV,commitAuthority=False,sourceFiles=524,rendererFiles=482,rendererFingerprint=FP,completeFrozenSourcePathSet=True,completeRendererPathSet=True,completeMemberPathSet=True,buildMembers=90,servedAssetCount=20,servedAssets=assets,currentInputsMatched=524-len(current_delta),currentSourceDelta=current_delta,currentExtraPaths=sorted(current_paths-set(imap)),currentMissingPaths=sorted(set(imap)-current_paths),referenceSourceFiles=106,referenceStates=205,referenceManifestEntries=410,referenceAllOriginalPNGHashesVerified=410,referenceSelectedOriginalPNGsVerified=12,suppliedPNGCount=37,ignoredPreviewAPI404s=len(errors),limits='Offline receipt/frozen-byte verification; no rebuild, fetch, signed provenance, Git commit binding, package, CI or native acceptance.'))
unstable=[dict(path=p,before=h,after=sha(Path(p).read_bytes())) for p,h in pins.items() if sha(Path(p).read_bytes())!=h]
assert not unstable, unstable
save('binding/input-hashes.json',pins)
save('verification.json',dict(status='passed',startedUTC=started,finishedUTC=datetime.now(timezone.utc).isoformat(),stableInputs=len(pins),imageDecoder='Pillow '+Image.__version__,rawPNGs=37,originalViews=25,newWebPs=sum(r['storage']=='new-lossless-WebP' for r in retained),canonicalReuses=sum(r['storage']=='existing-RGBA-exact-canonical' for r in retained),newWebPBytes=sum(r['bytes'] for r in retained if r['storage']=='new-lossless-WebP'),contacts=2,newCaptures=0,networkRequests=0,applicationTests=0,builds=0))
print(json.dumps(dict(verification=load(OUT/'verification.json'),sourceAdded=added,sourceChanged=changed,currentSourceDelta=current_delta),indent=2))
