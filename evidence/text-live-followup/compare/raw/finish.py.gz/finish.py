"""Finalize supplied-image review receipts after full-size inspection; offline only."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, re
from PIL import Image

REPO=Path.cwd(); OUT=REPO/'evidence/text-live-followup/compare'; TMP=Path('/tmp/opencode/text-compare-audit')
BASE=Path('/tmp/opencode/files-text/compare-initial'); BUILD=Path('/tmp/opencode/build-files-text-initial')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
rows=load(OUT/'report.json'); metrics=load(OUT/'metrics.json'); retained=load(OUT/'retained.json')['images']; verified=load(OUT/'binding/verified.json')
assert [r['name'] for r in rows]==[r['name'] for r in metrics['rows']]
assert sum(r['frozen'] is not None for r in metrics['rows'])==12
assert all(r['frozen']['diffPNGBytesReproduced'] for r in metrics['rows'] if r['frozen'])
prior=load(TMP/'previous-app.json'); details=[]
def crop(p,rect):
    with Image.open(p) as im: return im.convert('RGBA').crop(rect).tobytes()
for row in rows:
    rect=([754,150,2790,1690] if row['name'].startswith('file-code') else [1150,430,2460,1080] if row['name'].startswith('chat') else None)
    if rect is None: continue
    a=crop(BASE/row['files']['app']['file'],rect)
    item=dict(name=row['name'],region='code-main-interior' if row['name'].startswith('file-code') else 'chat-transcript-text-code',rect=rect,rgbaSHA256=sha(a))
    for kind in ['design','prior']:
        previous=next((p for p in prior if p['name']==row['name']),None)
        if kind=='prior' and not previous: continue
        b=crop(BASE/row['files']['design']['file'] if kind=='design' else Path(previous['file']),rect)
        count=sum(a[i:i+4]!=b[i:i+4] for i in range(0,len(a),4))
        item[kind]=dict(rawPixels=count,rgbaExact=count==0)
    if row['name'].startswith('file-code'): assert item['design']['rgbaExact']
    if row['name'].startswith('chat'): assert item['prior']['rgbaExact']
    details.append(item)
save('regions.json',dict(policy='Supplemental exact unshifted RGBA crops, original device pixels; not replacement whole-frame metrics.',rows=details))
notes={
    'chat':'French transcript, code block, composer and shell retain the reference layout in both themes. Inherited punctuation-space differences remain; prior transcript crop is RGBA-exact. No newly clipped text or overlap observed.',
    'view':'Image, zoom controls and metadata panel retain placement in both themes. Main-content RGBA equals the prior image delivery; no blank image, missing control or new clipping observed.',
    'zoom':'Enlarged image, minimap and metadata remain positioned consistently in both themes. Main-content RGBA equals the prior image delivery; frozen zoom residuals remain explicit.',
    'compare':'Before/after image split, handle, labels and retouch actions retain their layout in both themes. Main-content RGBA equals the prior delivery; inherited retouch punctuation/residuals remain.',
    'code-view':'panier.ts header, 44-line metadata, monospace rows, gutter, highlighting, minimap and toolbar retain the supplied approved reference layout. Main interior is RGBA-exact to frozen.',
    'code-diff':'Diff badges, numbered rows, red/green bands, minimap and toolbar retain reference alignment in both themes. Main interior is RGBA-exact to frozen; rounded zero is not whole-frame equality.',
    'ask':'Image, metadata and Ask panel are readable without observed overlap. This is an unpaired fixture frame with no matching frozen reference; no design-fidelity credit.'
}
review=[]
for row in rows:
    name=row['name']; kind=('ask' if '+ask' in name else 'chat' if name.startswith('chat') else 'code-diff' if name.startswith('file-code~diff') else 'code-view' if name.startswith('file-code') else 'zoom' if '~zoom' in name else 'compare' if '~compare' in name else 'view')
    images=[dict(kind=k,file=next(r['file'] for r in retained if r['state']==name and r['kind']==k),originalPNG=f['file'],originalSHA256=f['sha256']) for k,f in row['files'].items() if k!='diff']
    review.append(dict(name=name,fullSizeOriginalsInspected=images,finding=notes[kind],blockingP2=False,status='reference-gap-observed' if row.get('status') else 'scoped-static-pass'))
save('visual-review.json',dict(status='scoped-static-pass',reviewedUTC=datetime.now(timezone.utc).isoformat(),contactSheetsInspected=2,fullSizeApplicationViews=13,fullSizeReferenceViews=12,totalOriginalViews=25,rows=review,limits='Settled browser preview images only. No live text images, minimum-window geometry, keyboard behavior, native chrome, motion, CI or product acceptance.'))
ledger=['# Preview comparison image ledger','','Full-resolution links retain exact decoded RGBA. Original PNG hashes/timestamps remain in report.json and original-images.json.','','| State | Application | Frozen reference | Original rounded % |','| --- | --- | --- | ---: |']
for row in rows:
    a=next(r for r in retained if r['state']==row['name'] and r['kind']=='app'); d=next((r for r in retained if r['state']==row['name'] and r['kind']=='design'),None)
    ref=f"[{row['ref']}]({d['file']})" if d else '**No matching frozen reference**'
    ledger.append(f"| `{row['name']}` | [image]({a['file']}) | {ref} | {row.get('diffPct','gap')} |")
(OUT/'image-index.md').write_text('\n'.join(ledger)+'\n')
helpers=[]
for name in ['audit.py','pixels.mjs','finish.py']:
    source=TMP/name; data=source.read_bytes(); dst=OUT/'raw'/(name+'.gz'); dst.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(dst.read_bytes())==data
    helpers.append(dict(source=str(source),sha256=sha(data),archive=str(dst.relative_to(OUT)),archiveSHA256=sha(dst.read_bytes())))
save('helpers.json',dict(offlineExecuted=helpers,dependencies=metrics['dependencies'],comparatorExecutedByReviewer=False))
pins=load(OUT/'binding/input-hashes.json')
immutable=[p for p in pins if not p.startswith(str(OUT)+os.sep) and (not p.startswith(str(REPO)+os.sep) or p.startswith(str(REPO/'evidence')+os.sep) or p.endswith('scripts/compare-shots.mjs'))]
assert all(sha(Path(p).read_bytes())==pins[p] for p in immutable)
inputs=load(OUT/'binding/pinned-inputs.json')['inputs']; source_now=[]
for row in inputs:
    actual=sha((REPO/row['path']).read_bytes())
    if actual!=row['sha256']: source_now.append(dict(path=row['path'],captured=row['sha256'],current=actual))
assert sha((BASE/'report.json').read_bytes())==sha((OUT/'report.json').read_bytes())
assert sha((BASE/'provenance.json').read_bytes())==sha((OUT/'provenance.json').read_bytes())
assert len(retained)==25 and all((OUT/r['file']).resolve().is_file() and sha((OUT/r['file']).read_bytes())==r['sha256'] for r in retained)
for r in retained:
    with Image.open(OUT/r['file']) as im: assert im.size==(2880,1800) and sha(im.convert('RGBA').tobytes())==r['rgbaSHA256']
assert len((OUT/'README.md').read_text().splitlines())<=60
counts=[r['frozen']['thresholdPixels'] for r in metrics['rows'] if r['frozen']]
save('summary.json',dict(status='scoped-static-pass',captures=13,compared=12,gaps=['file-image+ask-light'],fullSizeOriginalsReviewed=25,rawPNGsChecked=37,pixelmatchThreshold=0.15,allOriginalDiffPNGBytesReproduced=True,maximumExactDifferencePct=max(counts)*100/5184000,meanExactDifferencePct=sum(counts)*100/(12*5184000),sourceInputs=524,rendererInputs=482,rendererFingerprint=verified['rendererFingerprint'],buildMembers=90,servedAssets=20,dirtyBase=verified['captureDirtyBase'],commitAuthority=False,priorRowsCompared=9,priorWholeFramesRGBAExact=sum(r['prior']['rgbaExact'] for r in metrics['rows'] if r['prior']),priorImageContentRGBAExact=6,codeMainInteriorFrozenRGBAExact=4,priorChatTranscriptRGBAExact=2,newWebPs=17,canonicalReferenceReuses=8,newWebPBytes=17178816,blockingVisualP2=0,nativeAcceptance=False,liveTextGolden=False))
save('final-check.json',dict(status='passed',checkedUTC=datetime.now(timezone.utc).isoformat(),immutableInputsRechecked=len(immutable),allImmutableInputsStable=True,capturedSourceInputs=524,currentInputsStillEqual=524-len(source_now),currentSourceDelta=source_now,originalReportAndProvenanceUnchanged=True,retainedRGBAReverified=25,relativeImageLinksValid=True,readmeLines=len((OUT/'README.md').read_text().splitlines()),helperCorrection='First finalizer checked links before writing summary.json; stopped at that missing generated target. Moved link validation after output generation; no capture, metric or application change.',laterSourcePolicy='Any later source change requires separate build attribution; this capture remains attached to the immutable dirty receipts.'))
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
(OUT/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT)}\n' for p in files))
for name in ['README.md','image-index.md']:
    for link in re.findall(r'\]\(([^)]+)\)',(OUT/name).read_text()):
        assert not link.startswith(('http:','https:')) and (OUT/link.split('#')[0]).exists(), link
print(json.dumps(dict(summary=load(OUT/'summary.json'),final=load(OUT/'final-check.json'),retainedFileCount=len(files)+1,retainedBytes=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())),indent=2))
