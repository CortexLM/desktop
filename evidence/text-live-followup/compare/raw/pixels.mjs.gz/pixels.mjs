// Existing-image arithmetic only; no app, browser, network or comparator execution.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
const repo = process.cwd(), require = createRequire(path.join(repo, 'package.json'));
const { PNG } = require('pngjs'), pixelmatch = (await import(require.resolve('pixelmatch'))).default;
const base = '/tmp/opencode/files-text/compare-initial', tmp = '/tmp/opencode/text-compare-audit', out = path.join(repo, 'evidence/text-live-followup/compare');
const sha = b => createHash('sha256').update(b).digest('hex'), json = p => JSON.parse(fs.readFileSync(p));
const rows = json(path.join(base, 'report.json')), prov = json(path.join(base, 'provenance.json'));
assert.equal(sha(fs.readFileSync(path.join(base, 'report.json'))), prov.reportSha256);
const prior = json(path.join(tmp, 'previous-app.json'));
const priorReport = json(path.join(repo, 'evidence/files-live-followup/compare/report.json'));
const priorProvenance = json(path.join(repo, 'evidence/files-live-followup/compare/provenance.json'));
assert.equal(sha(fs.readFileSync(path.join(repo, 'evidence/files-live-followup/compare/report.json'))), priorProvenance.reportSha256);
function image(file, receipt) {
  const bytes = fs.readFileSync(file); assert.equal(sha(bytes), receipt.sha256);
  if (receipt.bytes !== undefined) assert.equal(bytes.length, receipt.bytes);
  const im = PNG.sync.read(bytes, { checkCRC: true }); assert.equal(im.width, 2880); assert.equal(im.height, 1800); return im;
}
function raw(a, b, rect = [0, 0, 2880, 1800]) {
  let count = 0, x0 = rect[2], y0 = rect[3], x1 = 0, y1 = 0;
  for (let y = rect[1]; y < rect[3]; y++) for (let x = rect[0]; x < rect[2]; x++) {
    const i = (y * 2880 + x) * 4;
    if (a.data[i] === b.data[i] && a.data[i+1] === b.data[i+1] && a.data[i+2] === b.data[i+2] && a.data[i+3] === b.data[i+3]) continue;
    count++; x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x+1); y1 = Math.max(y1, y+1);
  }
  return { rawPixels: count, rgbaExact: count === 0, bounds: count ? [x0, y0, x1, y1] : null };
}
const regions = [['header', [0,0,2880,150]], ['sidebar', [0,150,754,1800]], ['content', [754,150,2880,1800]]];
function compare(a, b) {
  const diff = new PNG({ width: 2880, height: 1800 });
  const count = pixelmatch(a.data, b.data, diff.data, 2880, 1800, { threshold: 0.15 });
  const pieces = regions.map(([name, rect]) => {
    let n = 0;
    for (let y = rect[1]; y < rect[3]; y++) for (let x = rect[0]; x < rect[2]; x++) {
      const i = (y * 2880 + x) * 4;
      if (diff.data[i] === 255 && diff.data[i+1] === 0 && diff.data[i+2] === 0) n++;
    }
    return { name, rect, thresholdPixels: n, ...raw(a, b, rect) };
  });
  assert.equal(pieces.reduce((s, r) => s + r.thresholdPixels, 0), count);
  return { diff, thresholdPixels: count, exactPct: 100 * count / 5184000, roundedPct: +(100 * count / 5184000).toFixed(2), ...raw(a,b), regions: pieces };
}
const results = rows.map(row => {
  const a = image(path.join(base, row.files.app.file), row.files.app), result = { name: row.name, appRGBA: sha(a.data), frozen: null, prior: null };
  if (!row.status) {
    const b = image(path.join(base, row.files.design.file), row.files.design), recordedDiff = image(path.join(base, row.files.diff.file), row.files.diff);
    const { diff, ...counts } = compare(a,b), bytes = PNG.sync.write(diff);
    assert.equal(counts.roundedPct, row.diffPct); assert.equal(sha(bytes), row.files.diff.sha256); assert.equal(bytes.length, row.files.diff.bytes); assert(diff.data.equals(recordedDiff.data));
    result.frozen = { ...counts, referenceRGBA: sha(b.data), diffPNGBytesReproduced: true };
  } else assert.equal(row.status, 'no-design-shot');
  const previous = prior.find(p => p.name === row.name);
  if (previous) {
    const old = image(previous.file, previous), oldRow = priorReport.find(p => p.name === row.name);
    assert.equal(sha(old.data), previous.rgbaSHA256); assert.deepEqual(row.reference, oldRow.reference);
    const { diff: _diff, ...counts } = compare(a,old);
    result.prior = { ...counts, archive: previous.archive, archiveSHA256: previous.archiveSHA256, originalAppSHA256: oldRow.files.app.sha256, originalCapturedAt: oldRow.capturedAt, rgbaSHA256: sha(old.data) };
  }
  return result;
});
const dependencies = ['pngjs','pixelmatch'].map(name => ({ name, entry: require.resolve(name), sha256: sha(fs.readFileSync(require.resolve(name))) }));
fs.writeFileSync(path.join(out,'metrics.json'), JSON.stringify({ threshold: 0.15, pixelsPerFrame: 5184000, policy: 'Original whole-frame pixelmatch metrics reproduced exactly. Rectangles partition the unshifted frames for diagnosis only; no masking or tolerance change.', priorReportSHA256: priorProvenance.reportSha256, priorClock: priorProvenance.clock, dependencies, rows: results }, null, 2)+'\n');
console.log(JSON.stringify(results.map(r => ({ name: r.name, frozen: r.frozen && { count: r.frozen.thresholdPixels, raw: r.frozen.rawPixels, pct: r.frozen.exactPct, content: r.frozen.regions[2] }, prior: r.prior && { count: r.prior.thresholdPixels, raw: r.prior.rawPixels, content: r.prior.regions[2] } })), null, 2));
