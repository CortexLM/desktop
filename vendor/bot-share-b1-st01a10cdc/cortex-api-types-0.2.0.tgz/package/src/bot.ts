/**
 * Wire types for Cortex Bot Desktop.
 *
 * Agents on the wire are mascots (`/v1/mascots`). There is no `/v1/agents`
 * alias. Ids are UUID strings, not the branded `mst_` prefix — the live
 * `MascotId` brand does not match stored rows. Start from
 * `GET /v1/bot/capabilities`. See `docs/bot-desktop.md`.
 */

/** Owner-scoped resource from `/v1/mascots`; raw UUID ids. */
export interface Bot {
  readonly id: string;
  readonly name: string;
  readonly look: 'meadow' | 'teal' | 'terracotta' | 'amber' | 'plum' | 'slate';
  readonly shape: 'dots' | 'slit' | 'wink' | 'peek' | 'smile' | 'glance';
  readonly description: string;
  readonly label: string;
  readonly computer_kind: string;
  readonly status: string;
  readonly tools: readonly string[];
  readonly plugins: readonly string[];
  readonly notifications: boolean;
  readonly updated_at: string;
  readonly last_message?: { readonly sender: string; readonly text: string; readonly at: string };
  readonly is_pinned?: true;
  readonly is_hidden?: true;
}

export interface BotPage { readonly items: readonly Bot[] }

/** Only create metadata; computer/tools are backend-managed. */
export interface BotCreateRequest {
  readonly name: string;
  readonly look?: string | null;
  readonly shape?: string | null;
  readonly description?: string | null;
  readonly label?: string | null;
}

/** Null fields leave stored configuration unchanged. */
export interface BotUpdateRequest {
  readonly name?: string | null;
  readonly look?: string | null;
  readonly shape?: string | null;
  readonly description?: string | null;
  readonly label?: string | null;
  readonly notifications?: boolean | null;
  readonly plugins?: readonly string[] | null;
  readonly status?: 'awake' | 'idle' | 'hibernating' | null;
  readonly is_pinned?: boolean | null;
  readonly is_hidden?: boolean | null;
}

export interface BotDeleted { readonly deleted: true }

/** Visible retained messages only; payload remains arbitrary JSON. */
export interface BotMessage {
  readonly id: string;
  readonly sender: string;
  readonly kind: 'text' | 'question' | 'multi_select' | 'secret_request' | 'confirm' | 'notice' | 'waiting';
  readonly text: string;
  readonly payload?: unknown;
  readonly responded: boolean;
  readonly dismissed: boolean;
  readonly at: string;
}

/** At most 500 oldest retained messages; no cursor or Chat parts. */
export interface BotMessagePage { readonly items: readonly BotMessage[] }

/** Explicit original-parent turn; text is trimmed to 1-20000 code points. */
export interface BotMessageCreateRequest { readonly text: string }

/** JSON response; a quiet turn has no reply and an empty replies array. */
export interface BotMessageCreateResponse {
  readonly message: BotMessage;
  readonly replies: readonly BotMessage[];
  readonly reply?: BotMessage;
}

export interface BotTaskNoticePayload {
  readonly task_id: string;
  readonly notification_id: string;
  readonly status: 'done' | 'failed' | 'cancelled';
  readonly kind: 'executor' | 'browser' | 'computer' | 'watch_video' | 'explore' | 'research' | 'general-purpose';
}

/** `GET /v1/bot/capabilities`. Public, like the Code catalogue. */
export interface BotCapabilities {
  readonly product: 'Cortex Bot';
  readonly domain: 'cortex.foundation';
  readonly auth: {
    readonly device: '/v1/auth/device';
    readonly device_token: '/v1/auth/device/token';
    readonly refresh: '/v1/auth/refresh';
    readonly me: '/v1/me';
    readonly consents: '/v1/me/consents';
  };
  readonly agents: {
    readonly list: '/v1/mascots';
    readonly create: '/v1/mascots';
    readonly item: '/v1/mascots/{id}';
    readonly messages: '/v1/mascots/{id}/messages';
    readonly respond: '/v1/mascots/{id}/messages/{message_id}/respond';
  };
  readonly routines: {
    readonly list: '/v1/mascots/{id}/routines';
    readonly create: '/v1/mascots/{id}/routines';
    readonly item: '/v1/mascots/{id}/routines/{rid}';
    readonly pause: '/v1/mascots/{id}/routines/{rid}/pause';
    readonly resume: '/v1/mascots/{id}/routines/{rid}/resume';
    readonly tick: '/v1/mascots/{id}/routines/tick';
    readonly events: '/v1/bot/routines/events';
    readonly trigger_kinds: readonly ['cron', 'slack', 'github'];
  };
  readonly channels: {
    readonly list: '/v1/channels';
    readonly create: '/v1/channels';
    readonly item: '/v1/channels/{id}';
    readonly messages: '/v1/channels/{id}/messages';
  };
  readonly inbox: {
    readonly home: '/v1/bot/inbox';
    readonly read: '/v1/bot/inbox/read';
    readonly per_agent: '/v1/mascots/{id}/inbox';
  };
  readonly approvals: {
    readonly pending: '/v1/bot/approvals';
    readonly per_agent_pending: '/v1/mascots/{id}/approvals/pending';
    readonly rules: '/v1/mascots/{id}/approvals';
    readonly settle: '/v1/mascots/{id}/messages/{message_id}/respond';
  };
  readonly vault: {
    readonly list: '/v1/mascots/{id}/secrets';
    readonly store: '/v1/mascots/{id}/secrets';
    readonly delete: '/v1/mascots/{id}/secrets';
  };
  readonly plugins: {
    readonly catalog: '/v1/plugins/catalog';
    readonly connections: '/v1/plugins/connections';
    readonly item: '/v1/plugins/{slug}';
    readonly connect: '/v1/plugins/{slug}/connect';
    readonly surfaces: readonly ['chat', 'bot'];
    /**
     * Per-bot connector enablement. The account grant (`surfaces`) is not an
     * Always-allow for every bot the account owns (`API-33`, COR-352).
     */
    readonly connectors: '/v1/mascots/{id}/connectors';
  };
  readonly computer: {
    readonly available: boolean;
    readonly unavailable_reason?: 'compute_not_configured';
    readonly status: '/v1/mascots/{id}/computer';
    readonly hosts: readonly ['cloud', 'this_pc', 'ssh'];
    readonly web_origin_cloud_only: boolean;
    /** Mint a ticket to watch or take over. `mode` selects which. */
    readonly vnc_ticket: '/v1/mascots/{id}/computer/vnc-ticket';
    /** The websocket the ticket is redeemed on. */
    readonly vnc_signal: '/v1/mascots/{id}/computer/vnc';
    /** `view` watches; `interactive` is a takeover (keyboard and mouse). */
    readonly vnc_modes: readonly ['view', 'interactive'];
  };
  readonly realtime: {
    readonly websocket: '/v1/realtime';
    readonly sse: '/v1/realtime/events';
  };
  /**
   * The account surface a companion needs. The same group Code's catalogue
   * carries, plus the device routes this client registers itself through.
   */
  readonly privacy: {
    readonly consents: '/v1/me/consents';
    readonly export: '/v1/me/export';
    readonly deletion: '/v1/me/deletion';
    readonly mfa: '/v1/me/mfa';
    readonly devices: '/v1/me/devices';
    readonly device_item: '/v1/me/devices/{id}';
    readonly device_platforms: readonly ['ios', 'android', 'desktop', 'cli', 'web'];
  };
  readonly shares: {
    readonly preview: '/v1/bot/shares/{token}';
    readonly clone: '/v1/bot/shares/{token}/clone';
    readonly template: '/v1/mascots/{id}/share';
    readonly template_invites: '/v1/mascots/{id}/share/invites';
    readonly routine: '/v1/mascots/{id}/routines/{rid}/share';
    readonly routine_invites: '/v1/mascots/{id}/routines/{rid}/share/invites';
    readonly invites: '/v1/bot/share-invites';
    readonly invite: '/v1/bot/share-invites/{id}';
    readonly accept: '/v1/bot/share-invites/{id}/accept';
    readonly copies_independent: true;
    readonly live_link: false;
  };
}

/** `POST /v1/me/devices` — register this device, or refresh a known one. */
export interface DeviceRegister {
  /** Shown to the owner so they recognise the device. 1-64 characters. */
  readonly label: string;
  readonly platform: 'ios' | 'android' | 'desktop' | 'cli' | 'web';
}

/** `GET /v1/me/devices`. */
export interface Device {
  readonly id: string;
  readonly label: string;
  readonly platform: 'ios' | 'android' | 'desktop' | 'cli' | 'web';
  readonly created_at: string;
  readonly last_seen_at: string;
  readonly revoked: boolean;
}

export interface DeviceList {
  readonly items: readonly Device[];
  /** Platforms a client may register, so a companion does not guess. */
  readonly platforms: readonly ['ios', 'android', 'desktop', 'cli', 'web'];
}

/** `GET /v1/bot/shares/{token}` — allowlisted config, never secrets. */
export interface BotSharePreview {
  readonly kind: 'template' | 'routine';
  readonly name: string;
  readonly look: string;
  readonly shape: string;
  readonly description: string;
  readonly label: string;
  readonly plugins: readonly string[];
  readonly skills: readonly string[];
  readonly routines: readonly BotShareRoutine[];
  readonly routine?: BotShareRoutine;
  readonly copies_independent: true;
  readonly reconnect_required: true;
}

export interface BotShareRoutine {
  readonly name: string;
  readonly prompt: string;
  readonly body: string;
  readonly schedule: string;
  readonly quiet_if_empty: boolean;
  readonly trigger: {
    readonly kind: string;
    readonly event?: string;
    readonly timezone?: string;
    readonly utc_offset_minutes?: unknown;
  };
}

/** Independent copies only. No visibility, expiry or membership role. */
export interface BotShareCreateRequest { readonly mode?: string | null }

/** Optional recipient-owned target for a routine; ignored for templates. */
export interface BotShareAcceptRequest { readonly mascot_id?: string | null }

export interface BotShareInviteRequest { readonly email: string }

export interface BotShareIssued {
  readonly kind: 'template' | 'routine';
  readonly active: true;
  readonly token: string;
  readonly share_url: string;
  readonly token_issued: true;
}

export interface BotShareInvite {
  readonly email_normalized: string;
  readonly id: string;
  readonly accept_url: string;
}

export interface BotShareInviteInbox {
  readonly id: string;
  readonly kind: 'template' | 'routine';
  readonly name: string;
  readonly look: string;
  readonly description: string;
  readonly created_at: string;
}

export interface BotShareStatus {
  readonly kind: 'template' | 'routine';
  readonly active: boolean;
  readonly clone_count: number;
  readonly invites: readonly BotShareInvite[];
}

/** `POST /v1/bot/shares/{token}/clone`. */
export interface BotShareClone {
  readonly mascot_id?: string;
  readonly routine_id?: string;
  readonly copies_independent: true;
  readonly reconnect_plugins: readonly string[];
}

export type BotRoutineTriggerKind = 'cron' | 'slack' | 'github';

/** `POST /v1/mascots/{id}/routines` trigger. Slack/github require `event`. */
export interface BotRoutineTrigger {
  readonly kind: BotRoutineTriggerKind;
  readonly event?: string;
  readonly timezone?: string;
  readonly utc_offset_minutes?: number;
}

/** `POST /v1/bot/routines/events` — authenticated owner ingest, not a public webhook. */
export interface BotRoutineEventIngest {
  readonly kind: 'slack' | 'github';
  readonly event: string;
  readonly delivery_id: string;
  readonly mascot_id?: string;
}

export interface BotRoutineRun {
  readonly id: string;
  readonly status: 'running' | 'completed' | 'failed' | 'interrupted';
  readonly error_code: string | null;
  readonly created_at: string;
  readonly finished_at: string | null;
}

export interface BotChannel {
  readonly id: string;
  readonly name: string;
  readonly members: readonly string[];
}

export interface BotChannelMessage {
  readonly id: string;
  readonly from_id?: string;
  readonly text: string;
  readonly at: string;
}

export interface BotHomeInboxItem {
  readonly kind: string;
  readonly id: string;
  readonly mascot_id: string;
  readonly from_id?: string;
  readonly text?: string;
  readonly tool_name?: string;
  readonly message_id?: string;
  readonly at: string;
  readonly unread: boolean;
}

export interface BotHomeInbox {
  readonly items: readonly BotHomeInboxItem[];
  /**
   * Mascots with an active run (awake, computer running/provisioning,
   * queued/running task, or running routine). The Working rail uses this
   * set, not every mascot that appears in `items`.
   */
  readonly working_mascot_ids: readonly string[];
}

export interface BotInboxRead {
  readonly item_ids?: readonly string[];
  readonly all?: boolean;
  /**
   * When true, clear `read_at` so the row is unread again. `all` is refused
   * in that mode — mark-all only clears Unread, never parked work.
   */
  readonly unread?: boolean;
}

/**
 * Parked tool waiting on the owner. Never includes `arguments`.
 * Settle via `POST /v1/mascots/{id}/messages/{message_id}/respond`.
 */
export interface BotPendingApproval {
  readonly id: string;
  readonly mascot_id: string;
  readonly tool_name: string;
  readonly created_at: string;
  /** Confirm widget id. Absent on rows parked before the widget was stamped. */
  readonly message_id?: string;
}

/** `GET /v1/mascots/{id}/approvals`. Never includes tool arguments. */
export interface BotApprovalRule {
  readonly id: string;
  readonly effect: string;
  readonly match_kind: string;
  readonly match_value: string;
}

/** `GET /v1/mascots/{id}/secrets` — field names only. Never `value`. */
export interface BotVaultItem {
  readonly field: string;
  readonly updated_at: string;
}

/**
 * Why a per-bot connector switch cannot be turned on.
 *
 * Mirrors `blocked_reason` in `server/src/api/bot-connectors.ts`. Absent
 * means the switch is live. `account_off` is the account grant
 * (`plugin_connections.enabled_bot`); the rest are the connection's own state.
 * The frontend renders the reason rather than re-deriving the gate from
 * `status`, so both sides of the wire refuse for the same stated reason.
 */
export type BotConnectorBlockedReason =
  | 'account_off'
  | 'needs_auth'
  | 'pending'
  | 'failed'
  | 'disabled';

/**
 * One connected app as one bot sees it.
 *
 * The account's connection flattened, plus this bot's own answer.
 * `GET /v1/mascots/{id}/connectors`, `PUT …/connectors/{connection_id}`.
 */
export interface BotConnector {
  readonly id: string;
  readonly slug: string;
  readonly provider: string;
  readonly status: 'pending' | 'active' | 'needs_auth' | 'failed' | 'disabled';
  readonly status_reason?: string;
  readonly surfaces: { readonly chat: boolean; readonly bot: boolean };
  readonly connected_at?: string;
  readonly updated_at: string;
  /** Off unless a per-bot row says otherwise. Default is off. */
  readonly bot_enabled: boolean;
  /** Absent when the switch is live. */
  readonly blocked_reason?: BotConnectorBlockedReason;
}

export interface BotConnectorList {
  readonly items: readonly BotConnector[];
}
