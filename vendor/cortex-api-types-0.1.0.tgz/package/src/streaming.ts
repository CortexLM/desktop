/**
 * Server-sent events for a streaming response, and the resumable reader.
 *
 * # Why resumable
 *
 * A chat response takes tens of seconds and an agent run takes minutes. A page
 * refresh, a tab switch on mobile, or a laptop lid closing mid-answer must not
 * lose it — from the user's side that is indistinguishable from the product
 * having crashed.
 *
 * So every event carries a monotonic `id`, the server buffers them, and a
 * reconnect sends `Last-Event-ID` to resume from where it stopped. The browser's
 * built-in `EventSource` does this automatically but cannot send an
 * `Authorization` header, which is why {@link readStream} is written over `fetch`
 * instead.
 *
 * # The framing
 *
 * SSE frames are separated by a blank line, and a `data:` payload may span
 * several lines. The parser below buffers until it sees the separator, because a
 * chunk boundary falling inside a frame is not an edge case — it is what happens
 * whenever a message is longer than a TCP segment.
 */

import type {
  ArtifactId,
  ChatCanvasId,
  ConversationId,
  MessageBlockId,
  MessageId,
  ToolInvocationId,
} from './ids.js';

/** Tokens of the assistant's answer. */
export interface TextDeltaEvent {
  readonly type: 'text_delta';
  readonly message_id: MessageId;
  readonly delta: string;
}

/**
 * Tokens of the model's reasoning.
 *
 * A separate event rather than part of `text_delta`, because the UI renders it
 * collapsed behind "Thought for 9 seconds" and it is excluded from the input to
 * context compaction.
 */
export interface ReasoningDeltaEvent {
  readonly type: 'reasoning_delta';
  readonly message_id: MessageId;
  readonly delta: string;
}

/** Reasoning finished; the elapsed time is what the collapsed header shows. */
export interface ReasoningDoneEvent {
  readonly type: 'reasoning_done';
  readonly message_id: MessageId;
  readonly duration_ms: number;
}

/** A tool has started. Rendered as a `RUNNING` row. */
export interface ToolStartEvent {
  readonly type: 'tool_start';
  readonly invocation_id: ToolInvocationId;
  readonly tool_name: string;
  /** One line for the row, e.g. `Searched the web`. */
  readonly label: string;
}

/** A tool finished. Rendered as `DONE` or `ERROR`. */
export interface ToolEndEvent {
  readonly type: 'tool_end';
  readonly invocation_id: ToolInvocationId;
  readonly outcome: 'ok' | 'error' | 'timeout' | 'refused' | 'interrupted';
  readonly duration_ms: number;
  /**
   * Client-safe failure summary, bounded by the server. Never a raw upstream
   * error: an unbounded error body stacks across retries.
   */
  readonly error_detail?: string;
}

/** Structured tool output for the expanded row: a table, an extract, a preview. */
export interface ToolResultEvent {
  readonly type: 'tool_result';
  readonly invocation_id: ToolInvocationId;
  readonly payload: unknown;
  /** Set when the result was too large for the context window and was spilled. */
  readonly truncated_chars?: number;
}

/**
 * A source the assistant used. Renders the numbered inline citation.
 *
 * Identified by a block id rather than a citation id, because a citation *is* a
 * `message_blocks` row with `kind = 'citation'` — there is no separate citation
 * table and therefore no separate identifier space. Inventing one here is what
 * `scripts/check-type-drift.mjs` caught on its first run.
 */
export interface CitationEvent {
  readonly type: 'citation';
  readonly block_id: MessageBlockId;
  readonly index: number;
  readonly url: string;
  readonly title: string;
  readonly domain: string;
  /** Present on Deep Research citations when the source text was in hand. */
  readonly quote?: string;
  /** Deep Research grouping: `web`, `connector`, or `project`. Optional so older frames still validate. */
  readonly group?: string;
}

/** A file the assistant produced. Renders the file card. */
export interface ArtifactEvent {
  readonly type: 'artifact';
  readonly artifact_id: ArtifactId;
  readonly filename: string;
  readonly content_type: string;
  readonly byte_size: number;
}

/**
 * Crisis resources, delivered mid-stream.
 *
 * A stream event rather than only an error, because the detection can fire on a
 * turn that otherwise succeeds — the concern tier attaches resources to a normal
 * answer instead of replacing it. Render this prominently regardless of what else
 * arrives.
 */
export interface SafetyNoticeEvent {
  readonly type: 'safety_notice';
  readonly severity: 'concern' | 'acute';
  readonly message: string;
  readonly referral: {
    readonly name: string;
    readonly contact: string;
    readonly note: string;
  };
}

/**
 * The "you are talking to an AI" disclosure.
 *
 * Required at the start of a conversation and every three hours by New York GBL
 * Article 47, for every user rather than only minors. `blocking` says whether it
 * must be shown before the answer or alongside it.
 */
export interface DisclosureEvent {
  readonly type: 'disclosure';
  readonly reason: 'conversation_start' | 'periodic_reminder' | 'direct_question';
  readonly text: string;
  readonly blocking: boolean;
}

/** Usage and routing for the completed turn. */
export interface UsageEvent {
  readonly type: 'usage';
  readonly message_id: MessageId;
  readonly input_tokens: number;
  readonly output_tokens: number;
  /** What the backend reported serving from its prefix cache. */
  readonly cached_tokens: number;
  readonly reasoning_tokens?: number;
  /**
   * Which branch the router took: `prefix_hit`, `prefix_rejected_load`,
   * `least_loaded`, `only_candidate` or `fallback`. Exposed because the server
   * mirrors OpenAI's contract — affinity influences routing and does not
   * guarantee a cache hit — so a client that cares can see what happened.
   */
  readonly routing_reason?: string;
}

export interface ResearchScope {
  readonly domains?: readonly string[];
  /**
   * Marketplace slugs. Omitted keeps Chat read-oriented apps; `[]` skips
   * them. Those two must not be treated as the same.
   */
  readonly connectors?: readonly string[];
  readonly project_sources?: boolean;
}

/**
 * The visible Deep Research plan. Chat only — not a Code worklog.
 *
 * Rendered as an outline the user can adjust. Tool activity that produced
 * it is not part of this event.
 */
export interface ResearchPlanEvent {
  readonly type: 'research_plan';
  readonly message_id: MessageId;
  readonly title: string;
  readonly questions: readonly string[];
  readonly outline: readonly string[];
  /** Mermaid flowchart of the plan. Optional so older frames still validate. */
  readonly diagram?: string;
  /** Trusted sources for this run. Optional so older frames still validate. */
  readonly scope?: ResearchScope;
}

/**
 * The conversation was compacted so the turn could continue.
 *
 * The summary replaces a span of older messages. The last user ask, an
 * active Deep Research plan, and open artifact / child ids are kept.
 */
export interface CompactionSummaryEvent {
  readonly type: 'compaction_summary';
  readonly message_id: MessageId;
  readonly summary: string;
  readonly replaced_message_count: number;
}

/**
 * A Chat document sidecar was created or updated.
 *
 * Opens the document rail. The body is not on the event — fetch the canvas.
 */
export interface CanvasUpdatedEvent {
  readonly type: 'canvas_updated';
  readonly conversation_id: ConversationId;
  readonly canvas_id: ChatCanvasId;
  readonly title: string;
}

/**
 * One short product-language status while Deep Research is running.
 *
 * Never a tool name, env var, provider, or transport phrase.
 */
export interface ResearchStatusEvent {
  readonly type: 'research_status';
  readonly message_id: MessageId;
  readonly label: string;
}

/** The turn is complete. */
export interface DoneEvent {
  readonly type: 'done';
  readonly message_id: MessageId;
  readonly finish_reason: 'stop' | 'length' | 'tool_calls' | 'interrupted' | 'error';
  /**
   * A canned turn's card, when it drew one (the Chat `/link` signing card).
   * The same JSON is stored on the message, so a reload redraws it.
   */
  readonly metadata?: BountyLinkCard | BountyTermsCard;
}

/** Consent prompt only. Current terms are fetched, never frozen in a transcript. */
export interface BountyTermsCard {
  readonly card: 'bounty_terms';
  readonly hotkey: string;
}

/** The `/link <ss58>` signing card. Public challenge bytes; never a secret. */
export interface BountyLinkCard {
  readonly card: 'bounty_link';
  readonly hotkey: string;
  readonly nonce: string;
  /** The exact line to sign: `cortex-bounty-v1|{account_id}|{nonce}|{exp}`. */
  readonly payload: string;
  readonly expires_at: string;
  readonly submit: '/v1/bounty/pair';
}

/**
 * The turn failed.
 *
 * Carried in-band rather than as an HTTP status, because by the time it happens
 * the response has already begun with a 200. A client that only inspects the
 * status code will believe a failed turn succeeded.
 */
export interface ErrorEvent {
  readonly type: 'error';
  readonly code: string;
  readonly detail: string;
  readonly request_id: string;
}

/**
 * Cortex-Image-1 progress. The enhanced prompt never appears here —
 * only the status the Chat loader needs, and the Library file when done.
 *
 * `queued` is the prompt being improved, `generating` is the cluster call.
 * A failure carries what the card has to be able to say: which code, which
 * request to quote, and whether the day's allowance was given back.
 */
export interface ImageGenerationEvent {
  readonly type: 'image_generation';
  readonly generation_id: string;
  readonly status: 'queued' | 'generating' | 'done' | 'error';
  readonly file_id?: string;
  readonly filename?: string;
  readonly content_type?: string;
  readonly byte_size?: number;
  /** How long the generation took, on `done`. */
  readonly duration_ms?: number;
  readonly error_code?: string;
  readonly request_id?: string;
  /** Whether the failure returned the `images_per_day` charge. */
  readonly refunded?: boolean;
  readonly remaining?: number;
  readonly limit?: number;
  readonly plan?: string;
}

/**
 * A Chat `python` `outputs/` file saved to the Library (`API-32`).
 *
 * `generating` is emitted before ingest. `ready` names the Library file.
 * `failed` is a persist miss, not a silent skip. Distinct from
 * {@link ImageGenerationEvent} (Cortex-Image-1).
 *
 * `id` is the python run (`py_{assistant_message_id}`), shared by every
 * output of that call. `file_id` is the Library row for one saved file.
 */
export interface GeneratedFileEvent {
  readonly type: 'generated_file';
  readonly id: string;
  readonly status: 'generating' | 'ready' | 'failed';
  readonly file_id?: string;
  readonly filename?: string;
  readonly content_type?: string;
  readonly byte_size?: number;
  readonly artifact_kind?: string;
  readonly error_code?: string;
  readonly plan?: string;
  readonly used_bytes?: number;
  readonly limit_bytes?: number;
}

/** One series of a chart `render_chart` drew. One value per category, in order. */
export interface ChartSeries {
  readonly name: string;
  readonly values: readonly number[];
}

/**
 * A chart `render_chart` drew, announced as the tool returns.
 *
 * The event carries the validated spec, not a rendered figure: the card draws
 * the SVG from these numbers, which is the same data the stored block holds, so
 * a live turn and a reloaded transcript cannot disagree about the chart. Caps
 * are the server's (12 series, 2000 points) and are enforced before this is
 * emitted.
 */
export interface ChartEvent {
  readonly type: 'chart';
  readonly message_id: string;
  readonly chart: {
    readonly kind: 'bar' | 'line' | 'area' | 'pie' | 'scatter';
    readonly title?: string;
    readonly categories: readonly string[];
    readonly series: readonly ChartSeries[];
    readonly unit?: string;
  };
}

/**
 * BitMind origin verification. The card is driven by these events;
 * the enhanced / partner payload never appears here.
 *
 * `queued` / `checking` hold assistant copy. `done` carries the verdict
 * the Paper card paints. `error` names a Paper code
 * (`origin_check_failed`, `origin_check_unavailable`, `network_error`).
 */
export interface OriginCheckEvent {
  readonly type: 'origin_check';
  readonly check_id: string;
  readonly status: 'queued' | 'checking' | 'done' | 'error';
  readonly verdict?: 'camera' | 'generated' | 'uncertain';
  readonly confidence?: number;
  readonly similarity?: number;
  readonly duration_ms?: number;
  readonly has_content_credentials?: boolean;
  readonly file_id?: string;
  readonly filename?: string;
  readonly media_kind?: 'image' | 'video';
  readonly content_type?: string;
  readonly duration_label?: string;
  readonly error_code?: string;
  readonly request_id?: string;
}

/** Aggregated metric chart. Paths are opaque ids; points are label+value only. */
export interface DataDashboardEvent {
  readonly type: 'data_dashboard';
  readonly dashboard_id: string;
  readonly status: 'queued' | 'loading' | 'done' | 'error';
  readonly title?: string;
  readonly metric?: string;
  readonly source?: string;
  readonly unit?: string;
  readonly points?: readonly { readonly label: string; readonly value: number }[];
}

/** Exact live action. Decisions use the conversation or Code permissions route.
 * Older clients must fail closed when they cannot render this event. */
export interface PermissionRequiredEvent {
  readonly type: 'permission_required';
  readonly invocation_id: ToolInvocationId;
  /** Whether this pending action could be covered by a Code session grant. */
  readonly session_grant_available?: boolean;
  /** One-line sentence naming the exact action (command, path, dest). */
  readonly exact_action_preview?: string;
  /** Unified diff for a proposed `write_file` / `edit_file`. Absent until approved. */
  readonly proposed_diff?: string;
  readonly path?: string;
  readonly prompt: {
    readonly id: string;
    readonly session_id: string;
    readonly tool_name: string;
    readonly summary: string;
    readonly detail: string;
    readonly decision?: 'allow' | 'always' | 'deny';
    readonly created_at: string;
    readonly scope?: 'exact' | 'session';
    readonly expires_at?: string;
    readonly session_grant_available?: boolean;
    readonly exact_action_preview?: string;
    readonly proposed_diff?: string;
    readonly path?: string;
  };
}

/** Any event on a message stream. Discriminated on `type`. */
export type StreamEvent =
  | TextDeltaEvent
  | ReasoningDeltaEvent
  | ReasoningDoneEvent
  | ToolStartEvent
  | ToolEndEvent
  | ToolResultEvent
  | PermissionRequiredEvent
  | CitationEvent
  | ArtifactEvent
  | SafetyNoticeEvent
  | DisclosureEvent
  | ResearchPlanEvent
  | ResearchStatusEvent
  | CompactionSummaryEvent
  | CanvasUpdatedEvent
  | UsageEvent
  | ImageGenerationEvent
  | GeneratedFileEvent
  | OriginCheckEvent
  | ChartEvent
  | DataDashboardEvent
  | DoneEvent
  | ErrorEvent;

/** One parsed SSE frame. */
export interface SseFrame {
  /** The `id:` field. Send it back as `Last-Event-ID` to resume. */
  readonly id?: string;
  readonly event?: string;
  readonly data: string;
}

/**
 * Incremental SSE frame parser.
 *
 * Stateful on purpose. A chunk boundary falling inside a frame is not an edge
 * case, it is what happens whenever a message exceeds a TCP segment, so a parser
 * that assumes one chunk is one frame drops data under exactly the conditions
 * that matter.
 */
export class SseParser {
  #buffer = '';

  /** Feeds a chunk and returns whatever frames completed. */
  push(chunk: string): SseFrame[] {
    this.#buffer += chunk;
    const frames: SseFrame[] = [];

    // Frames are separated by a blank line. `\r\n\r\n` is handled because a
    // proxy may normalise line endings, and dropping those frames would look
    // like an intermittent stall.
    for (;;) {
      const match = /\r?\n\r?\n/.exec(this.#buffer);
      if (match === null || match.index === undefined) break;

      const raw = this.#buffer.slice(0, match.index);
      this.#buffer = this.#buffer.slice(match.index + match[0].length);

      const frame = parseFrame(raw);
      if (frame !== undefined) frames.push(frame);
    }

    return frames;
  }

  /**
   * Whether a partial frame is buffered.
   *
   * A non-empty buffer at end of stream means the connection was cut mid-frame,
   * which is a resume rather than a completion.
   */
  get hasPartialFrame(): boolean {
    return this.#buffer.trim().length > 0;
  }
}

/**
 * Reads an SSE body as JSON objects, without the Chat `StreamEvent` union.
 *
 * `GET /v1/realtime/events` is this shape: it stays open until the client
 * aborts, and it never sends Chat's terminal `done`. Feeding it through
 * {@link readStream} would throw `IncompleteStreamError` on a clean close
 * and drop every frame that is not a turn event.
 */
export async function* readSseJson(
  response: Response,
  options: ReadStreamOptions = {},
): AsyncGenerator<unknown, void, undefined> {
  const body = response.body;
  if (body === null) {
    throw new Error('the response has no body, so it cannot be streamed');
  }

  const reader = body.pipeThrough(new TextDecoderStream()).getReader();
  const parser = new SseParser();
  let lastDeliveredId: string | undefined = options.lastEventId;

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;

      for (const frame of parser.push(value)) {
        let decoded: unknown;
        try {
          decoded = JSON.parse(frame.data);
        } catch {
          options.onDiscardedFrame?.('malformed_json');
          continue;
        }

        yield decoded;
        if (frame.id !== undefined) {
          lastDeliveredId = frame.id;
          options.onEventId?.(frame.id);
        }
      }
    }

    if (parser.hasPartialFrame) {
      throw new IncompleteStreamError('the connection closed mid-frame', lastDeliveredId);
    }
  } finally {
    // Cancel abandoned bodies; cleanup failure must not replace the original error.
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

function parseFrame(raw: string): SseFrame | undefined {
  let id: string | undefined;
  let event: string | undefined;
  const dataLines: string[] = [];

  for (const line of raw.split(/\r?\n/)) {
    // A leading colon is a comment. Servers send these as keep-alives, and
    // treating one as data would produce a JSON parse error every 15 seconds.
    if (line.startsWith(':')) continue;

    const colon = line.indexOf(':');
    const field = colon === -1 ? line : line.slice(0, colon);
    // One optional space after the colon is stripped, per the SSE spec. Getting
    // this wrong prefixes every payload with a space.
    const value = colon === -1 ? '' : line.slice(colon + 1).replace(/^ /, '');

    switch (field) {
      case 'id':
        id = value;
        break;
      case 'event':
        event = value;
        break;
      case 'data':
        dataLines.push(value);
        break;
      default:
        break;
    }
  }

  if (dataLines.length === 0) return undefined;
  // Multi-line data is joined with newlines, not concatenated.
  return { ...(id !== undefined ? { id } : {}), ...(event !== undefined ? { event } : {}), data: dataLines.join('\n') };
}

/**
 * Raised when a stream ends without completing.
 *
 * Carries the last event id that was actually *delivered to the consumer*, so a
 * reconnect resumes from a point the caller has genuinely seen. Resuming from a
 * later id silently skips content, which for a chat answer means a paragraph
 * quietly going missing.
 */
export class IncompleteStreamError extends Error {
  /** Resume point: the last id whose event was validated and yielded. */
  readonly lastEventId: string | undefined;

  constructor(reason: string, lastEventId: string | undefined) {
    super(`the stream ended without completing: ${reason}`);
    this.name = 'IncompleteStreamError';
    this.lastEventId = lastEventId;
  }
}

/** Options for {@link readStream}. */
export interface ReadStreamOptions {
  /** Resume point from a previous attempt. */
  readonly lastEventId?: string;
  readonly signal?: AbortSignal;
  /**
   * Called with the id of each event **after** it has been decoded and
   * validated.
   *
   * Deliberately not called for a frame that fails to parse or fails validation.
   * Advancing a persisted resume cursor past data the consumer never received
   * loses it permanently on reconnect.
   */
  readonly onEventId?: (id: string) => void;
  /**
   * Called for a frame that could not be used, so a caller can count them.
   *
   * A handful is normal on a flaky network. A steady rate means a version skew
   * between client and server, which is worth an alert rather than a silent
   * discard.
   */
  readonly onDiscardedFrame?: (reason: 'malformed_json' | 'failed_validation' | 'unknown_type') => void;
}

/**
 * Permitted values for the fields a consumer switches on.
 *
 * Checked rather than accepted as any string. A consumer that switches on
 * `outcome` or `finish_reason` and receives an unlisted value falls through its
 * exhaustive branch to nothing — which is the same failure the union was supposed
 * to prevent, arriving through the runtime door instead.
 */
const ENUMS = {
  tool_outcome: ['ok', 'error', 'timeout', 'refused', 'interrupted'],
  severity: ['concern', 'acute'],
  disclosure_reason: ['conversation_start', 'periodic_reminder', 'direct_question'],
  finish_reason: ['stop', 'length', 'tool_calls', 'interrupted', 'error'],
  image_generation_status: ['queued', 'generating', 'done', 'error'],
  generated_file_status: ['generating', 'ready', 'failed'],
  origin_check_status: ['queued', 'checking', 'done', 'error'],
  origin_check_verdict: ['camera', 'generated', 'uncertain'],
  chart_kind: ['bar', 'line', 'area', 'pie', 'scatter'],
  data_dashboard_status: ['queued', 'loading', 'done', 'error'],
} as const satisfies Record<string, readonly string[]>;

function isOneOf(value: unknown, permitted: readonly string[]): boolean {
  return typeof value === 'string' && permitted.includes(value);
}

/**
 * Required fields per event type, checked before a frame is yielded.
 *
 * Every field an interface above declares as non-optional appears here. That is
 * not a style rule: a declared-required field that goes unchecked reaches the
 * consumer as `undefined` while typed as `string`, which is precisely the failure
 * this validation exists to prevent.
 *
 * `validators_cover_every_required_field` in `test/streaming.test.mjs` deletes
 * each required field in turn and asserts rejection, so the next field added to an
 * interface without a matching check fails a test rather than shipping.
 *
 * Greptile found `citation` missing `title` and `domain` on PR #12. Auditing the
 * rest turned up four more events with the same gap — `artifact.content_type`,
 * `usage.cached_tokens`, and `safety_notice`'s referral being only half-checked —
 * which is why the mechanical test matters more than the individual fixes.
 */
const VALIDATORS: Readonly<Record<StreamEvent['type'], (value: Record<string, unknown>) => boolean>> = {
  text_delta: (v) => isNonEmptyString(v['message_id']) && typeof v['delta'] === 'string',
  reasoning_delta: (v) => isNonEmptyString(v['message_id']) && typeof v['delta'] === 'string',
  reasoning_done: (v) => isNonEmptyString(v['message_id']) && typeof v['duration_ms'] === 'number',
  tool_start: (v) =>
    isNonEmptyString(v['invocation_id']) &&
    isNonEmptyString(v['tool_name']) &&
    typeof v['label'] === 'string',
  tool_end: (v) =>
    isNonEmptyString(v['invocation_id']) &&
    isOneOf(v['outcome'], ENUMS.tool_outcome) &&
    typeof v['duration_ms'] === 'number',
  // `payload` is `unknown`, so presence is all that can be checked — but presence
  // must be checked, because a consumer reading `.payload` off an absent key gets
  // `undefined` where the type promises a value.
  tool_result: (v) => isNonEmptyString(v['invocation_id']) && 'payload' in v,
  permission_required: (v) => {
    const prompt = v['prompt'];
    const optionalBool = (value: unknown) => value === undefined || typeof value === 'boolean';
    const optionalString = (value: unknown) => value === undefined || isNonEmptyString(value);
    return isNonEmptyString(v['invocation_id']) && isRecord(prompt) &&
      ['id', 'session_id', 'tool_name', 'summary', 'detail', 'created_at']
        .every((key) => isNonEmptyString(prompt[key])) &&
      (prompt['decision'] === undefined ||
        isOneOf(prompt['decision'], ['allow', 'always', 'deny'])) &&
      optionalBool(v['session_grant_available']) &&
      optionalString(v['exact_action_preview']) &&
      optionalString(v['proposed_diff']) &&
      optionalString(v['path']) &&
      (prompt['scope'] === undefined || isOneOf(prompt['scope'], ['exact', 'session'])) &&
      optionalString(prompt['expires_at']) &&
      optionalBool(prompt['session_grant_available']) &&
      optionalString(prompt['exact_action_preview']) &&
      optionalString(prompt['proposed_diff']) &&
      optionalString(prompt['path']);
  },
  citation: (v) =>
    isNonEmptyString(v['block_id']) &&
    typeof v['index'] === 'number' &&
    isNonEmptyString(v['url']) &&
    // Both display fields are required by the interface. A citation chip with an
    // `undefined` title renders as a blank source, which looks like a product bug
    // rather than a malformed frame.
    isNonEmptyString(v['title']) &&
    isNonEmptyString(v['domain']) &&
    (v['group'] === undefined || typeof v['group'] === 'string'),
  artifact: (v) =>
    isNonEmptyString(v['artifact_id']) &&
    isNonEmptyString(v['filename']) &&
    // Drives which viewer opens the file. Absent, the file card cannot decide
    // between Source and Preview.
    isNonEmptyString(v['content_type']) &&
    typeof v['byte_size'] === 'number',
  // The referral is required in full, not merely present. The server has no path
  // that raises a safety notice without one, so a partial referral is a corrupted
  // frame — and rendering a crisis warning with an incomplete way to get help is
  // worse than rendering nothing.
  safety_notice: (v) =>
    isOneOf(v['severity'], ENUMS.severity) &&
    typeof v['message'] === 'string' &&
    isRecord(v['referral']) &&
    isNonEmptyString(v['referral']['name']) &&
    isNonEmptyString(v['referral']['contact']) &&
    typeof v['referral']['note'] === 'string',
  disclosure: (v) =>
    isOneOf(v['reason'], ENUMS.disclosure_reason) &&
    typeof v['text'] === 'string' &&
    typeof v['blocking'] === 'boolean',
  research_plan: (v) =>
    isNonEmptyString(v['message_id']) &&
    typeof v['title'] === 'string' &&
    Array.isArray(v['questions']) &&
    v['questions'].every((item) => typeof item === 'string') &&
    Array.isArray(v['outline']) &&
    v['outline'].every((item) => typeof item === 'string') &&
    (v['scope'] === undefined || isResearchScope(v['scope'])),
  research_status: (v) => isNonEmptyString(v['message_id']) && typeof v['label'] === 'string',
  compaction_summary: (v) =>
    isNonEmptyString(v['message_id']) &&
    typeof v['summary'] === 'string' &&
    typeof v['replaced_message_count'] === 'number',
  canvas_updated: (v) =>
    isNonEmptyString(v['conversation_id']) &&
    isNonEmptyString(v['canvas_id']) &&
    typeof v['title'] === 'string',
  image_generation: (v) =>
    isNonEmptyString(v['generation_id']) &&
    isOneOf(v['status'], ENUMS.image_generation_status),
  generated_file: (v) =>
    isNonEmptyString(v['id']) &&
    isOneOf(v['status'], ENUMS.generated_file_status) &&
    (v['error_code'] === undefined || isNonEmptyString(v['error_code'])) &&
    (v['plan'] === undefined || isNonEmptyString(v['plan'])) &&
    (v['used_bytes'] === undefined || typeof v['used_bytes'] === 'number') &&
    (v['limit_bytes'] === undefined || typeof v['limit_bytes'] === 'number'),
  origin_check: (v) =>
    isNonEmptyString(v['check_id']) && isOneOf(v['status'], ENUMS.origin_check_status),
  chart: (v) =>
    isNonEmptyString(v['message_id']) && isChartSpec(v['chart']),
  data_dashboard: (v) =>
    isNonEmptyString(v['dashboard_id']) &&
    isOneOf(v['status'], ENUMS.data_dashboard_status) &&
    (v['title'] === undefined || typeof v['title'] === 'string') &&
    (v['metric'] === undefined || typeof v['metric'] === 'string') &&
    (v['source'] === undefined || typeof v['source'] === 'string') &&
    (v['unit'] === undefined || typeof v['unit'] === 'string') &&
    (v['points'] === undefined ||
      (Array.isArray(v['points']) &&
        v['points'].every(
          (point) =>
            isRecord(point) && typeof point['label'] === 'string' && typeof point['value'] === 'number',
        ))),
  usage: (v) =>
    isNonEmptyString(v['message_id']) &&
    typeof v['input_tokens'] === 'number' &&
    typeof v['output_tokens'] === 'number' &&
    // Required by the interface, and the value the routing dashboard reads. A
    // missing one silently becomes a zero cache-hit rate.
    typeof v['cached_tokens'] === 'number',
  done: (v) => isNonEmptyString(v['message_id']) && isOneOf(v['finish_reason'], ENUMS.finish_reason),
  error: (v) =>
    isNonEmptyString(v['code']) &&
    typeof v['detail'] === 'string' &&
    isNonEmptyString(v['request_id']),
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * The chart shape, checked field by field rather than trusted.
 *
 * The card draws whatever passes this, so the checks are the ones whose absence
 * would draw a wrong picture rather than a missing one: a series with a
 * different number of values than there are categories is plotted against an
 * axis that does not exist, and a non-finite value has no position at all. The
 * server refuses both (`server/src/api/chart.ts`); this is the second
 * line, for a frame from an older or newer build.
 */
function isChartSpec(value: unknown): boolean {
  if (!isRecord(value)) return false;
  if (!isOneOf(value['kind'], ENUMS.chart_kind)) return false;
  if (value['title'] !== undefined && typeof value['title'] !== 'string') return false;
  if (value['unit'] !== undefined && typeof value['unit'] !== 'string') return false;
  const categories = value['categories'];
  if (!Array.isArray(categories) || !categories.every((item) => typeof item === 'string')) {
    return false;
  }
  const series = value['series'];
  if (!Array.isArray(series) || series.length === 0) return false;
  return series.every((row) => {
    if (!isRecord(row)) return false;
    if (typeof row['name'] !== 'string') return false;
    const values = row['values'];
    return (
      Array.isArray(values) &&
      values.length === categories.length &&
      values.every((item) => typeof item === 'number' && Number.isFinite(item))
    );
  });
}

function isResearchScope(value: unknown): boolean {
  if (!isRecord(value)) return false;
  if (value['domains'] !== undefined) {
    if (!Array.isArray(value['domains']) || !value['domains'].every((item) => typeof item === 'string')) {
      return false;
    }
  }
  if (value['connectors'] !== undefined) {
    if (
      !Array.isArray(value['connectors']) ||
      !value['connectors'].every((item) => typeof item === 'string')
    ) {
      return false;
    }
  }
  if (value['project_sources'] !== undefined && typeof value['project_sources'] !== 'boolean') {
    return false;
  }
  return true;
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0;
}

/**
 * Validates a decoded frame against its variant.
 *
 * The previous version accepted any non-null object with a string `type`, which
 * meant `readStream` handed the consumer values typed as `StreamEvent` whose
 * required fields were `undefined` at runtime — a `text_delta` with no `delta`
 * typed as `string`. That defeats the point of a typed contract, since the
 * consumer's only defence was the type it had been told to trust.
 *
 * Found by Greptile on PR #9.
 *
 * An **unknown** `type` is rejected rather than passed through. That keeps an
 * older client forward-compatible — it ignores an event the server has newly
 * added — without the alternative of yielding something that does not inhabit
 * the union it is typed as.
 */
function validateEvent(
  value: unknown,
): { readonly ok: true; readonly event: StreamEvent } | { readonly ok: false; readonly reason: 'failed_validation' | 'unknown_type' } {
  if (!isRecord(value)) return { ok: false, reason: 'failed_validation' };

  const type = value['type'];
  if (typeof type !== 'string') return { ok: false, reason: 'failed_validation' };

  const validator = Object.hasOwn(VALIDATORS, type)
    ? VALIDATORS[type as StreamEvent['type']]
    : undefined;
  if (validator === undefined) return { ok: false, reason: 'unknown_type' };

  if (!validator(value)) return { ok: false, reason: 'failed_validation' };
  return { ok: true, event: value as unknown as StreamEvent };
}

/**
 * Reads a stream, yielding validated events.
 *
 * Written over `fetch` rather than `EventSource` because `EventSource` cannot
 * send an `Authorization` header, and this API takes a bearer token. The cost is
 * doing reconnection by hand.
 *
 * @throws {IncompleteStreamError} if the body ends mid-frame, or ends without a
 * terminal `done` or `error` event. Both mean the answer is truncated, and
 * returning normally would let a consumer render a half-written response as
 * finished.
 */
export async function* readStream(
  response: Response,
  options: ReadStreamOptions = {},
): AsyncGenerator<StreamEvent, void, undefined> {
  const body = response.body;
  if (body === null) {
    throw new Error('the response has no body, so it cannot be streamed');
  }

  const reader = body.pipeThrough(new TextDecoderStream()).getReader();
  const parser = new SseParser();

  // The last id actually handed to the consumer. Distinct from the last id
  // *seen*, which is the distinction that stops a resume skipping content.
  let lastDeliveredId: string | undefined = options.lastEventId;
  let sawTerminalEvent = false;

  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;

      for (const frame of parser.push(value)) {
        let decoded: unknown;
        try {
          decoded = JSON.parse(frame.data);
        } catch {
          // Skipped rather than thrown: discarding the rest of an otherwise fine
          // stream loses more than one event does. But the id is *not* recorded,
          // so a reconnect will re-request this frame.
          options.onDiscardedFrame?.('malformed_json');
          continue;
        }

        const result = validateEvent(decoded);
        if (!result.ok) {
          options.onDiscardedFrame?.(result.reason);
          continue;
        }

        if (result.event.type === 'done' || result.event.type === 'error') {
          sawTerminalEvent = true;
        }

        // The id is recorded *after* the yield, which in an async generator means
        // it is not reached until the consumer calls `next()` again. So the
        // cursor advances only once the consumer has finished with the event and
        // come back for more — a consumer that throws while rendering leaves the
        // cursor where it was, and the event is redelivered on reconnect.
        //
        // At-least-once is the right bias: redelivering a text delta duplicates a
        // few characters, whereas skipping one loses them permanently.
        yield result.event;
        if (frame.id !== undefined) {
          lastDeliveredId = frame.id;
          options.onEventId?.(frame.id);
        }
      }
    }

    // A body that ends with bytes still buffered means the connection was cut
    // between the last `data:` line and its terminating blank line. The frame is
    // lost, and reporting success here would let the consumer treat a truncated
    // answer as complete.
    if (parser.hasPartialFrame) {
      throw new IncompleteStreamError('the connection closed mid-frame', lastDeliveredId);
    }

    // A clean close with no `done` or `error` is also truncation — the server
    // always terminates a stream with one of the two.
    if (!sawTerminalEvent) {
      throw new IncompleteStreamError(
        'the connection closed before a terminal event',
        lastDeliveredId,
      );
    }
  } finally {
    // Cancel abandoned bodies; cleanup failure must not replace the original error.
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
