/**
 * Types and a typed client for the Cortex API.
 *
 * # What this package is
 *
 * The contract between the Rust backend and the web frontend. It carries the
 * request and response shapes, the streaming event union, the error union, and a
 * thin client that handles bearer tokens, problem+json parsing and resumable
 * streams.
 *
 * # What it is not
 *
 * Not the frontend. There is no React, no state management and no caching here,
 * because those are the application's decisions and a package that made them
 * would be in the way.
 *
 * # Two things worth knowing before using it
 *
 * **Errors are a discriminated union on `code`.** Switch on it and the compiler
 * checks exhaustiveness; a new server-side error becomes a type error here rather
 * than a silent fall-through to a generic branch.
 *
 * **Identifiers are branded.** A `ConversationId` is not assignable to a
 * `UserId`, which makes ID confusion between sibling resources — a routine source
 * of authorization bugs — a compile error. Use `parseId` to construct one from an
 * untrusted string.
 *
 * # Drift
 *
 * These types are hand-mirrored from `server/src`, and `npm run check-drift`
 * compares them against the Rust source. It runs in CI. Once the route handlers
 * carry their `utoipa` annotations this becomes generation from the OpenAPI
 * document, which is better; until then, a check that exists beats a generator
 * that does not.
 */

export * from './cli.js';
export * from './admin-support.js';
export * from './client.js';
export * from './errors.js';
export * from './ids.js';
export * from './streaming.js';
export * from './realtime.js';
export * from './design.js';
export * from './library.js';
export * from './projects.js';
export * from './science.js';
export * from './bot.js';
export * from './exports.js';
export * from './feedback.js';
export * from './support-automation.js';

/** Cursor-paginated collection. */
export interface Page<T> {
  readonly items: readonly T[];
  /**
   * Position to resume from. Absent on the last page.
   *
   * Opaque — pass it back verbatim and do not construct one. It encodes an
   * ordering the server is free to change, and it is validated on the way in so
   * a hand-crafted cursor cannot read across a tenant boundary.
   */
  readonly next_cursor?: string;
  readonly has_more: boolean;
}

/** Query parameters for a paginated collection. */
export interface PageRequest {
  readonly cursor?: string;
  /**
   * Items requested. Clamped by the server to 100 rather than rejected, so an
   * over-large value is corrected rather than failing the request.
   */
  readonly limit?: number;
}

/** Reasoning effort, matching the composer's Low/Medium/High control. */
export type ReasoningEffort = 'low' | 'medium' | 'high';

/** An entry in the model picker. */
export interface Model {
  /** Stable slug: `cortex-1-mini`. */
  readonly slug: string;
  /** What the picker shows, e.g. `Cortex 1 Mini`. */
  readonly display_name: string;
  /** The one-line subtitle beneath it. */
  readonly description: string;
  readonly context_tokens: number;
  readonly max_output_tokens: number;
  /** Whether the Low/Medium/High control applies. Hide it when false. */
  readonly supports_reasoning: boolean;
  readonly supports_tools: boolean;
  readonly supports_vision: boolean;
  /** Shown as a Preview mention next to the name. */
  readonly is_preview?: boolean;
  /**
   * `chat` is a completion model the picker may offer. `image` is
   * Cortex-Image-1: public for the card, never selected as a Chat slug.
   */
  readonly kind?: 'chat' | 'image';
  /** Credit on a model card, e.g. "Built on NVIDIA Cosmos". */
  readonly attribution?: string;
  /** Public banner URL for a model card. Never a credentialed URL. */
  readonly banner_url?: string;
  /**
   * What to offer when this model's quota is exhausted.
   *
   * This is what lets the plan-limit notice truthfully say another model is
   * still available, rather than only that the current one is not.
   */
  readonly fallback_slug?: string;
}

/** A plan on the pricing page. */
export interface Plan {
  readonly slug: string;
  readonly tier: 'free' | 'pro' | 'enterprise';
  readonly display_name: string;
  readonly description: string;
  /** Cents. `null` for a quote-only plan. */
  readonly monthly_price_cents: number | null;
  readonly currency: string;
  readonly is_recommended: boolean;
  readonly entitlements: readonly Entitlement[];
}

/** One capability or limit within a plan. */
export interface Entitlement {
  /** Stable key, e.g. `reasoning_runs_per_day`. */
  readonly key: string;
  /**
   * `null` means unlimited, which is distinct from `0` (forbidden). Collapsing
   * the two turns an unlimited plan into a blocked one, so check for `null`
   * explicitly rather than relying on falsiness.
   */
  readonly limit_value: number | null;
  readonly window_seconds: number | null;
}

/** Remaining allowance for one quota. */
export interface QuotaStatus {
  readonly key: string;
  readonly used: number;
  /** `null` when unlimited. */
  readonly limit: number | null;
  /** RFC 3339. Renders the countdown in the plan-limit notice. */
  readonly resets_at: string;
}

/**
 * Public bounty verdict. Pending reports are absent from public routes.
 *
 * Dedicated DTO: never includes account id, session id, email, or the report body.
 */
export type BountyVerdict =
  | 'valid'
  | 'duplicate'
  | 'already_fixed_not_prod'
  | 'invalid_malicious';

/** Current research terms and this authenticated account's versioned consent. */
export interface BountyTerms {
  readonly version: string;
  readonly title: string;
  readonly body: string;
  readonly accepted: boolean;
  readonly accepted_at?: string;
  readonly dedicated_account_recommended: boolean;
}

/** Impact required for a creditable `valid` bounty report. */
export type BountySeverity = 'trivial' | 'minor' | 'major' | 'critical';

/** One adjudicated report on the public transparency API. */
export interface PublicBountyReport {
  readonly id: string;
  readonly hotkey: string;
  readonly status: BountyVerdict;
  /** Required for scoreable `valid`; legacy detail rows may remain `null`. */
  readonly severity: BountySeverity | null;
  readonly problem_found: string;
  readonly adjudicator: string;
  readonly justification: string;
  readonly adjudicated_at: string;
  readonly created_at: string;
  /** Required exactly when `status === 'duplicate'`. */
  readonly related_report_id?: string;
  /**
   * One public-safe paragraph, present only when staff chose to publish it
   * with the verdict. Never the sealed finding.
   */
  readonly summary?: string;
}

/** `GET /v1/bounty/public/reports/{id}`. */
export interface PublicBountyReportDetail extends PublicBountyReport {
  readonly api_version: number;
  readonly generated_at: string;
  /** Revision that published this version of the report. */
  readonly revision: string;
}

/** Hotkey ranked by valid-report count. No account ids. */
export interface PublicBountyLeaderboardEntry {
  readonly hotkey: string;
  readonly valid: number;
  /**
   * The same number as `valid`, under the name the subnet's scorer reads.
   *
   * Both names are stable: this API published `valid` when the log opened and
   * CortexLM/cortex parses `valid_count`, and neither repository may break the
   * other on a rename.
   */
  readonly valid_count: number;
  readonly duplicate: number;
  readonly already_fixed_not_prod: number;
  readonly invalid_malicious: number;
  /** Every scoreable public report for this hotkey, whatever the verdict. */
  readonly total: number;
}

/**
 * Shape version carried by every public bounty payload.
 *
 * New fields are additive and do not move it, so a consumer pinned to `1`
 * keeps parsing.
 */
export const PUBLIC_BOUNTY_API_VERSION = 1;

/** `GET /v1/bounty/public/leaderboard?since=&until=` */
export interface PublicBountyLeaderboard {
  readonly api_version: number;
  readonly generated_at: string;
  /** Immutable publication snapshot aggregated by this response. */
  readonly revision: string;
  /** Echo of the window asked for, absent when the whole log was counted. */
  readonly since?: string;
  readonly until?: string;
  readonly items: readonly PublicBountyLeaderboardEntry[];
  /** The board was truncated; enumerate `/public/reports` instead. */
  readonly has_more: boolean;
}

/**
 * `GET /v1/bounty/public/reports?hotkey=&status=&since=&until=&limit=&cursor=&revision=`
 *
 * Page until `has_more` is false to hold every row in the window. `since` is
 * inclusive and `until` exclusive, so consecutive epochs neither overlap nor
 * drop a verdict.
 */
export interface PublicBountyReportPage {
  readonly api_version: number;
  readonly generated_at: string;
  /** Immutable publication snapshot used by every page in this walk. */
  readonly revision: string;
  readonly items: readonly PublicBountyReport[];
  readonly count: number;
  readonly has_more: boolean;
  /** Pass back verbatim with the same filters; do not construct one. */
  readonly next_cursor?: string;
}

/**
 * `GET /v1/bounty/public/status`
 *
 * What makes a zero readable: `adjudication_available: false` means no verdict
 * can exist on this deployment yet, and a non-zero `awaiting_adjudication`
 * with nothing published is a queue nobody worked. Neither is a scored zero.
 */
export interface PublicBountyStatus {
  readonly api_version: number;
  readonly generated_at: string;
  readonly revision: string;
  readonly adjudication_available: boolean;
  readonly published: number;
  readonly valid: number;
  readonly duplicate: number;
  readonly already_fixed_not_prod: number;
  readonly invalid_malicious: number;
  /** Distinct hotkeys with at least one adjudicated report. */
  readonly hotkeys: number;
  readonly awaiting_adjudication: number;
  /** Legacy valid rows withheld until staff records their severity. */
  readonly unpriced_valid: number;
  readonly last_adjudicated_at?: string;
  /** Published rows that carry a public summary. */
  readonly summarised: number;
}

/**
 * One `bounty_reports` row on `GET /v1/bounty/queue`.
 *
 * Staff only. Metadata — never the sealed finding. Not
 * `GET /v1/support/queue` and not `GET /v1/bounty/public/reports`.
 * `status` / `severity` stay strings so an unrecognised stored verdict
 * still lists (same shape as the owner's private report list).
 */
export interface BountyStaffQueueItem {
  readonly id: string;
  readonly hotkey: string;
  readonly account_id: string;
  readonly session_id?: string;
  readonly created_at: string;
  readonly delivered: boolean;
  readonly body_chars?: number;
  readonly source: string;
  readonly bug_report_id?: string;
  readonly status?: string;
  readonly severity?: string;
  readonly problem_found?: string;
  readonly adjudicator?: string;
  readonly justification?: string;
  readonly adjudicated_at?: string;
  readonly related_report_id?: string;
}

/** `GET /v1/bounty/queue?status=&limit=&cursor=` — staff adjudication inventory. */
export interface BountyStaffQueue {
  readonly items: readonly BountyStaffQueueItem[];
  /** Rows still awaiting a verdict, regardless of the `status` filter. */
  readonly pending: number;
  readonly has_more: boolean;
  readonly next_cursor?: string;
}
