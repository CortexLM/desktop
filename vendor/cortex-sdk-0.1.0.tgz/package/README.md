# @cortex/sdk

TypeScript SDK for the Cortex API. It is generated from the OpenAPI document
(`openapi/cortex.openapi.json`). Every public route is a typed method, grouped
by route: `client.conversations.turns.create()`, `client.mascots.routines.list()`.
A small hand-written layer adds the parts generation cannot produce:

- **Base URL.** Defaults to Cortex Cloud (`https://api.cortex.foundation`). A
  self-hosted instance passes its own origin.
- **Optional auth.** You can use a bearer token or a token function, with
  single-flight refresh on a 401. You can also start a guest session, or send no
  credentials at all to an instance that does not require login.
- **Resumable streams.** Chat and Code turns resume from `Last-Event-ID` with
  the same `Idempotency-Key`. Realtime subscriptions reconnect with backoff and
  resume from the last delivered event.
- **Typed errors.** Every failure is an `ApiError` carrying the RFC 9457
  `code`.
- **Embedded mode.** The real API runs in-process, with no port.

## Install

The package is not on npm yet. Depend on it from this repository:

```json
{ "dependencies": { "@cortex/sdk": "file:../backend/packages/sdk" } }
```

Build it first with `cd packages/sdk && npm install && npm run build`. It
depends on `@cortex/api-types`, which lives next to it.

## Quick start

```ts
import { createCortexClient, ApiError } from '@cortex/sdk';

const client = createCortexClient({
  baseUrl: 'http://127.0.0.1:8080',     // omit for Cortex Cloud
  auth: { token: () => store.accessToken, refresh: () => store.refresh() }, // optional
});

const { items } = await client.models.list();   // slugs, context, supports_reasoning, …

for await (const event of client.streamTurn({ body: { message: 'Hello', model_slug: items[0].slug } })) {
  switch (event.type) {
    case 'reasoning_delta': /* thinking */ break;
    case 'text_delta': process.stdout.write(event.delta); break;
    case 'image_generation': /* status, file_id */ break;
    case 'done': break;
  }
}
```

Without `auth`, call `await client.startGuest()` to get a guest session. Outside
a browser, the SDK keeps the session cookie in an in-memory jar.

## Calling a route

Each method takes `{ path, query, body }`. It resolves to the response body or
throws `ApiError`:

```ts
const conversation = await client.conversations.get({ path: { id: 'cnv_…' } });
await client.mascots.routines.create({ path: { id: botId }, body: { … } });

try {
  await client.code.sessions.create({ body: { repo: 'owner/name' } });
} catch (e) {
  if (e instanceof ApiError && e.code === 'entitlement_required') { /* sign in */ }
}
```

`client.http` is the underlying generated client. Use it for interceptors or
per-call `fetch` overrides.

## Streams and resume

| Method | Route | Ends |
| --- | --- | --- |
| `streamTurn({ conversationId?, body, idempotencyKey? })` | `POST /v1/conversations[/{id}]/turns` | `done` or `error` event |
| `streamCodeTurn(sessionId, { body })` | `POST /v1/code/sessions/{id}/turns` | `done` or `error` event |
| `subscribe()` | `GET /v1/realtime/events` | when `signal` aborts |
| `subscribePath(path)` | `GET /v1/mascots/{id}/events`, `/v1/code/sessions/{id}/events`, `/v1/code/runtimes/{id}/events` | when `signal` aborts |

Every stream method accepts `{ lastEventId, onEventId, onResponse, signal,
maxReconnects, retryDelayMs }`. To survive a reload, persist the id passed to
`onEventId` and pass it back later as `lastEventId`. The cursor advances only
after your loop has consumed an event, so on reconnect you may see an event
again but you never miss one. The `x-conversation-id` and `x-message-id`
headers of a new turn arrive through `onResponse`.

## Embedded mode

`server/src/embedded.ts` exposes the public router as a Fetch handler. Pass it
to the SDK as `fetch`:

```ts
import { startEmbedded } from '<backend>/server/src/embedded.ts';
const api = await startEmbedded();             // same config and datastores as cortex-api
const client = createCortexClient({ baseUrl: 'http://cortex.embedded', fetch: api.fetch });
```

It runs under Bun and still needs Postgres, Redis and OpenBao. The scheduler,
the Security pipeline and WebSockets are not started in this mode.

## Regenerating

```sh
npm run generate          # rewrite src/gen from openapi/cortex.openapi.json
npm run check-generated   # fail if src/gen differs from a fresh generation (CI)
```

Generation is deterministic: the generator version is pinned, there is a
single input file, there are no timestamps, and trailing whitespace is
stripped. Do not edit `src/gen` by hand.

## Examples and tests

- `examples/` holds runnable scripts. Run them with `npm run examples` against
  `CORTEX_URL`, which defaults to `http://127.0.0.1:8080`.
- `test/` holds integration tests against a real local backend. Start one with
  `scripts/sdk-local-backend.sh up` from the repository root.
