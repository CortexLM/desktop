/**
 * Resumable streams over the generated client.
 *
 * Two shapes, matching the server:
 *
 * - **Turn streams** (`POST …/turns`): validated `StreamEvent`s that always end
 *   with `done` or `error`. A connection that drops earlier is resumed with
 *   `Last-Event-ID` against the same endpoint and the same `Idempotency-Key`,
 *   so the server replays from its buffer instead of starting a second turn.
 * - **Event subscriptions** (`GET /v1/realtime/events`, `…/events`): JSON
 *   envelopes with no terminal frame. Reconnects forever (with backoff) until
 *   the caller aborts, resuming from the last delivered id.
 *
 * Parsing and validation are reused from `@cortex/api-types`, which already
 * guarantees the resume cursor only advances past events the consumer saw.
 */

import {
  ApiError,
  IncompleteStreamError,
  isProblem,
  readSseJson,
  readStream,
  type StreamEvent,
} from '@cortex/api-types';

export type FetchLike = (request: Request) => Promise<Response>;

export interface StreamTarget {
  readonly url: string;
  readonly method: 'GET' | 'POST';
  readonly body?: unknown;
  readonly headers: Headers;
  readonly fetch: FetchLike;
}

export interface ResumeOptions {
  /** Resume point from an earlier attempt (persist it from `onEventId`). */
  readonly lastEventId?: string;
  readonly onEventId?: (id: string) => void;
  /** Called with each response before its body is read (`x-conversation-id`, `x-message-id`). */
  readonly onResponse?: (response: Response) => void;
  readonly signal?: AbortSignal;
  /** Reconnect attempts after a dropped connection. Default 5 for turns, unlimited for subscriptions. */
  readonly maxReconnects?: number;
  /** First backoff delay; doubles per attempt up to 30 s. Default 250 ms. */
  readonly retryDelayMs?: number;
}

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => (clearTimeout(t), resolve()), { once: true });
  });

async function open(target: StreamTarget, lastEventId: string | undefined, signal?: AbortSignal): Promise<Response> {
  const headers = new Headers(target.headers);
  headers.set('accept', 'text/event-stream');
  if (lastEventId !== undefined) headers.set('last-event-id', lastEventId);
  let body: string | undefined;
  if (target.body !== undefined) {
    body = JSON.stringify(target.body);
    headers.set('content-type', 'application/json');
  }
  const response = await target.fetch(
    new Request(target.url, { method: target.method, headers, ...(body === undefined ? {} : { body }), ...(signal ? { signal } : {}) }),
  );
  if (response.ok) return response;
  let parsed: unknown;
  try {
    parsed = await response.json();
  } catch {
    parsed = undefined;
  }
  if (isProblem(parsed)) throw new ApiError(parsed);
  throw new ApiError({
    type: 'about:blank',
    title: `HTTP ${response.status}`,
    status: response.status,
    code: response.status >= 500 ? 'service_unavailable' : 'bad_request',
    request_id: response.headers.get('x-request-id') ?? 'unknown',
  });
}

/** A turn: yields `StreamEvent`s until `done`/`error`, resuming dropped connections. */
export async function* turnStream(target: StreamTarget, options: ResumeOptions = {}): AsyncGenerator<StreamEvent, void, undefined> {
  let cursor = options.lastEventId;
  const max = options.maxReconnects ?? 5;
  let delay = options.retryDelayMs ?? 250;
  for (let attempt = 0; ; attempt++) {
    const response = await open(target, cursor, options.signal);
    options.onResponse?.(response);
    try {
      yield* readStream(response, {
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        ...(options.signal ? { signal: options.signal } : {}),
        onEventId: (id) => {
          cursor = id;
          options.onEventId?.(id);
        },
      });
      return;
    } catch (error) {
      if (!(error instanceof IncompleteStreamError) || attempt >= max || options.signal?.aborted) throw error;
      cursor = error.lastEventId ?? cursor;
    }
    await sleep(delay, options.signal);
    delay = Math.min(delay * 2, 30_000);
  }
}

/** A subscription: yields JSON envelopes forever, resuming from the last delivered id. */
export async function* eventSubscription<T = unknown>(target: StreamTarget, options: ResumeOptions = {}): AsyncGenerator<T, void, undefined> {
  let cursor = options.lastEventId;
  const max = options.maxReconnects ?? Number.POSITIVE_INFINITY;
  const first = options.retryDelayMs ?? 250;
  let delay = first;
  for (let attempt = 0; !options.signal?.aborted; attempt++) {
    try {
      const response = await open(target, cursor, options.signal);
      options.onResponse?.(response);
      for await (const frame of readSseJson(response, {
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        ...(options.signal ? { signal: options.signal } : {}),
        onEventId: (id) => {
          cursor = id;
          options.onEventId?.(id);
        },
      })) {
        delay = first;
        yield frame as T;
      }
    } catch (error) {
      // Auth and validation failures will not fix themselves on a retry.
      if (error instanceof ApiError && error.status < 500 && error.status !== 429) throw error;
      if (options.signal?.aborted) return;
      if (attempt >= max) throw error;
    }
    if (attempt >= max) return;
    await sleep(delay, options.signal);
    delay = Math.min(delay * 2, 30_000);
  }
}
