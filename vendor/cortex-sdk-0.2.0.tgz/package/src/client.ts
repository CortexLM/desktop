/**
 * `createCortexClient` — the entry point.
 *
 * Wraps the generated `CortexSdk` (one namespace per route group, one method per
 * operation) with what generation cannot know: where the instance lives, how a
 * caller authenticates, and how turns and event streams resume.
 */

import { ApiError, isProblem, type Problem, type StreamEvent } from '@cortex/api-types';
import { createClient, type Client, type Config } from './gen/client/index.js';
import { CortexSdk } from './gen/sdk.gen.js';
import { codeForStatus, problemFrom, eventSubscription, turnStream, type FetchLike, type ResumeOptions } from './stream.js';

/** Cortex Cloud's public API. A self-hosted instance passes its own `baseUrl`. */
export const CORTEX_CLOUD_URL = 'https://api.cortex.foundation';

export type TokenSource = string | (() => string | null | undefined | Promise<string | null | undefined>);

export interface CortexAuth {
  /** A bearer access token, or a function returning the current one. */
  readonly token?: TokenSource;
  /**
   * Obtains a fresh token after a 401. Called at most once per request, and
   * shared between concurrent requests (single flight): the identity provider
   * rate-limits refreshes, so one expiry must not become N refreshes.
   */
  readonly refresh?: () => Promise<string | null>;
}

export interface CortexClientOptions {
  /** Defaults to {@link CORTEX_CLOUD_URL}. No trailing `/v1`: operation paths carry it. */
  readonly baseUrl?: string;
  /**
   * Optional. Omit for a self-hosted instance whose auth mode is `none`, or to
   * start a guest session with `client.startGuest()`.
   */
  readonly auth?: CortexAuth;
  /** Defaults to `globalThis.fetch`. Pass the embedded handler to skip TCP. */
  readonly fetch?: FetchLike;
  /** Extra headers sent on every request. */
  readonly headers?: Record<string, string>;
  /**
   * Keep cookies the API sets (guest session, refresh cookie) and send them back.
   * Default: on outside a browser, where `fetch` has no cookie store. In a
   * browser the platform does this (`credentials: 'include'`).
   */
  readonly cookieJar?: boolean;
}

export interface TurnInput {
  /** Continue this conversation; omit to start a new one. */
  readonly conversationId?: string;
  /** The `TurnBody` (`message`, `model_slug`, `reasoning_effort`, `attachment_ids`, …). */
  readonly body: Record<string, unknown>;
  /** Makes the turn safe to retry and resume. Generated when omitted. */
  readonly idempotencyKey?: string;
}

export interface CortexClient extends CortexSdk {
  readonly baseUrl: string;
  /** The generated low-level client (interceptors, `setConfig`). */
  readonly http: Client;
  /** Starts a guest session (`POST /v1/auth/guest`); its cookie is kept by the jar. */
  startGuest(): Promise<{ kind: string; user_id: string }>;
  /** Streams a Chat turn, resuming on a dropped connection. */
  streamTurn(input: TurnInput, options?: ResumeOptions): AsyncGenerator<StreamEvent, void, undefined>;
  /** Streams a Code session turn (`POST /v1/code/sessions/{id}/turns`). */
  streamCodeTurn(sessionId: string, input: Omit<TurnInput, 'conversationId'>, options?: ResumeOptions): AsyncGenerator<StreamEvent, void, undefined>;
  /** Subscribes to the account's realtime envelopes (`GET /v1/realtime/events`). */
  subscribe<T = unknown>(options?: ResumeOptions): AsyncGenerator<T, void, undefined>;
  /** Subscribes to any other SSE endpoint by path (bot or runtime events). */
  subscribePath<T = unknown>(path: string, options?: ResumeOptions): AsyncGenerator<T, void, undefined>;
}

const trimSlashes = (s: string) => {
  let end = s.length;
  while (end > 0 && s.charCodeAt(end - 1) === 47) end--;
  return s.slice(0, end);
};

/** `randomUUID` needs a secure context; a self-host on plain http in a browser has only `getRandomValues`. */
const randomKey = () => {
  const c = globalThis.crypto;
  if (typeof c.randomUUID === 'function') return c.randomUUID();
  return Array.from(c.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
};

/** One string per cookie. `getSetCookie` is missing in some runtimes (React Native). */
const setCookies = (headers: Headers): string[] =>
  headers.getSetCookie?.() ?? (headers.get('set-cookie')?.split(/,(?=\s*[^;=\s]+=)/) ?? []);

const expired = (line: string) => {
  if (/max-age=0/i.test(line)) return true;
  const at = /expires=([^;]+)/i.exec(line)?.[1];
  return at !== undefined && Date.parse(at) <= Date.now();
};

/**
 * Wraps fetch with bearer auth, single-flight refresh on 401, and an optional cookie jar.
 *
 * A refreshed token is used until `auth.token` (when it is a function) returns
 * a different one, so a caller's own store stays authoritative.
 */
function authedFetch(base: FetchLike, auth: CortexAuth | undefined, jar: Map<string, string> | undefined, extra: Record<string, string>): FetchLike {
  let refreshing: Promise<string | null> | undefined;
  let refreshed: { from: string | null | undefined; token: string } | undefined;
  const current = async (): Promise<string | null | undefined> => {
    const t = auth?.token;
    const own = typeof t === 'function' ? await t() : t;
    if (refreshed && refreshed.from === own) return refreshed.token;
    refreshed = undefined;
    return own;
  };
  const send = async (request: Request, token: string | null | undefined): Promise<Response> => {
    const req = request.clone();
    for (const [k, v] of Object.entries(extra)) if (!req.headers.has(k)) req.headers.set(k, v);
    if (token && !req.headers.has('authorization')) req.headers.set('authorization', `Bearer ${token}`);
    if (jar && jar.size > 0) req.headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
    const res = await base(req);
    if (jar) {
      for (const line of setCookies(res.headers)) {
        const pair = line.split(';')[0] ?? '';
        const eq = pair.indexOf('=');
        if (eq <= 0) continue;
        const name = pair.slice(0, eq).trim();
        const value = pair.slice(eq + 1).trim();
        if (value === '' || expired(line)) jar.delete(name);
        else jar.set(name, value);
      }
    }
    return res;
  };
  return async (request) => {
    const used = await current();
    const res = await send(request, used);
    if (res.status !== 401 || !auth?.refresh) return res;
    await res.body?.cancel();
    // Another request may have refreshed while this one was in flight.
    const now = await current();
    if (now && now !== used) return send(request, now);
    const own = typeof auth.token === 'function' ? await auth.token() : auth.token;
    refreshing ??= auth.refresh().finally(() => (refreshing = undefined));
    const next = await refreshing;
    if (next === null) return send(request, used);
    refreshed = { from: own, token: next };
    return send(request, next);
  };
}

export function createCortexClient(options: CortexClientOptions = {}): CortexClient {
  const baseUrl = trimSlashes(options.baseUrl ?? CORTEX_CLOUD_URL);
  const inBrowser = typeof (globalThis as { document?: unknown }).document !== 'undefined';
  const jar = (options.cookieJar ?? !inBrowser) ? new Map<string, string>() : undefined;
  const rawFetch: FetchLike = options.fetch ?? ((r) => globalThis.fetch(r));
  const fetch = authedFetch(rawFetch, options.auth, jar, options.headers ?? {});

  const config: Config = {
    baseUrl,
    fetch: (input: RequestInfo | URL, init?: RequestInit) => fetch(input instanceof Request ? input : new Request(input, init)),
    credentials: 'include',
    throwOnError: true,
    responseStyle: 'data',
  };
  const http = createClient(config);
  // Every failure surfaces as `ApiError`, discriminated on `code`, whether the
  // body was a problem document or something a proxy wrote.
  // No response means the request never completed (abort, network): keep the original error.
  http.interceptors.error.use((error, response) => {
    if (error instanceof ApiError || response === undefined) return error;
    if (isProblem(error)) return new ApiError(error);
    const problem = {
      type: 'about:blank',
      title: `HTTP ${response.status}`,
      status: response.status,
      code: codeForStatus(response.status),
      request_id: response.headers.get('x-request-id') ?? 'unknown',
    } as Problem;
    return new ApiError(problem);
  });
  const sdk = new CortexSdk({ client: http }) as CortexClient;

  const target = (method: 'GET' | 'POST', path: string, body?: unknown, headers: Record<string, string> = {}) => ({
    url: `${baseUrl}${path}`,
    method,
    ...(body === undefined ? {} : { body }),
    headers: new Headers(headers),
    fetch,
  });

  return Object.assign(sdk, {
    baseUrl,
    http,
    async startGuest() {
      const res = await fetch(new Request(`${baseUrl}/v1/auth/guest`, { method: 'POST', credentials: 'include' }));
      if (!res.ok) throw await problemFrom(res);
      return (await res.json()) as { kind: string; user_id: string };
    },
    streamTurn(input: TurnInput, opts?: ResumeOptions) {
      const path = input.conversationId ? `/v1/conversations/${encodeURIComponent(input.conversationId)}/turns` : '/v1/conversations/turns';
      return turnStream(target('POST', path, input.body, { 'idempotency-key': input.idempotencyKey ?? randomKey() }), opts);
    },
    streamCodeTurn(sessionId: string, input: Omit<TurnInput, 'conversationId'>, opts?: ResumeOptions) {
      const path = `/v1/code/sessions/${encodeURIComponent(sessionId)}/turns`;
      return turnStream(target('POST', path, input.body, { 'idempotency-key': input.idempotencyKey ?? randomKey() }), opts);
    },
    subscribe<T>(opts?: ResumeOptions) {
      return eventSubscription<T>(target('GET', '/v1/realtime/events'), opts);
    },
    subscribePath<T>(path: string, opts?: ResumeOptions) {
      return eventSubscription<T>(target('GET', path), opts);
    },
  });
}
