/**
 * Resumable streams over the generated client.
 *
 * Two shapes, matching the server:
 *
 * - **Turn streams** (`POST …/turns`): validated `StreamEvent`s that always end
 *   with `done` or `error`. A connection that drops earlier is resumed with
 *   `Last-Event-ID` against the same endpoint and the same `Idempotency-Key`,
 *   so the server replays from its buffer instead of starting a second turn.
 * - **Event subscriptions** (`GET /v1/realtime/events`, `…/events`): JSON
 *   envelopes with no terminal frame. Reconnects (with backoff) until the
 *   caller aborts, resuming from the last delivered id.
 *
 * Parsing and validation are reused from `@cortex/api-types`, which already
 * guarantees the resume cursor only advances past events the consumer saw.
 */

import {
  ApiError,
  IncompleteStreamError,
  isProblem,
  readSseJson,
  readStream,
  type ErrorCode,
  type Problem,
  type StreamEvent,
} from '@cortex/api-types';

export type FetchLike = (request: Request) => Promise<Response>;

export interface StreamTarget {
  readonly url: string;
  readonly method: 'GET' | 'POST';
  readonly body?: unknown;
  readonly headers: Headers;
  readonly fetch: FetchLike;
}

export interface ResumeOptions {
  /** Resume point from an earlier attempt (persist it from `onEventId`). */
  readonly lastEventId?: string;
  readonly onEventId?: (id: string) => void;
  /** Called with each response before its body is read (`x-conversation-id`, `x-message-id`). */
  readonly onResponse?: (response: Response) => void;
  /** Called before each reconnect with the error that ended the previous attempt. */
  readonly onError?: (error: unknown, attempt: number) => void;
  readonly signal?: AbortSignal;
  /** Consecutive failed reconnects tolerated. Default 5 for turns, unlimited for subscriptions. */
  readonly maxReconnects?: number;
  /** First backoff delay; doubles per failed attempt up to 30 s. Default 250 ms. */
  readonly retryDelayMs?: number;
}

const MAX_DELAY_MS = 30_000;

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => (clearTimeout(t), resolve()), { once: true });
  });

/** Status to code for a failure whose body is not a problem document. */
export function codeForStatus(status: number): ErrorCode {
  if (status === 401) return 'unauthenticated';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not_found';
  if (status === 413) return 'payload_too_large';
  if (status === 429) return 'rate_limited';
  return status >= 500 ? 'service_unavailable' : 'bad_request';
}

export async function problemFrom(response: Response): Promise<ApiError> {
  let parsed: unknown;
  try {
    parsed = await response.json();
  } catch {
    parsed = undefined;
  }
  if (isProblem(parsed)) return new ApiError(parsed);
  return new ApiError({
    type: 'about:blank',
    title: `HTTP ${response.status}`,
    status: response.status,
    code: codeForStatus(response.status),
    request_id: response.headers.get('x-request-id') ?? 'unknown',
  } as Problem);
}

/** Network failures and 5xx/429 are worth another attempt; other refusals are not. */
const retryable = (error: unknown) =>
  error instanceof IncompleteStreamError ||
  error instanceof TypeError ||
  (error instanceof ApiError && (error.status >= 500 || error.status === 429));

async function open(target: StreamTarget, lastEventId: string | undefined, signal?: AbortSignal): Promise<Response> {
  const headers = new Headers(target.headers);
  headers.set('accept', 'text/event-stream');
  if (lastEventId !== undefined) headers.set('last-event-id', lastEventId);
  let body: string | undefined;
  if (target.body !== undefined) {
    body = JSON.stringify(target.body);
    headers.set('content-type', 'application/json');
  }
  const response = await target.fetch(
    new Request(target.url, {
      method: target.method,
      headers,
      // The API is usually another origin than the page (app.* vs api.*).
      credentials: 'include',
      ...(body === undefined ? {} : { body }),
      ...(signal ? { signal } : {}),
    }),
  );
  if (!response.ok) throw await problemFrom(response);
  // A captive portal or a wrong base URL answers 200 HTML; never parse that as a stream.
  if (!(response.headers.get('content-type') ?? '').includes('text/event-stream')) {
    await response.body?.cancel();
    throw new TypeError(`expected an event stream from ${target.url}, got ${response.headers.get('content-type') ?? 'no content type'}`);
  }
  return response;
}

/** Server ids are increasing integers; `0` marks a local frame (hello, resync) and is not a resume point. */
const isResumePoint = (id: string, current: string | undefined) =>
  /^\d+$/.test(id) && id !== '0' && (current === undefined || !/^\d+$/.test(current) || BigInt(id) > BigInt(current));

/** A turn: yields `StreamEvent`s until `done`/`error`, resuming dropped connections. */
export async function* turnStream(target: StreamTarget, options: ResumeOptions = {}): AsyncGenerator<StreamEvent, void, undefined> {
  let cursor = options.lastEventId;
  const max = options.maxReconnects ?? 5;
  const first = options.retryDelayMs ?? 250;
  let delay = first;
  let failures = 0;
  for (;;) {
    try {
      const response = await open(target, cursor, options.signal);
      options.onResponse?.(response);
      for await (const event of readStream(response, {
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        ...(options.signal ? { signal: options.signal } : {}),
        onEventId: (id) => {
          cursor = id;
          options.onEventId?.(id);
        },
      })) {
        failures = 0;
        delay = first;
        yield event;
      }
      return;
    } catch (error) {
      if (!retryable(error) || failures >= max || options.signal?.aborted) throw error;
      if (error instanceof IncompleteStreamError) cursor = error.lastEventId ?? cursor;
      failures++;
      options.onError?.(error, failures);
    }
    await sleep(delay, options.signal);
    delay = Math.min(delay * 2, MAX_DELAY_MS);
  }
}

/** A subscription: yields JSON envelopes until aborted, resuming from the last delivered id. */
export async function* eventSubscription<T = unknown>(target: StreamTarget, options: ResumeOptions = {}): AsyncGenerator<T, void, undefined> {
  let cursor = options.lastEventId;
  const max = options.maxReconnects ?? Number.POSITIVE_INFINITY;
  const first = options.retryDelayMs ?? 250;
  let delay = first;
  let failures = 0;
  while (!options.signal?.aborted) {
    let error: unknown = new IncompleteStreamError('the subscription closed', cursor);
    try {
      const response = await open(target, cursor, options.signal);
      options.onResponse?.(response);
      for await (const frame of readSseJson(response, {
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        ...(options.signal ? { signal: options.signal } : {}),
        onEventId: (id) => {
          if (!isResumePoint(id, cursor)) return;
          cursor = id;
          // Only a real event proves the link is healthy; a hello alone does not reset backoff.
          failures = 0;
          delay = first;
          options.onEventId?.(id);
        },
      })) {
        yield frame as T;
      }
    } catch (e) {
      error = e;
    }
    if (options.signal?.aborted) return;
    if (!retryable(error)) throw error;
    failures++;
    if (failures > max) throw error;
    options.onError?.(error, failures);
    await sleep(delay, options.signal);
    delay = Math.min(delay * 2, MAX_DELAY_MS);
  }
}
