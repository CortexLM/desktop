/**
 * `createCortexClient` — the entry point.
 *
 * Wraps the generated `CortexSdk` (one namespace per route group, one method per
 * operation) with what generation cannot know: where the instance lives, how a
 * caller authenticates, and how turns and event streams resume.
 */

import { ApiError, isProblem, type Problem, type StreamEvent, type RealtimeMessage } from '@cortex/api-types';
import { createClient, type Client, type Config } from './gen/client/index.js';
import { CortexSdk } from './gen/sdk.gen.js';
import type { AgentEvent } from './gen/types.gen.js';
import { codeForStatus, problemFrom, eventSubscription, turnStream, type FetchLike, type ResumeOptions, type AgentResumeOptions } from './stream.js';

/** Cortex Cloud's public API. A self-hosted instance passes its own `baseUrl`. */
export const CORTEX_CLOUD_URL = 'https://api.cortex.foundation';

export type TokenSource = string | (() => string | null | undefined | Promise<string | null | undefined>);

export interface CortexAuth {
  /** A bearer access token, or a function returning the current one. */
  readonly token?: TokenSource;
  /**
   * Obtains a fresh token after a 401. Called at most once per request, and
   * shared between concurrent requests (single flight): the identity provider
   * rate-limits refreshes, so one expiry must not become N refreshes.
   */
  readonly refresh?: (signal: AbortSignal) => Promise<string | null>;
  /** Abort before replacing the account; create a new client for that identity. */
  readonly signal?: AbortSignal;
}

export interface CortexClientOptions {
  /** Defaults to {@link CORTEX_CLOUD_URL}. No trailing `/v1`: operation paths carry it. */
  readonly baseUrl?: string;
  /**
   * Optional. Omit for a self-hosted instance whose auth mode is `none`, or to
   * start a guest session with `client.startGuest()`.
   */
  readonly auth?: CortexAuth;
  /** Defaults to `globalThis.fetch`. Pass the embedded handler to skip TCP. */
  readonly fetch?: FetchLike;
  /** Extra headers sent on every request. */
  readonly headers?: Record<string, string>;
  /**
   * Keep cookies the API sets (guest session, refresh cookie) and send them back.
   * Default: on outside a browser, where `fetch` has no cookie store. In a
   * browser the platform does this (`credentials: 'include'`).
   */
  readonly cookieJar?: boolean;
}

export interface TurnInput {
  /** Continue this conversation; omit to start a new one. */
  readonly conversationId?: string;
  /** The `TurnBody` (`message`, `model_slug`, `reasoning_effort`, `attachment_ids`, …). */
  readonly body: Record<string, unknown>;
  /** Generated when omitted. Persist your own key for resuming across invocations. */
  readonly idempotencyKey?: string;
}

/** The registered POST stream routes, including edit and regenerate. */
export type TurnPath = '/v1/conversations/turns'
  | `/v1/conversations/${string}/turns`
  | `/v1/code/sessions/${string}/turns`
  | `/v1/conversations/${string}/messages/${string}/edit`
  | `/v1/conversations/${string}/messages/${string}/regenerate`;

export interface CortexClient extends CortexSdk {
  readonly baseUrl: string;
  /** The generated low-level client (interceptors, `setConfig`). */
  readonly http: Client;
  /** Starts a guest session (`POST /v1/auth/guest`); its cookie is kept by the jar. */
  startGuest(): Promise<{ kind: string; user_id: string }>;
  /** Streams a Chat turn, resuming on a dropped connection. */
  streamTurn(input: TurnInput, options?: ResumeOptions): AsyncGenerator<StreamEvent, void, undefined>;
  /** Streams a Code session turn (`POST /v1/code/sessions/{id}/turns`). */
  streamCodeTurn(sessionId: string, input: Omit<TurnInput, 'conversationId'>, options?: ResumeOptions): AsyncGenerator<StreamEvent, void, undefined>;
  /** Edit/regenerate use their original POST path, body and key on every replay. */
  streamPath(path: TurnPath, input: Omit<TurnInput, 'conversationId'>, options?: ResumeOptions): AsyncGenerator<StreamEvent, void, undefined>;
  /** Subscribes to the account's realtime envelopes (`GET /v1/realtime/events`). */
  subscribe<T = RealtimeMessage>(options?: ResumeOptions): AsyncGenerator<T, void, undefined>;
  /** AgentEvent feeds use UUID query `since`; realtime uses numeric Last-Event-ID. */
  subscribePath<T = AgentEvent>(path: string, options?: AgentResumeOptions): AsyncGenerator<T, void, undefined>;
}

const trimSlashes = (s: string) => {
  let end = s.length;
  while (end > 0 && s.charCodeAt(end - 1) === 47) end--;
  return s.slice(0, end);
};

/** `randomUUID` needs a secure context; a self-host on plain http in a browser has only `getRandomValues`. */
const randomKey = () => {
  const c = globalThis.crypto;
  if (typeof c.randomUUID === 'function') return c.randomUUID();
  return Array.from(c.getRandomValues(new Uint8Array(16)), (b) => b.toString(16).padStart(2, '0')).join('');
};

/** One string per cookie. `getSetCookie` is missing in some runtimes (React Native). */
const setCookies = (headers: Headers): string[] =>
  headers.getSetCookie?.() ?? (headers.get('set-cookie')?.split(/,(?=\s*[^;=\s]+=)/) ?? []);

const expired = (line: string) => {
  if (/max-age=0/i.test(line)) return true;
  const at = /expires=([^;]+)/i.exec(line)?.[1];
  return at !== undefined && Date.parse(at) <= Date.now();
};

/**
 * Wraps fetch with bearer auth, single-flight refresh on 401, and an optional cookie jar.
 *
 * A refreshed token is used until `auth.token` (when it is a function) returns
 * a different one, so a caller's own store stays authoritative.
 */
function authedFetch(base: FetchLike, auth: CortexAuth | undefined, jar: Map<string, string> | undefined, extra: Record<string, string>) {
  let refreshing: Promise<string | null> | undefined;
  let refreshed: { from: string | null | undefined; token: string | null } | undefined;
  let session = new AbortController();
  let source: string | null | undefined;
  let issuedToken: string | undefined;
  let initialized = false;
  const changed = () => new DOMException('The client account changed; retry explicitly with its new client', 'AbortError');
  const invalidate = (clearCredentials = true) => {
    session.abort(changed());
    session = new AbortController();
    refreshing = undefined;
    if (clearCredentials) { refreshed = undefined; issuedToken = undefined; jar?.clear(); }
  };
  const ownToken = async () => typeof auth?.token === 'function' ? await auth.token() : auth?.token;
  const current = async (): Promise<string | null | undefined> => {
    auth?.signal?.throwIfAborted();
    const own = await ownToken();
    auth?.signal?.throwIfAborted();
    // New calls can use the caller's current token while refresh completes.
    // Replays wait below: only the callback's result can reconcile its identity.
    if (initialized && source !== own && own !== issuedToken && refreshing) return own;
    if (initialized && source !== own && !(issuedToken !== undefined && own === issuedToken)) invalidate();
    source = own;
    initialized = true;
    if (refreshed && refreshed.from === own) return refreshed.token;
    refreshed = undefined;
    return own;
  };
  const send = async (request: Request, token: string | null | undefined, bound: AbortSignal): Promise<Response> => {
    const signal = AbortSignal.any([request.signal, bound, ...(auth?.signal ? [auth.signal] : [])]);
    signal.throwIfAborted();
    const req = new Request(request.clone(), { signal });
    for (const [k, v] of Object.entries(extra)) if (!req.headers.has(k)) req.headers.set(k, v);
    if (token && !req.headers.has('authorization')) req.headers.set('authorization', `Bearer ${token}`);
    if (jar && jar.size > 0) req.headers.set('cookie', [...jar].map(([k, v]) => `${k}=${v}`).join('; '));
    let res = await base(req);
    const path = new URL(request.url).pathname;
    let tokenIssued: string | undefined;
    if (res.ok && /\/v1\/auth\//.test(path) && res.headers.get('content-type')?.includes('json')) {
      const data: unknown = await res.clone().json().catch(() => undefined);
      if (!signal.aborted && data && typeof data === 'object' && 'access_token' in data && typeof data.access_token === 'string') {
        // Adopt the token this client just issued before a reactive store can
        // start another request. Its rotation is not a new account switch.
        tokenIssued = data.access_token;
      }
    }
    // Native Fetch may abort unread bytes when this sign-in replaces its own
    // account lifetime. Detach the completed auth body before invalidating it.
    if (tokenIssued !== undefined && !/\/auth\/refresh$/.test(path)) res = new Response(await res.arrayBuffer(), res);
    // Custom Fetch implementations may ignore abort. Never merge stale cookies.
    if (signal.aborted) {
      await res.body?.cancel();
      signal.throwIfAborted();
    }
    if (jar) {
      for (const line of setCookies(res.headers)) {
        const pair = line.split(';')[0] ?? '';
        const eq = pair.indexOf('=');
        if (eq <= 0) continue;
        const name = pair.slice(0, eq).trim();
        const value = pair.slice(eq + 1).trim();
        if (value === '' || expired(line)) jar.delete(name);
        else jar.set(name, value);
      }
    }
    if (tokenIssued !== undefined) {
      // Requests admitted while sign-in was pending still belong to the old
      // identity. Only a refresh retains that identity's in-flight operations.
      if (!/\/auth\/refresh$/.test(path)) invalidate(false);
      issuedToken = tokenIssued;
      refreshed = { from: source, token: tokenIssued };
    } else if (res.ok && request.method === 'POST' && /\/auth\/(?:local\/)?logout$/.test(path)) {
      invalidate();
      refreshed = { from: source, token: null };
    }
    return res;
  };
  const requestWithAuth = async (request: Request, expected?: AbortSignal): Promise<Response> => {
    const duringRefresh = refreshing !== undefined;
    const used = await current();
    expected?.throwIfAborted();
    const authPath = /\/v1\/auth(?:\/|$)/.test(new URL(request.url).pathname);
    const refreshPath = /\/v1\/auth\/refresh$/.test(new URL(request.url).pathname);
    // Cancel the previous account's refresh before a new sign-in can set a
    // cookie. The refresh callback itself remains in its originating session.
    if (authPath && !refreshPath && request.method === 'POST' && /\/auth\/(?:password|register|local(?:\/logout)?|logout|magic-auth\/verify|verify-email|mfa\/verify)$/.test(new URL(request.url).pathname)) invalidate(false);
    const bound = session.signal;
    const res = await send(request, used, bound);
    // Sign-in/refresh failures must escape to the caller. Refreshing the
    // refresh request waits on the promise whose completion needs that request.
    if (res.status !== 401 || !auth?.refresh || authPath || duringRefresh) return res;
    if (request.headers.has('authorization') || Object.keys(extra).some((key) => key.toLowerCase() === 'authorization')) return res;
    // Another request may have refreshed while this one was in flight.
    try { if (refreshing) await refreshing; }
    catch (error) { await res.body?.cancel(); throw error; }
    const now = await current();
    if (bound.aborted) { await res.body?.cancel(); throw bound.reason; }
    if (now && now !== used) {
      await res.body?.cancel();
      return send(request, now, bound);
    }
    const own = source;
    if (!refreshing) {
      const pending = Promise.resolve().then(() => auth.refresh!(AbortSignal.any([bound, ...(auth.signal ? [auth.signal] : [])]))).then(async (token) => {
        bound.throwIfAborted();
        auth.signal?.throwIfAborted();
        const latest = await ownToken();
        // A callback may save its own refreshed token. Any other source change
        // is another account, never permission to replay this request there.
        if (latest !== own && latest !== token) { invalidate(); throw changed(); }
        source = latest;
        if (token) refreshed = { from: latest, token };
        return token;
      }).finally(() => { if (refreshing === pending) refreshing = undefined; });
      refreshing = pending;
    }
    try {
      const next = await refreshing;
      bound.throwIfAborted();
      if (!next) return res;
      await res.body?.cancel();
      request.signal.throwIfAborted();
      // A sign-out or account switch during refresh outranks its old token.
      const latest = await current();
      bound.throwIfAborted();
      return send(request, latest, bound);
    } catch (error) {
      await res.body?.cancel();
      throw error;
    }
  };
  return Object.assign((request: Request) => requestWithAuth(request), {
    bindSession() {
      let bound: AbortSignal | undefined;
      return {
        getSignal: () => bound,
        fetch: async (request: Request) => {
          if (bound && refreshing) await refreshing;
          await current();
          bound ??= AbortSignal.any([session.signal, ...(auth?.signal ? [auth.signal] : [])]);
          bound.throwIfAborted();
          return requestWithAuth(request, bound);
        },
      };
    },
  });
}

export function createCortexClient(options: CortexClientOptions = {}): CortexClient {
  const baseUrl = trimSlashes(options.baseUrl ?? CORTEX_CLOUD_URL);
  const inBrowser = typeof (globalThis as { document?: unknown }).document !== 'undefined';
  const jar = (options.cookieJar ?? !inBrowser) ? new Map<string, string>() : undefined;
  const rawFetch: FetchLike = options.fetch ?? ((r) => globalThis.fetch(r));
  const fetch = authedFetch(rawFetch, options.auth, jar, options.headers ?? {});

  const config: Config = {
    baseUrl,
    fetch: (input: RequestInfo | URL, init?: RequestInit) => fetch(input instanceof Request ? input : new Request(input, init)),
    credentials: 'include',
    throwOnError: true,
    responseStyle: 'data',
  };
  const http = createClient(config);
  // Every failure surfaces as `ApiError`, discriminated on `code`, whether the
  // body was a problem document or something a proxy wrote.
  // No response means the request never completed (abort, network): keep the original error.
  http.interceptors.error.use((error, response) => {
    if (error instanceof ApiError || response === undefined) return error;
    if (isProblem(error)) return new ApiError(error);
    const problem = {
      type: 'about:blank',
      title: `HTTP ${response.status}`,
      status: response.status,
      code: codeForStatus(response.status),
      request_id: response.headers.get('x-request-id') ?? 'unknown',
    } as Problem;
    return new ApiError(problem);
  });
  const sdk = new CortexSdk({ client: http }) as CortexClient;

  const target = (method: 'GET' | 'POST', path: string, body?: unknown, headers: Record<string, string> = {}) => ({
    url: `${baseUrl}${path}`,
    method,
    ...(body === undefined ? {} : { body }),
    headers: new Headers(headers),
    ...fetch.bindSession(),
  });
  const streamPath = (path: TurnPath, input: Omit<TurnInput, 'conversationId'>, opts?: ResumeOptions) => {
    if (!/^\/v1\/(?:conversations(?:\/[^/?#]+)?\/turns|code\/sessions\/[^/?#]+\/turns|conversations\/[^/?#]+\/messages\/[^/?#]+\/(?:edit|regenerate))$/.test(path)) throw new Error('Unknown turn stream path');
    if (opts?.lastEventId !== undefined && !input.idempotencyKey) throw new Error('Resuming a turn requires its original Idempotency-Key, POST path and body');
    return turnStream(target('POST', path, input.body, { 'idempotency-key': input.idempotencyKey ?? randomKey() }), opts);
  };

  return Object.assign(sdk, {
    baseUrl,
    http,
    async startGuest() {
      const res = await fetch(new Request(`${baseUrl}/v1/auth/guest`, { method: 'POST', credentials: 'include' }));
      if (!res.ok) throw await problemFrom(res);
      return (await res.json()) as { kind: string; user_id: string };
    },
    streamTurn(input: TurnInput, opts?: ResumeOptions) {
      const path: TurnPath = input.conversationId ? `/v1/conversations/${encodeURIComponent(input.conversationId)}/turns` : '/v1/conversations/turns';
      return streamPath(path, input, opts);
    },
    streamCodeTurn(sessionId: string, input: Omit<TurnInput, 'conversationId'>, opts?: ResumeOptions) {
      const path: TurnPath = `/v1/code/sessions/${encodeURIComponent(sessionId)}/turns`;
      return streamPath(path, input, opts);
    },
    streamPath,
    subscribe<T>(opts?: ResumeOptions) {
      return eventSubscription<T>(target('GET', '/v1/realtime/events'), opts);
    },
    subscribePath<T>(path: string, opts?: AgentResumeOptions) {
      const pathname = path.split('?')[0];
      const agent = /^\/v1\/(?:mascots|code\/sessions|code\/runtimes)\/[^/?#]+\/events$/.test(pathname);
      if (!agent && pathname !== '/v1/realtime/events') throw new Error('Unknown event subscription path');
      return eventSubscription<T>({ ...target('GET', path), ...(agent ? { resumeQuery: 'since' as const } : {}) }, opts);
    },
  });
}
