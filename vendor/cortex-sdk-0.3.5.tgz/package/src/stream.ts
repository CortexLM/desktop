/**
 * Resumable streams over the generated client.
 *
 * Three contracts, matching the server:
 *
 * - **Turn streams** (`POST …/turns`): validated `StreamEvent`s that always end
 *   with `done` or `error`, plus any announced image completion after `done`.
 *   A connection that drops earlier is resumed with
 *   `Last-Event-ID` against the same endpoint and the same `Idempotency-Key`,
 *   so the server replays from its buffer instead of starting a second turn.
 * - **Realtime** (`GET /v1/realtime/events`): numeric `Last-Event-ID`,
 *   process-local replay. Reload durable state after reconnecting.
 * - **Agent events** (`GET …/{id}/events`): UUID cursor in query `since`.
 *
 * Parsing and validation are reused from `@cortex/api-types`, which already
 * guarantees the resume cursor only advances past events the consumer saw.
 */

import {
  ApiError,
  IncompleteStreamError,
  isProblem,
  readSseJson,
  readStream,
  type ErrorCode,
  type Problem,
  type StreamEvent,
} from '@cortex/api-types';

export type FetchLike = (request: Request) => Promise<Response>;

export interface StreamTarget {
  readonly url: string;
  readonly method: 'GET' | 'POST';
  readonly body?: unknown;
  readonly headers: Headers;
  readonly fetch: FetchLike;
  /** The account lifetime, captured when this stream makes its first request. */
  readonly getSignal?: () => AbortSignal | undefined;
  /** AgentEvent feeds resume with a UUID query, never a numeric header. */
  readonly resumeQuery?: 'since';
}

export interface ResumeOptions {
  /** Resume point from an earlier attempt (persist it from `onEventId`). */
  readonly lastEventId?: string;
  readonly onEventId?: (id: string) => void;
  /** Called with each response before its body is read (`x-conversation-id`, `x-message-id`). */
  readonly onResponse?: (response: Response) => void;
  /** Called before each reconnect with the error that ended the previous attempt. */
  readonly onError?: (error: unknown, attempt: number) => void;
  readonly signal?: AbortSignal;
  /** Consecutive failed reconnects tolerated. Default 5 for turns, unlimited for subscriptions. */
  readonly maxReconnects?: number;
  /** First backoff delay; doubles per failed attempt up to 30 s. Default 250 ms. */
  readonly retryDelayMs?: number;
}

export interface AgentResumeOptions extends ResumeOptions {
  /** UUID from an AgentEvent feed. `lastEventId` is retained as an alias. */
  readonly since?: string;
}

const MAX_DELAY_MS = 30_000;
const readerSignal = (target: StreamTarget, signal?: AbortSignal) =>
  AbortSignal.any([signal, target.getSignal?.()].filter((value): value is AbortSignal => value !== undefined));

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve) => {
    const finish = () => {
      clearTimeout(t);
      signal?.removeEventListener('abort', finish);
      resolve();
    };
    const t = setTimeout(finish, ms);
    signal?.addEventListener('abort', finish, { once: true });
    if (signal?.aborted) finish();
  });

/** Status to code for a failure whose body is not a problem document. */
export function codeForStatus(status: number): ErrorCode {
  if (status === 401) return 'unauthenticated';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not_found';
  if (status === 413) return 'payload_too_large';
  if (status === 429) return 'rate_limited';
  return status >= 500 ? 'service_unavailable' : 'bad_request';
}

export async function problemFrom(response: Response): Promise<ApiError> {
  let parsed: unknown;
  try {
    parsed = await response.json();
  } catch {
    parsed = undefined;
  }
  if (isProblem(parsed)) return new ApiError(parsed);
  return new ApiError({
    type: 'about:blank',
    title: `HTTP ${response.status}`,
    status: response.status,
    code: codeForStatus(response.status),
    request_id: response.headers.get('x-request-id') ?? 'unknown',
  } as Problem);
}

/** Network failures and 5xx/429 are worth another attempt; other refusals are not. */
const retryable = (error: unknown) =>
  error instanceof IncompleteStreamError ||
  error instanceof TypeError ||
  (error instanceof ApiError && (error.status >= 500 || error.status === 429));

async function open(target: StreamTarget, lastEventId: string | undefined, signal?: AbortSignal, body?: string): Promise<Response> {
  const headers = new Headers(target.headers);
  const url = new URL(target.url);
  headers.set('accept', 'text/event-stream');
  if (target.resumeQuery === 'since') {
    headers.delete('last-event-id');
    if (lastEventId !== undefined) url.searchParams.set('since', lastEventId);
  } else if (lastEventId !== undefined) {
    headers.set('last-event-id', lastEventId);
    // Realtime query wins over the header on the server; do not leave a stale
    // initial query overriding every later cursor.
    if (url.searchParams.has('last_event_id')) url.searchParams.set('last_event_id', lastEventId);
  }
  if (body !== undefined) headers.set('content-type', 'application/json');
  const response = await target.fetch(
    new Request(url, {
      method: target.method,
      headers,
      // The API is usually another origin than the page (app.* vs api.*).
      credentials: 'include',
      ...(body === undefined ? {} : { body }),
      ...(signal ? { signal } : {}),
    }),
  );
  if (!response.ok) throw await problemFrom(response);
  // A captive portal or a wrong base URL answers 200 HTML; never parse that as a stream.
  if (!(response.headers.get('content-type') ?? '').includes('text/event-stream')) {
    await response.body?.cancel();
    throw new Error('Expected text/event-stream');
  }
  return response;
}

/** Server ids are increasing integers; `0` marks a local frame (hello, resync) and is not a resume point. */
const isResumePoint = (id: string, current: string | undefined) =>
  /^\d+$/.test(id) && id !== '0' && (current === undefined || !/^\d+$/.test(current) || BigInt(id) > BigInt(current));
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** A turn: yields through done and pending image completion, resuming pre-terminal drops. */
export async function* turnStream(target: StreamTarget, options: ResumeOptions = {}): AsyncGenerator<StreamEvent, void, undefined> {
  const key = target.headers.get('idempotency-key')?.trim();
  if (target.method !== 'POST' || !key || key.length > 200) throw new Error('Turn streams require a POST and an Idempotency-Key of 1–200 characters');
  let cursor = options.lastEventId;
  if (cursor !== undefined && !/^\d+$/.test(cursor)) throw new Error('Turn resume cursor must be numeric');
  // Snapshot before the first request: a caller editing its draft during a
  // disconnect must not change the body of this replay.
  const body = target.body === undefined ? undefined : JSON.stringify(target.body);
  target = { ...target, headers: new Headers(target.headers) };
  const max = options.maxReconnects ?? 5;
  const first = options.retryDelayMs ?? 250;
  let delay = first;
  let failures = 0;
  let terminal = false;
  const pendingImages = new Set<string>();
  for (;;) {
    try {
      const response = await open(target, cursor, options.signal, body);
      options.onResponse?.(response);
      for await (const event of readStream(response, {
        // Text can finish before an announced image; acknowledge its final
        // cursor before closing even if the transport itself stays open.
        get stopAtTerminal() { return pendingImages.size === 0; },
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        signal: readerSignal(target, options.signal),
        onEventId: (id) => {
          if (!isResumePoint(id, cursor)) return;
          cursor = id;
          options.onEventId?.(id);
        },
      })) {
        failures = 0;
        delay = first;
        if (event.type === 'image_generation') {
          if (event.status === 'queued' || event.status === 'generating') pendingImages.add(event.generation_id);
          else pendingImages.delete(event.generation_id);
        }
        if (event.type === 'error') pendingImages.clear();
        terminal ||= event.type === 'done' || event.type === 'error';
        yield event;
      }
      return;
    } catch (error) {
      if (options.signal?.aborted || target.getSignal?.()?.aborted) throw error;
      if (terminal) return;
      if (!retryable(error) || failures >= max) throw error;
      // Only the validated numeric cursor above may advance a replay.
      failures++;
      options.onError?.(error, failures);
    }
    await sleep(delay, readerSignal(target, options.signal));
    delay = Math.min(delay * 2, MAX_DELAY_MS);
  }
}

/** A subscription: yields JSON envelopes until aborted, resuming from the last delivered id. */
export async function* eventSubscription<T = unknown>(target: StreamTarget, options: AgentResumeOptions = {}): AsyncGenerator<T, void, undefined> {
  const agent = target.resumeQuery === 'since';
  const initial = new URL(target.url).searchParams.get(agent ? 'since' : 'last_event_id');
  let cursor = (agent ? options.since : undefined) ?? options.lastEventId ?? initial ?? undefined;
  if (cursor !== undefined && !(agent ? uuid.test(cursor) : /^\d+$/.test(cursor))) throw new Error('Invalid subscription cursor');
  if (agent) cursor = cursor?.toLowerCase();
  const max = options.maxReconnects ?? Number.POSITIVE_INFINITY;
  const first = options.retryDelayMs ?? 250;
  let delay = first;
  let failures = 0;
  while (!options.signal?.aborted) {
    let error: unknown = new IncompleteStreamError('the subscription closed', cursor);
    try {
      const response = await open(target, cursor, options.signal);
      options.onResponse?.(response);
      // Realtime sequence numbers restart if this process loses the room.
      // The previous connection's cursor cannot reject new delivered events.
      let connectionCursor: string | undefined;
      for await (const frame of readSseJson(response, {
        ...(cursor === undefined ? {} : { lastEventId: cursor }),
        signal: readerSignal(target, options.signal),
        onEventId: (id) => {
          if (agent) {
            if (!uuid.test(id)) return;
            id = id.toLowerCase();
            if (cursor !== undefined && id <= cursor) return;
          } else if (!isResumePoint(id, connectionCursor)) return;
          cursor = id;
          connectionCursor = id;
          // Only a real event proves the link is healthy; a hello alone does not reset backoff.
          failures = 0;
          delay = first;
          options.onEventId?.(id);
        },
      })) {
        yield frame as T;
      }
    } catch (e) {
      error = e;
    }
    if (options.signal?.aborted || target.getSignal?.()?.aborted) return;
    if (!retryable(error)) throw error;
    failures++;
    if (failures > max) throw error;
    options.onError?.(error, failures);
    await sleep(delay, readerSignal(target, options.signal));
    delay = Math.min(delay * 2, MAX_DELAY_MS);
  }
}
