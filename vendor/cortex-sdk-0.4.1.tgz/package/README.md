# @cortex/sdk

TypeScript SDK for the Cortex API. It is generated from the OpenAPI document
(`openapi/cortex.openapi.json`). Every public route has a method, grouped
by route: `client.conversations.turns.create()`, `client.mascots.routines.list()`,
`client.registry.models.list()`.
A small hand-written layer adds the parts generation cannot produce:

- **Base URL.** Defaults to Cortex Cloud (`https://api.cortex.foundation`). A
  self-hosted instance passes its own origin.
- **Optional auth.** You can use a bearer token or a token function, with
  single-flight refresh on a 401. You can also start a guest session, or send no
  credentials at all to an instance that does not require login.
- **Resumable streams.** Chat and Code turns resume from `Last-Event-ID` with
  the same `Idempotency-Key`. Realtime subscriptions reconnect with backoff and
  resume from the last delivered event.
- **Typed errors.** HTTP refusals become `ApiError`; network/abort errors retain
  their original type. `ApiError.problem.mfa` names the required sign-in step.
- **Embedded mode.** The real API runs in-process, with no port.

## Install

The package is not on npm yet. Depend on it from this repository:

```json
{ "dependencies": { "@cortex/sdk": "file:../backend/packages/sdk" } }
```

Build it first with `cd packages/sdk && npm install && npm run build`. It
depends on `@cortex/api-types`, which lives next to it.

For another repository, `npm run pack:vendor -- <output-directory>` builds both
tarballs. Install the pair together with npm or Bun; the SDK's optional peer
references the accompanying api-types version. SDK 0.4.1 pairs with api-types
0.3.0. 0.4.1 keeps every runtime export of the approved 0.3.5 pairs (response
DTOs that would collide with a resource class carry a `Response` suffix, e.g.
`ApprovalPolicyResponse`). 0.4.x types every turn body (`ChatTurnRequest`, `EditTurnRequest`,
`RegenerateRequest`, `CodeTurnRequest`) and every account, history, Bot, Code,
approval, task and call response; `TurnInput.body` is no longer `Record<string, unknown>`. No public npm publication is implied.

**Typing scope:** instance, local login, provider/registry discovery, email-code
sign-in, MFA/email verification, Library and bug screenshot uploads use precise schema types.
Other legacy payloads remain `unknown` where the canonical document has no
field schema. Operation counts measure route coverage, not fully typed workflows.

## Quick start

```ts
import { createCortexClient, ApiError } from '@cortex/sdk';

const client = createCortexClient({
  baseUrl: 'http://127.0.0.1:8080',     // omit for Cortex Cloud
  auth: { token: () => store.accessToken, signal: accountAbort.signal,
    refresh: (signal) => store.refresh(signal) }, // optional
});

const { items } = await client.models.list();   // slugs, context, supports_reasoning, …
const model = items[0];
if (!model) throw new Error('No model is available for this example.');

for await (const event of client.streamTurn({ body: { message: 'Hello', model_slug: model.slug } })) {
  switch (event.type) {
    case 'reasoning_delta': /* thinking */ break;
    case 'text_delta': process.stdout.write(event.delta); break;
    case 'image_generation': /* status, file_id */ break;
    case 'done': break;
  }
}
```

Without `auth`, call `await client.startGuest()` to get a guest session. Outside
a browser, the SDK keeps the session cookie in an in-memory jar.

## Cloud or self-host

`GET /v1/instance` is the first call a client makes. It tells you whether the
backend is Cortex Cloud or a self-hosted instance, and whether a sign-in is
required:

```ts
const instance = await client.instance.list();
if (instance.auth.required) { /* sign in: Bearer token, or startGuest() on Cloud */ }
if (instance.mode === 'self_host') {
  // Self-host: the models.dev registry, with capabilities and filters.
  const { items } = await client.registry.models.list({ query: { configured: true, reasoning: true } });
  const providers = await client.providers.list();
} else {
  const { items } = await client.models.list(); // Cortex Cloud catalogue
}
```

A self-hosted turn names a registry model as `<provider>/<model>`
(`model_slug: 'acme/think-1'`). `reasoning_effort` and image attachments are
honoured only when the model's capabilities allow them. `examples/self-host.mjs`
is this flow.

`registry.enabled` controls metadata enrichment, not discovery. Disabled
enrichment can still list explicitly configured operator models. In local auth
mode, obtain the bearer with `client.auth.local.create({ body: { email,
password } })`, keep it in memory, sign in again after reload/expiry. Local
sessions have no refresh cookie. Cloud `auth.refresh` calls can use this same
client; auth endpoints bypass automatic refresh so a refused refresh cannot
wait on itself.
Abort the account's `auth.signal` before switching identities, then create a
client for the new account. Pass the refresh callback's signal to its request.
The SDK also detects changed token sources and cancels old requests/replays;
sign-in through this client cancels a pending refresh before the new cookie
arrives. A rejected sign-in keeps the existing cookies. Adopting a token issued
by this client preserves its rotated cookie. Late responses cannot update the
old client's cookie jar. Account cancellation reaches parsed stream readers too.
Successful auth JSON is read once and detached before replacing its lifetime,
so Node 22 can read it after cancellation without native response cloning that
can hang Node 20.9 during shutdown. Network-read failures retain their identity.
Calls started during a pending refresh return their own 401 without recursively
refreshing, so a refresh callback can await another SDK call without a cycle.

## Calling a route

Each method takes `{ path, query, body }`. It resolves to the response body or
throws `ApiError`:

```ts
const file = await client.library.create({
  query: { filename: 'notes.txt' },
  body: new Blob(['notes'], { type: 'text/plain' }),
});
const bytes = await client.library.content.list({ path: { id: file.id } }); // Blob

try {
  await client.code.sessions.create({ body: { repo: 'owner/name' } });
} catch (e) {
  if (e instanceof ApiError && e.code === 'entitlement_required') { /* sign in */ }
}
```

`client.http` is the underlying generated client. Use it for interceptors or
per-call `fetch` overrides. Raw Library upload sends bytes, never JSON or
multipart; its default request Content-Type is `application/octet-stream`.
`client.feedback.bugs.screenshots.create()` likewise takes raw Blob/File bytes
and required `query.filename`, returning screenshot metadata for a bug report.
Request headers accept objects, native `Headers`, or tuples. Object values of
`null` remove defaults.
OTP send resolves to `undefined` (204). Verification returns a `status` union:
`session`, `verify_email`, `mfa_challenge`, `mfa_enrollment`; only `session`
establishes sign-in. MFA verification itself returns `session` only.

HTTP media methods return `Blob` for binary routes, strings for text routes.
Generated SSE-only methods return a raw `ReadableStream<Uint8Array>` without
buffering; use the helpers below for parsed events and automatic replay.
Turn/edit/regenerate request bodies remain `unknown` until canonical DTOs exist;
their documented SSE response does not imply a bodyless request.
Agent event `.list()` methods always request their JSON page. Generated methods
pin their parser and data return style; `parseAs` and `responseStyle` overrides
are available only on `client.http`. WebSocket-only routes remain HTTP refusal
methods (`never` success type); Fetch cannot open an upgraded socket. Realtime
SSE is `subscribe()`. A native WebSocket/noVNC client owns socket upgrades.
Low-level `client.http.sse` follows empty SSE IDs as cursor resets, removing
`Last-Event-ID` on reconnect; it preserves an initial caller cursor until then.

## Streams and resume

| Method | Route | Ends |
| --- | --- | --- |
| `streamTurn({ conversationId?, body, idempotencyKey? })` | `POST /v1/conversations[/{id}]/turns` | `done` or `error` event |
| `streamCodeTurn(sessionId, { body })` | `POST /v1/code/sessions/{id}/turns` | `done` or `error` event |
| `streamPath(path, { body, idempotencyKey })` | Original edit/regenerate POST endpoint | `done` or `error` event |
| `subscribe()` | `GET /v1/realtime/events` | when `signal` aborts |
| `subscribePath(path)` | `GET /v1/mascots/{id}/events`, `/v1/code/sessions/{id}/events`, `/v1/code/runtimes/{id}/events` | when `signal` aborts |

Stream options are `{ lastEventId, onEventId, onResponse, signal,
maxReconnects, retryDelayMs }`. For a turn, retain the **original POST path,
body, Idempotency-Key and full opaque Redis cursor** (for example `1791179744000-1`); replay the same input with
`lastEventId`. A new invocation with a cursor but no original key is refused
before sending. Automatic reconnect snapshots the body once. An error
`stream_expired` ends replay: reload `conversations.messages.list()` (or Code
session messages); never start a replacement turn automatically.
Turn `done` can precede an announced image's completion. The iterator keeps
those image frames until they settle or the transport closes, then acknowledges
the final cursor. Plain completion does not wait for socket EOF.

`conversations.messages.list()` returns `ConversationHistory`: chronological
`items`, `has_more`, `has_older`, `has_newer`, optional `next_cursor` and
`next_after_cursor`. Pass only one of `before`, `after`, `message_id`; `limit`
is clamped to 1–200. Parts retain their ordered `sequence`, `kind`, optional
text/metadata, and explicit `retention`. Missing retained bytes do not imply
an empty successful attachment. Empty compatibility arrays are omitted.
The sibling API-types package exports the matching readonly history DTOs.

AgentEvent subscriptions instead accept `{ since: '<UUID>', ... }` and update
query `since` on reconnect, preserving other query parameters. `lastEventId`
is a compatibility alias for that UUID. Realtime uses numeric `Last-Event-ID`;
its buffer is process-local, so reload durable state after reconnecting.
`examples/resume.mjs` accepts `CORTEX_LAST_EVENT_ID` only with `CORTEX_TOKEN`
for the same account; a fresh guest cannot resume the previous guest's feed.

AgentEvent `payload` is `unknown`. Render through `projectAgentEvent(event)`,
which keeps only producer-written public fields (`ask_user` message_id/widget,
`video_ready` video_id/title, `environment_progress` phase, `host_connected`
host_id/hostname) and returns `{ opaque: true }` metadata for every other kind,
resource mismatch or malformed payload; `user_id` is dropped. Frames are
published in-process before the producer commits: re-read the owned resource
before acting, and use a fresh `since` page after reconnecting.
Cursors advance after the consumer requests the next event; interrupted
consumption can redeliver a frame. Equal nonempty turn IDs suppress exact
redelivery, including legacy numeric IDs; nonunique legacy IDs cannot identify
distinct events. Empty `id:` resets clear the resume cursor, deliver every
payload and terminal outcome, and prevent reconnecting an unbuffered truncation.
No synthetic cursor replaces a reset.
Replay still depends on the server retaining its idempotency mapping and
buffer. The SDK preserves replay identity; it cannot provide an exactly-once
generation guarantee when that server state is unavailable.

`onResponse` exposes `x-conversation-id` and `x-message-id`. Aborting Chat's
reader detaches delivery; generation continues. There is no Chat cancel
operation. Reasoning accepts `low|medium|high`, with no portable Off. Omission
uses the server default/stored effort. Code's cancel route is Code-only.

## Bot calls

`client.live.sessions.create({ body: { surface: 'bot', bot_id, consent: 'allow' } })`
starts a call only after in-session consent (`deny` creates nothing).
Connect with `new WebSocket(liveMediaUrl(client.baseUrl, call))` within 15 s;
the ticket in `ws_path` is one-use and must never be logged. Binary messages are
672-byte frames: build and read them with `encodeLiveFrame` / `decodeLiveFrame`
(`LIVE_FRAME` holds the layout). Text messages are `LiveCallControl` /
`LiveCallEvent`. After socket loss, `client.live.sessions.resume.create({ path:
{ id }, body: { epoch } })` returns a fresh ticket; 409 means superseded, 410
means the call ended. `client.live.sessions.delete()` ends it.

A call is not full duplex: speech is endpointed by the server and recognised
once per utterance (`stt: 'utterance'`), with no interim transcripts; replies
stream back as PCM (`tts: 'pcm_stream'`) and can be interrupted. Chat Live has
no transport (`live: false`). `parseAudioCapabilities()` narrows
`GET /v1/audio/capabilities` to exactly those shapes. Sending capture while
muted, out of order or faster than real time closes the socket with 1008.

## Embedded mode

`server/src/embedded.ts` exposes the public router as a Fetch handler. Pass it
to the SDK as `fetch`:

```ts
import { startEmbedded } from '<backend>/server/src/embedded.ts';
const api = await startEmbedded();             // same config and datastores as cortex-api
const client = createCortexClient({ baseUrl: 'http://cortex.embedded', fetch: api.fetch });
```

It runs under Bun and still needs Postgres, Redis and OpenBao. The scheduler,
the Security pipeline and WebSockets are not started in this mode.
Call `api.close()` in `finally`; failed startup also releases connected state.

## Regenerating

```sh
npm run generate          # rewrite src/gen from openapi/cortex.openapi.json
npm run check-generated   # fail if src/gen differs from a fresh generation (CI)
```

Generation is deterministic: the generator version is pinned, there is a
single input file, there are no timestamps, and trailing whitespace is
stripped. Do not edit `src/gen` by hand.

## Examples and tests

- `examples/` holds runnable scripts. Run them with `npm run examples` against
  `CORTEX_URL`, which defaults to `http://127.0.0.1:8080`.
- `npm run test:integration` boots two real APIs from this checkout (a Cloud
  one, and a self-host one with `auth_mode = none`), with local stubs for
  sign-in, inference and models.dev. It needs Postgres and Redis (addresses
  from `CORTEX_TEST_ADMIN_URL` / `CORTEX__DATABASE__URL` and
  `CORTEX__REDIS__URL`, or loopback defaults). A fresh database is cloned from
  the server suite's migrated template per run, then removed. It fails
  unless every SDK operation is called and every route group has a test of
  its own. The coverage report is written under `/tmp/opencode/sdk-it-*/coverage/`.
- `scripts/sdk-local-backend.sh up` (repository root) starts one API on :8080
  for the examples or for your own app.
- `npm test` covers protocol regressions; `npm run test:types` verifies positive
  and rejected consumer inputs against the built declarations.
- `node test/package.mjs <tarball-directory>` checks both npm and Bun installs
  outside the repository, public consumer types, and the same runtime cases.
