/**
 * `@cortex/sdk` — TypeScript SDK for the Cortex API.
 *
 * `src/gen` is generated from `openapi/cortex.openapi.json` (`npm run generate`);
 * this file and its siblings are the hand-written runtime around it.
 */
export { createCortexClient, CORTEX_CLOUD_URL } from './client.js';
export type { CortexClient, CortexClientOptions, CortexAuth, TokenSource, TurnInput, TurnPath } from './client.js';
export { turnStream, eventSubscription } from './stream.js';
export type { ResumeOptions, AgentResumeOptions, StreamTarget, FetchLike } from './stream.js';
export * from './gen/index.js';
export { ApiError, IncompleteStreamError, isProblem, projectAgentEvent, LIVE_FRAME, encodeLiveFrame, decodeLiveFrame, liveMediaUrl, parseAudioCapabilities } from '@cortex/api-types';
export type { StreamEvent, Problem, ErrorCode, MfaRequirement, RealtimeMessage } from '@cortex/api-types';
export type {
  AgentActivity, AgentKnownActivity, AgentOpaqueActivity, AgentAskUserActivity, AgentVideoReadyActivity,
  AgentEnvironmentProgressActivity, AgentHostConnectedActivity, AgentHostDisconnectedActivity,
  BotAskWidgetKind, EnvironmentProgressPhase,
} from '@cortex/api-types';
export type {
  LiveFrame, LiveFrameInput, LiveFrameDirection, BotCallCapabilities, BotCallAvailable, BotCallUnavailable, CallAudioCapabilities,
} from '@cortex/api-types';
