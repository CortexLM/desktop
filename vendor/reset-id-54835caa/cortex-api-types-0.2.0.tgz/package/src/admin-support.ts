/** Private admin listener; normal staff session authentication is required. */
export type BugValidity = 'valid' | 'invalid';

export interface AdminBug {
  readonly id: string;
  readonly title: string;
  readonly description: string;
  readonly surface: string | null;
  readonly path: string | null;
  readonly status: string;
  readonly validity: BugValidity | null;
  readonly ticket_number: string | null;
  readonly created_at: string;
}

/** GET /v1/admin/bugs?limit=50&before=bug_ID; limit is 1..200. */
export interface AdminBugList {
  readonly items: readonly AdminBug[];
  /** Pass as before until null. Includes reports in every status. */
  readonly next_cursor: string | null;
}

/** POST /v1/admin/bugs/{id}/triage; validity does not resolve a report. */
export interface AdminBugTriageRequest {
  /** Nonzero UUID reused with the same body when retrying. */
  readonly request_id: string;
  readonly validity: BugValidity;
  /** 1..8000 characters after trimming. */
  readonly message: string;
}

export interface AdminBugTriageResponse {
  readonly request_id: string;
  readonly report_id: string;
  readonly validity: BugValidity;
  readonly ticket_number: string;
  /** Durable queue acknowledgement, not an email delivery receipt. */
  readonly reply_queued: boolean;
}
