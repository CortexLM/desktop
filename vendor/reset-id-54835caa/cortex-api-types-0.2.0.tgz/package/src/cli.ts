/**
 * Wire types for the Cortex Code CLI.
 *
 * Mirrors `server/src/api/auth.ts` (`CliSessionBody`),
 * `auth-cli.ts` (`DeviceAuthorization`) and `code-cli.ts`
 * (`CodeCapabilities`). The CLI stores `refresh_token` in a keyring and
 * sends `Authorization: Bearer` on every call. See `docs/cli.md`.
 */

/** `POST /v1/auth/device` — start a CLI sign-in. */
export interface DeviceAuthorization {
  readonly device_code: string;
  readonly user_code: string;
  readonly verification_uri: string;
  readonly verification_uri_complete: string;
  readonly expires_in: number;
  readonly interval: number;
}

/** `POST /v1/auth/device/token` while the user is still in the browser. */
export interface DevicePollPending {
  readonly status: 'authorization_pending';
  readonly interval: number;
}

/**
 * Tokens a CLI can store. The web modal never sees this shape — it keeps
 * using `{ access_token }` plus the httpOnly refresh cookie.
 */
export interface CliSession {
  readonly access_token: string;
  readonly refresh_token: string;
  readonly token_type: 'Bearer';
}

/** `POST /v1/auth/refresh` from a keyring. */
export interface CliRefreshRequest {
  readonly refresh_token: string;
}

/** `GET /v1/code/capabilities`. */
export interface CodeCapabilities {
  readonly product: 'Cortex Code';
  readonly domain: 'cortex.foundation';
  readonly auth: {
    readonly device: '/v1/auth/device';
    readonly device_token: '/v1/auth/device/token';
    readonly refresh: '/v1/auth/refresh';
    readonly me: '/v1/me';
    readonly consents: '/v1/me/consents';
  };
  readonly privacy: {
    readonly consents: '/v1/me/consents';
    readonly export: '/v1/me/export';
    readonly deletion: '/v1/me/deletion';
    readonly mfa: '/v1/me/mfa';
  };
  readonly turns: {
    readonly create_session: '/v1/code/sessions';
    readonly turn: '/v1/code/sessions/{id}/turns';
    readonly events: '/v1/code/sessions/{id}/events';
    readonly cancel: '/v1/code/sessions/{id}/cancel';
    readonly files: '/v1/code/sessions/{id}/files';
    readonly workspace_tools: readonly string[];
    readonly executors: readonly string[];
    readonly interactions: readonly string[];
  };
  readonly runtimes: {
    readonly available: boolean;
    readonly unavailable_reason?: 'code_compute_not_configured';
    readonly create: '/v1/code/runtimes';
    readonly prepare: '/v1/code/runtimes/{id}/prepare';
    readonly events: '/v1/code/runtimes/{id}/events';
    readonly snapshot: '/v1/code/runtimes/{id}/snapshot';
    readonly restore: '/v1/code/runtimes/{id}/restore';
    readonly images: '/v1/code/runtimes/images';
  };
  readonly realtime: {
    readonly websocket: '/v1/realtime';
    readonly sse: '/v1/realtime/events';
  };
}
