/**
 * A typed client over the Cortex API.
 *
 * Thin on purpose. It handles the four things that are easy to get wrong and
 * tedious to repeat — bearer tokens with single-flight refresh, problem+json
 * parsing, idempotency keys, and resumable streams — and nothing else. No caching,
 * no state management, no retry policy beyond what the server asks for. Those are
 * the frontend's decisions and a client that made them for you would be in the
 * way.
 */

import { ApiError, isProblem, type Problem } from './errors.js';
import { readSseJson, readStream, type StreamEvent } from './streaming.js';

/** Supplies and refreshes the access token. */
export interface TokenProvider {
  /** The current token, or `null` when not signed in. */
  getToken(): string | null;
  /**
   * Obtains a fresh token after a 401.
   *
   * **Must be single-flight.** Access tokens live five minutes, so several tabs
   * and any long-running request will hit 401 within moments of each other, and
   * WorkOS rate-limits the refresh endpoint to 10 requests per 60 seconds per
   * email. A naive implementation that refreshes per failed request turns an
   * expired token into a lockout. Return the same in-flight promise to every
   * concurrent caller.
   */
  refresh(): Promise<string | null>;
}

export interface ClientOptions {
  /** Base URL of the API, without a trailing slash. JSON and blob requests. */
  readonly baseUrl: string;
  /**
   * Host for `stream` / `sse` only. Defaults to {@link baseUrl}.
   *
   * Production Chat keeps JSON on the page origin (CDN `/v1/*`) and sends the
   * token stream to the HTTP/1.1 API distribution so CloudFront HTTP/2 cannot
   * coalesce `text_delta`s (`API-9`).
   */
  readonly streamBaseUrl?: string;
  readonly tokens: TokenProvider;
  /** Overridable for tests and for non-browser runtimes. */
  readonly fetch?: typeof globalThis.fetch;
}

interface RequestOptions {
  readonly method?: string;
  readonly body?: unknown;
  /**
   * A body to send as-is, for the endpoints that take bytes rather than JSON.
   *
   * Separate from `body` because that member is always JSON-serialised, and a
   * `File` through `JSON.stringify` is the string `{}` — a silent zero-byte
   * upload rather than an error. Mutually exclusive with `body`.
   */
  readonly rawBody?: BodyInit;
  /** Content type for `rawBody`. Omitted lets the server sniff the bytes. */
  readonly contentType?: string;
  readonly query?: Record<string, string | number | boolean | undefined>;
  readonly signal?: AbortSignal;
  /**
   * Makes a mutation safe to retry.
   *
   * Supply the same key when retrying after a timeout and the server replays the
   * original response instead of performing the action twice. Reusing a key with
   * a *different* body is reported as `idempotency_key_reuse` rather than served
   * a stale response, because that is a client bug worth surfacing.
   */
  readonly idempotencyKey?: string;
  /** Internal: prevents a refresh loop. */
  readonly _retried?: boolean;
}

export class CortexClient {
  readonly #baseUrl: string;
  readonly #streamBaseUrl: string;
  readonly #tokens: TokenProvider;
  readonly #fetch: typeof globalThis.fetch;

  constructor(options: ClientOptions) {
    this.#baseUrl = trimTrailingSlashes(options.baseUrl);
    this.#streamBaseUrl = trimTrailingSlashes(options.streamBaseUrl ?? options.baseUrl);
    this.#tokens = options.tokens;
    // Bound to `globalThis`: an unbound `fetch` reference throws an illegal
    // invocation in some runtimes.
    this.#fetch = options.fetch ?? globalThis.fetch.bind(globalThis);
  }

  /** Performs a request and parses the response. */
  async request<T>(path: string, options: RequestOptions = {}): Promise<T> {
    const response = await this.#send(path, options);

    if (response.status === 204) return undefined as T;
    return (await response.json()) as T;
  }

  /**
   * Performs a request and returns the raw bytes.
   *
   * Needed because a Library preview cannot be an `<img src>` pointing at the
   * API: the access token lives in memory rather than in a cookie, so the
   * browser would send an unauthenticated request. The caller turns this into an
   * object URL and revokes it when the surface goes away.
   */
  async blob(path: string, options: RequestOptions = {}): Promise<Blob> {
    const response = await this.#send(path, options);
    return response.blob();
  }

  /**
   * Opens a stream.
   *
   * `lastEventId` resumes a stream that was interrupted. Persist the id from
   * `onEventId` — a refresh mid-answer is the case this exists for, and from the
   * user's side losing it is indistinguishable from the product crashing.
   */
  async *stream(
    path: string,
    options: RequestOptions & {
      lastEventId?: string;
      onEventId?: (id: string) => void;
      /**
       * Called with the response before the body is read. The turn endpoint
       * names the conversation and message it began in `X-Conversation-Id`
       * and `X-Message-Id`, and this is where a caller learns them.
       */
      onResponse?: (response: Response) => void;
    } = {},
  ): AsyncGenerator<StreamEvent, void, undefined> {
    const headers: Record<string, string> = { Accept: 'text/event-stream' };
    if (options.lastEventId !== undefined) {
      headers['Last-Event-ID'] = options.lastEventId;
    }

    const response = await this.#send(
      path,
      { ...options, method: options.method ?? 'POST' },
      headers,
      this.#streamBaseUrl,
    );
    options.onResponse?.(response);

    yield* readStream(response, {
      ...(options.lastEventId !== undefined ? { lastEventId: options.lastEventId } : {}),
      ...(options.signal !== undefined ? { signal: options.signal } : {}),
      ...(options.onEventId !== undefined ? { onEventId: options.onEventId } : {}),
    });
  }

  /**
   * Opens an SSE that is not a Chat turn.
   *
   * Bot's realtime hub (`GET /v1/realtime/events`) is this: JSON envelopes,
   * no terminal `done`. {@link stream} validates `StreamEvent` and would
   * drop every frame.
   */
  async *sse(
    path: string,
    options: RequestOptions & {
      lastEventId?: string;
      onEventId?: (id: string) => void;
    } = {},
  ): AsyncGenerator<unknown, void, undefined> {
    const headers: Record<string, string> = { Accept: 'text/event-stream' };
    if (options.lastEventId !== undefined) {
      headers['Last-Event-ID'] = options.lastEventId;
    }

    const response = await this.#send(
      path,
      { ...options, method: options.method ?? 'GET' },
      headers,
      this.#streamBaseUrl,
    );

    yield* readSseJson(response, {
      ...(options.lastEventId !== undefined ? { lastEventId: options.lastEventId } : {}),
      ...(options.signal !== undefined ? { signal: options.signal } : {}),
      ...(options.onEventId !== undefined ? { onEventId: options.onEventId } : {}),
    });
  }

  async #send(
    path: string,
    options: RequestOptions,
    extraHeaders: Record<string, string> = {},
    baseUrl: string = this.#baseUrl,
  ): Promise<Response> {
    const url = new URL(`${baseUrl}${path}`);
    for (const [key, value] of Object.entries(options.query ?? {})) {
      if (value !== undefined) url.searchParams.set(key, String(value));
    }

    const headers: Record<string, string> = { ...extraHeaders };
    const token = this.#tokens.getToken();
    if (token !== null) headers['Authorization'] = `Bearer ${token}`;
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (options.contentType !== undefined) headers['Content-Type'] = options.contentType;
    if (options.idempotencyKey !== undefined) {
      headers['Idempotency-Key'] = options.idempotencyKey;
    }

    const response = await this.#fetch(url.toString(), {
      method: options.method ?? 'GET',
      headers,
      ...(options.rawBody === undefined ? {} : { body: options.rawBody }),
      ...(options.body !== undefined ? { body: JSON.stringify(options.body) } : {}),
      ...(options.signal !== undefined ? { signal: options.signal } : {}),
      // The refresh token is an httpOnly cookie on the API's origin, so the
      // refresh call needs it sent cross-origin.
      credentials: 'include',
    });

    if (response.ok) return response;

    // One refresh attempt, never two. `_retried` is what stops an expired
    // refresh token from producing an infinite loop of 401s.
    if (response.status === 401 && options._retried !== true) {
      const refreshed = await this.#tokens.refresh();
      if (refreshed !== null) {
        return this.#send(path, { ...options, _retried: true }, extraHeaders, baseUrl);
      }
    }

    throw await this.#toError(response);
  }

  /**
   * Turns a failed response into an `ApiError`.
   *
   * A non-problem body is handled explicitly, because it means the response came
   * from something other than the API — a load balancer's HTML 502, a captive
   * portal, a proxy. Letting a JSON parse error escape from there produces a
   * message that sends the reader looking in the wrong place entirely.
   */
  async #toError(response: Response): Promise<ApiError> {
    let body: unknown;
    try {
      body = await response.json();
    } catch {
      body = undefined;
    }

    if (isProblem(body)) return new ApiError(body);

    const synthetic: Problem = {
      type: 'about:blank',
      title: `HTTP ${response.status}`,
      status: response.status,
      code:
        response.status === 413
          ? 'payload_too_large'
          : response.status >= 500
            ? 'service_unavailable'
            : 'bad_request',
      detail:
        'The server returned a response that was not a problem document. This usually ' +
        'means the request did not reach the API — check for a proxy or load balancer ' +
        'between the client and the server.',
      // The header is set by the API on every response, so its absence is itself
      // evidence the request never arrived.
      request_id: response.headers.get('x-request-id') ?? 'unknown',
    };
    return new ApiError(synthetic);
  }
}

/** Linear walk. `/\/+$/` was a polynomial-redos finding on a long slash suffix. */
export function trimTrailingSlashes(url: string): string {
  let end = url.length;
  while (end > 0 && url.charCodeAt(end - 1) === 47) {
    end -= 1;
  }
  return url.slice(0, end);
}
