/**
 * Cortex Design wire types.
 *
 * Paper page 13 names the product **Design** and the primary object a
 * **canvas**. Chat markdown sidecars stay `ChatCanvasId` (`cvs_`). These
 * identifiers are `DesignCanvasId` (`dcn_`).
 */

import type { CodeSessionId, ConversationId, DesignCanvasId, DesignLibraryItemId } from './ids.js';

export type DesignHost = 'chat' | 'code';
export type DesignCanvasStatus = 'empty' | 'drawing' | 'ready' | 'failed';
export type DesignLibraryKind = 'component' | 'page' | 'token';
export type DesignAssetKind = 'thumbnail' | 'tile' | 'image';
export type DesignSaveEncoding = 'snapshot' | 'delta';

export interface DesignCanvas {
  readonly id: DesignCanvasId;
  readonly title: string;
  readonly host: DesignHost;
  readonly host_title?: string;
  readonly conversation_id?: ConversationId;
  readonly code_session_id?: CodeSessionId;
  readonly current_revision: number;
  readonly option_count: number;
  readonly note_count: number;
  readonly frame_count: number;
  readonly status: DesignCanvasStatus;
  readonly thumbnail_digest?: string;
  readonly created_at: string;
  readonly updated_at: string;
}

export interface DesignCanvasPage {
  readonly items: readonly DesignCanvas[];
  readonly has_more: boolean;
}

/** Query for `GET /v1/design/canvases` — the canvases rail and in-flight panes. */
export interface DesignCanvasListQuery {
  readonly limit?: number;
  /** Search canvases (title and host thread title). */
  readonly q?: string;
  readonly host?: DesignHost;
  readonly conversation_id?: ConversationId;
  readonly code_session_id?: CodeSessionId;
}

/** Body for `POST /v1/design/canvases`. */
export interface DesignCanvasCreate {
  readonly title?: string;
  readonly host?: DesignHost;
  readonly host_title?: string;
  readonly conversation_id?: ConversationId;
  readonly code_session_id?: CodeSessionId;
}

/**
 * Body for `PATCH /v1/design/canvases/{id}`.
 *
 * Omit a host id to leave it. Empty string unbinds. A conversation id binds
 * Chat (and clears a Code session). A Code session id binds Code (and clears
 * a conversation). Both non-empty is refused.
 */
export interface DesignCanvasPatch {
  readonly title?: string;
  readonly host_title?: string;
  readonly status?: DesignCanvasStatus;
  readonly conversation_id?: ConversationId | '';
  readonly code_session_id?: CodeSessionId | '';
}

export interface DesignDocumentNode {
  readonly id: string;
  readonly kind:
    | 'frame'
    | 'group'
    | 'rectangle'
    | 'ellipse'
    | 'vector'
    | 'text'
    | 'image'
    | 'note'
    | 'component'
    | 'instance';
  readonly name: string;
  readonly option_key?: string;
  readonly status?: 'ready' | 'drawing' | 'failed';
  readonly x: number;
  readonly y: number;
  readonly w: number;
  readonly h: number;
  readonly parent_id?: string;
  readonly child_ids?: readonly string[];
  readonly text?: string;
  readonly asset_digest?: string;
}

export interface DesignDocument {
  readonly schema: 'cortex.design.document.v1';
  readonly page: { readonly width: number; readonly height: number };
  readonly root_ids: readonly string[];
  readonly nodes: Readonly<Record<string, DesignDocumentNode>>;
}

export interface DesignDocumentResponse {
  readonly canvas_id: DesignCanvasId;
  readonly revision: number;
  readonly encoding: DesignSaveEncoding;
  readonly pack: string;
  readonly digest: string;
  readonly content_hash: string;
  readonly document: DesignDocument;
  readonly option_count: number;
  readonly note_count: number;
  readonly frame_count: number;
}

export interface DesignRevision {
  readonly revision: number;
  readonly encoding: DesignSaveEncoding;
  readonly digest: string;
  readonly content_hash: string;
  readonly packed_bytes: number;
  readonly uncompressed_bytes: number;
  readonly node_count: number;
  readonly created_at: string;
}

export interface DesignViewerBlob {
  readonly digest: string;
  readonly content_type: string;
  readonly byte_size: number;
  readonly url: string;
}

export interface DesignViewerTile extends DesignViewerBlob {
  readonly z: number;
  readonly x: number;
  readonly y: number;
}

export interface DesignViewer {
  readonly canvas_id: DesignCanvasId;
  readonly revision: number;
  readonly renderers: readonly string[];
  readonly document?: DesignViewerBlob;
  readonly thumbnail?: DesignViewerBlob;
  readonly tiles: readonly DesignViewerTile[];
}

export interface DesignAsset {
  readonly digest: string;
  readonly kind: DesignAssetKind;
  readonly content_type: string;
  readonly byte_size: number;
  readonly tile_z?: number;
  readonly tile_x?: number;
  readonly tile_y?: number;
}

export interface DesignLibrarySummary {
  readonly components: number;
  readonly pages: number;
  readonly tokens: number;
}

export interface DesignLibraryItem {
  readonly id: DesignLibraryItemId;
  readonly kind: DesignLibraryKind;
  readonly name: string;
  readonly group_name?: string;
  readonly theme?: 'light' | 'dark' | 'both';
  /** Set by `POST /v1/design/library/items/{id}/thumbnail` (image body). */
  readonly thumbnail_digest?: string;
  readonly created_at: string;
  readonly updated_at: string;
}