/**
 * The error contract.
 *
 * Every failure from the API is an RFC 9457 `application/problem+json` document
 * with a stable `code`. That `code` is the discriminant of {@link Problem}, so a
 * `switch` over it is exhaustive and adding a new variant on the server is a
 * compile error here rather than a runtime surprise.
 *
 * `title` and `detail` are deliberately **not** part of the contract. They are
 * written for a human reading a response in a browser and will change wording
 * without notice. Branch on `code`; show `detail` if you have nowhere better to
 * put a message, but never parse it.
 *
 * This file mirrors `ErrorCode` in `server/src/core/error.ts`.
 * `scripts/check-type-drift.mjs` compares the two and fails CI if they diverge —
 * without that, the union silently stops being exhaustive and the frontend starts
 * falling through to a default branch for errors it should be handling.
 */

/**
 * RFC 9457 `type` prefix. Mirrored from `PROBLEM_TYPE_BASE` in
 * `server/src/core/error.ts`. Pages live on the Mintlify site at
 * `CortexLM/docs:problems/{code}.mdx`.
 */
export const PROBLEM_TYPE_BASE = 'https://docs.cortex.foundation/problems' as const;

/** The `type` URI the API puts on a problem document for this code. */
export function problemTypeUri(code: ErrorCode): string {
  return `${PROBLEM_TYPE_BASE}/${code}`;
}

/**
 * Every {@link ErrorCode}, as a value.
 *
 * The union below stays the source of truth for the type — `check-type-drift.mjs`
 * parses that declaration against Rust, and the two assertions under this array
 * make a list that has fallen behind the union a compile error. The array exists
 * because localization needs to *iterate* the codes: `apps/web` asserts that
 * every one of them has catalog copy, which a type alone cannot do.
 */
export const ERROR_CODES = [
  'validation_failed',
  'bad_request',
  'idempotency_key_reuse',
  'payload_too_large',
  'unsupported_media_type',
  'unauthenticated',
  'invalid_credential',
  'forbidden',
  'entitlement_required',
  'not_found',
  'conflict',
  'gone',
  'invalid_state',
  'quota_exceeded',
  'rate_limited',
  'concurrency_limit_reached',
  'safety_intervention',
  'content_policy',
  'jurisdiction_restricted',
  'internal',
  'upstream_failure',
  'upstream_timeout',
  'service_unavailable',
  'no_capacity',
] as const;

/** Machine-readable classification. Serialized `snake_case` by the server. */
export type ErrorCode =
  // --- 400 family ---
  | 'validation_failed'
  | 'bad_request'
  | 'idempotency_key_reuse'
  | 'payload_too_large'
  | 'unsupported_media_type'
  // --- 401 / 403 ---
  | 'unauthenticated'
  | 'invalid_credential'
  | 'forbidden'
  | 'entitlement_required'
  // --- 404 / 409 / 410 ---
  | 'not_found'
  | 'conflict'
  | 'gone'
  // --- 422 ---
  | 'invalid_state'
  // --- 429 ---
  | 'quota_exceeded'
  | 'rate_limited'
  | 'concurrency_limit_reached'
  // --- safety and compliance ---
  | 'safety_intervention'
  | 'content_policy'
  | 'jurisdiction_restricted'
  // --- 5xx ---
  | 'internal'
  | 'upstream_failure'
  | 'upstream_timeout'
  | 'service_unavailable'
  | 'no_capacity';

// Both directions, so neither the array nor the union can drift from the other.
type MissingFromList = Exclude<ErrorCode, (typeof ERROR_CODES)[number]>;
type MissingFromUnion = Exclude<(typeof ERROR_CODES)[number], ErrorCode>;
const _errorCodesCoverTheUnion: MissingFromList extends never ? true : never = true;
const _theUnionCoversErrorCodes: MissingFromUnion extends never ? true : never = true;
void _errorCodesCoverTheUnion;
void _theUnionCoversErrorCodes;

/** Per-field codes the server attaches to a `validation_failed` document. */
export const FIELD_ERROR_CODES = ['too_long', 'required', 'not_one_of'] as const;

export type FieldErrorCode = (typeof FIELD_ERROR_CODES)[number];

/** A field-level validation failure. */
export interface FieldError {
  /** JSON Pointer (RFC 6901) to the offending member, e.g. `/messages/0/role`. */
  readonly pointer: string;
  /** Stable per-field code: `too_long`, `required`, `not_one_of`. */
  readonly code: string;
  readonly message: string;
}

/** Members every problem document carries. */
interface ProblemBase {
  /** URI reference identifying the problem type. */
  readonly type: string;
  /** Short human-readable summary. Not contractual. */
  readonly title: string;
  readonly status: number;
  /**
   * Human-readable explanation of this occurrence. Absent for `internal`, by
   * design: an internal error renders nothing but a status and a request id, so
   * a stack trace or a connection string cannot reach a response body.
   */
  readonly detail?: string;
  /** URI reference for this occurrence; the request path. */
  readonly instance?: string;
  /**
   * Correlation id, always present and safe to show a user. This is the value to
   * put in a support form.
   */
  readonly request_id: string;
  readonly errors?: readonly FieldError[];
  /**
   * Which second-factor step unblocks this request (export, deletion):
   * enrol, answer a challenge, or (self-host `local`) enter the password again.
   */
  readonly mfa?: MfaRequirement;
}

/** `Problem.mfa`, mirrored from the OpenAPI `Problem` schema. */
export type MfaRequirement = 'enrollment_required' | 'challenge_required' | 'reauth_required';

/**
 * A plan quota window is exhausted.
 *
 * The extension members are what make the product's plan-limit notice truthful
 * rather than generic: `resets_at` renders the countdown, and `fallback_model` is
 * why the notice can say another model is still available.
 */
export interface QuotaExceededProblem extends ProblemBase {
  readonly code: 'quota_exceeded';
  /** When the window reopens, RFC 3339. Render a countdown from this. */
  readonly resets_at?: string;
  /** Seconds until the window reopens. Mirrors the `Retry-After` header. */
  readonly retry_after_seconds?: number;
  /** The quota that was hit, e.g. `reasoning_runs_per_day`. */
  readonly quota_key?: string;
  /** The plan in force when the limit was reached. */
  readonly plan?: string;
  /** A model still available under the current plan, if any. */
  readonly fallback_model?: string;
}

/**
 * Blocked by the crisis-intervention protocol.
 *
 * Always carries referral resources. The server has no code path that raises
 * this without them, because an intervention without a referral is the
 * California SB 243 §22602(b)(1) failure itself.
 *
 * Render `referral` prominently. This is the one error where the surrounding UI
 * matters more than the status code.
 */
export interface SafetyInterventionProblem extends ProblemBase {
  readonly code: 'safety_intervention';
  readonly referral?: {
    readonly name: string;
    readonly contact: string;
    readonly note: string;
  };
}

/** The caller's plan does not include this capability at all. */
export interface EntitlementRequiredProblem extends ProblemBase {
  readonly code: 'entitlement_required';
  /** The capability that is missing, e.g. `private_model_routing`. */
  readonly entitlement?: string;
  /** The lowest plan that includes it. Drives the upgrade call to action. */
  readonly required_plan?: string;
}

/** Transport-level throttling, unrelated to plan entitlements. */
export interface RateLimitedProblem extends ProblemBase {
  readonly code: 'rate_limited';
  readonly retry_after_seconds?: number;
}

/** Everything without extension members. */
export interface GenericProblem extends ProblemBase {
  readonly code: Exclude<
    ErrorCode,
    'quota_exceeded' | 'safety_intervention' | 'entitlement_required' | 'rate_limited'
  >;
}

/**
 * A failure from the API.
 *
 * Discriminated on `code`, so this is exhaustive:
 *
 * ```ts
 * switch (problem.code) {
 *   case 'quota_exceeded':
 *     // `problem.resets_at` is available here and nowhere else
 *     return showUpgradePrompt(problem);
 *   case 'safety_intervention':
 *     return showCrisisResources(problem.referral);
 *   default:
 *     return showError(problem);
 * }
 * ```
 */
export type Problem =
  | QuotaExceededProblem
  | SafetyInterventionProblem
  | EntitlementRequiredProblem
  | RateLimitedProblem
  | GenericProblem;

/** An API failure, carrying the problem document. */
export class ApiError extends Error {
  readonly problem: Problem;
  readonly status: number;

  constructor(problem: Problem) {
    // `detail` first: it is written for a human. Falling back to `title` rather
    // than to the code, because a user should never be shown `upstream_failure`.
    super(problem.detail ?? problem.title);
    this.name = 'ApiError';
    this.problem = problem;
    this.status = problem.status;
  }

  get code(): ErrorCode {
    return this.problem.code;
  }

  /** The id to quote in a support request. */
  get requestId(): string {
    return this.problem.request_id;
  }

  /**
   * Whether retrying the identical request is likely to succeed.
   *
   * Mirrors `ErrorCode::is_retryable` on the server. Note `quota_exceeded` is
   * *not* retryable: the caller must wait for `resets_at` or upgrade, and a retry
   * loop would only burn rate limit.
   */
  get isRetryable(): boolean {
    switch (this.problem.code) {
      case 'rate_limited':
      case 'internal':
      case 'upstream_failure':
      case 'upstream_timeout':
      case 'service_unavailable':
      case 'no_capacity':
      case 'conflict':
        return true;
      default:
        return false;
    }
  }

  /** Seconds to wait before retrying, when the server said. */
  get retryAfterSeconds(): number | undefined {
    if (this.problem.code === 'rate_limited' || this.problem.code === 'quota_exceeded') {
      return this.problem.retry_after_seconds;
    }
    return undefined;
  }
}

/**
 * Whether a value is a problem document.
 *
 * Used to tell a structured API failure from a network error or a proxy's HTML
 * error page. Without this check a 502 from a load balancer becomes a confusing
 * parse error rather than a recognisable outage.
 */
export function isProblem(value: unknown): value is Problem {
  if (typeof value !== 'object' || value === null) return false;
  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate['code'] === 'string' &&
    typeof candidate['status'] === 'number' &&
    typeof candidate['title'] === 'string' &&
    typeof candidate['request_id'] === 'string'
  );
}
