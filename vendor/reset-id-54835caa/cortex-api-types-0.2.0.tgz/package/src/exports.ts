/**
 * Chat document export (pptx / docx / xlsx / pdf).
 *
 * Export-first: Chat drafts an outline, the writers typeset it, Library
 * stores the outline so re-export does not call a model. Not a fourth
 * product mode and not a generate_* tool (`API-31`).
 */

export type ExportKind = 'deck' | 'document' | 'sheet' | 'pdf';
export type ExportTheme = 'cortex' | 'plain';

export type SlideLayout =
  | 'cover'
  | 'section'
  | 'title_bullets'
  | 'two_column'
  | 'table'
  | 'chart'
  | 'image'
  | 'sources';

export type ChartKind = 'bar' | 'line' | 'pie';

export interface ExportTable {
  readonly headers: readonly string[];
  readonly rows: readonly (readonly string[])[];
}

export interface ExportChartSeries {
  readonly name: string;
  readonly values: readonly number[];
}

export interface ExportChart {
  readonly kind: ChartKind;
  readonly categories: readonly string[];
  readonly series: readonly ExportChartSeries[];
}

export interface ExportSlide {
  readonly layout: SlideLayout;
  readonly title: string;
  readonly bullets?: readonly string[];
  readonly column_right?: readonly string[];
  readonly table?: ExportTable;
  readonly chart?: ExportChart;
  readonly notes?: string;
  readonly image_alt?: string;
}

export interface DeckOutline {
  readonly title: string;
  readonly subtitle?: string;
  readonly theme: ExportTheme;
  readonly slides: readonly ExportSlide[];
  readonly sources?: readonly string[];
  readonly disclosures?: readonly string[];
}

export type DocBlock =
  | { readonly kind: 'heading'; readonly level: 1 | 2 | 3; readonly text: string }
  | { readonly kind: 'paragraph'; readonly text: string }
  | { readonly kind: 'bullets'; readonly items: readonly string[] }
  | { readonly kind: 'table'; readonly table: ExportTable }
  | { readonly kind: 'footnote'; readonly text: string };

export interface DocOutline {
  readonly title: string;
  readonly theme: ExportTheme;
  readonly blocks: readonly DocBlock[];
  readonly disclosures?: readonly string[];
}

export type SheetCell = string | number | boolean | null;

export interface SheetOutline {
  readonly title: string;
  readonly theme: ExportTheme;
  readonly headers: readonly string[];
  readonly rows: readonly (readonly SheetCell[])[];
  readonly chart?: ChartKind;
}

export interface ExportOutline {
  readonly kind: ExportKind;
  readonly theme: ExportTheme;
  readonly deck?: DeckOutline;
  readonly document?: DocOutline;
  readonly sheet?: SheetOutline;
}

export interface ExportDraftRequest {
  readonly kind: ExportKind;
  readonly theme?: ExportTheme;
  readonly source: string;
}

export interface ExportCreateRequest extends ExportOutline {
  readonly conversation_id?: string;
}

export interface ExportReexportRequest {
  readonly outline?: ExportOutline;
  readonly conversation_id?: string;
}

export interface ExportFile {
  readonly id: string;
  readonly kind: ExportKind | string;
  readonly theme: ExportTheme | string;
  readonly filename: string;
  readonly content_type: string;
  readonly byte_size: number;
  readonly created_at: string;
  readonly outline: ExportOutline;
  readonly conversation_id?: string;
}

export interface CloudSaveStatus {
  readonly available: boolean;
  readonly providers: readonly string[];
}
