export type BugReportSurface = 'chat' | 'code' | 'bot';

/** `POST /v1/feedback/bugs`. */
export interface CreateBugReportRequest {
  readonly title: string;
  readonly description: string;
  readonly surface?: BugReportSurface;
  readonly screenshot_ids?: readonly string[];
  readonly path?: string;
  /** Email confirmation, questions and updates. Defaults to false. */
  readonly response_requested?: boolean;
}

/** Filing always opens a team ticket; email requires the reporter's consent. */
export interface CreateBugReportResponse {
  readonly id: string;
  readonly status: string;
  readonly response_requested: boolean;
  readonly team_response_required: boolean;
  readonly sla_due_at: string;
  readonly ticket_number: string;
}
