import type { BountyTermsCard } from './streaming.js';

/** Retained history wire from server/src/api/conversations.ts. */
export type HistoryRetention = 'retained' | 'deleted' | 'unavailable' | 'not_retained';

export interface HistoryMetadata {
  readonly card?: 'bounty_terms' | 'bounty_link';
  readonly hotkey?: string;
  readonly nonce?: string;
  readonly payload?: string;
  readonly expires_at?: string;
  readonly submit?: string;
  readonly duration_ms?: number;
  readonly tool_name?: string;
  readonly status?: string;
  readonly outcome?: 'ok' | 'error' | 'timeout' | 'refused' | 'interrupted';
  readonly truncated_chars?: number;
  readonly replaced_message_count?: number;
  readonly filename?: string;
  readonly file_id?: string;
  readonly content_type?: string;
  readonly byte_size?: number;
  readonly artifact_kind?: string;
  readonly caption_start?: number;
  readonly download_url?: string;
  readonly retention?: HistoryRetention;
  readonly kind?: string;
  readonly title?: string;
  readonly categories?: readonly string[];
  readonly series?: readonly { readonly name: string; readonly values: readonly number[] }[];
  readonly unit?: string;
  readonly generation_id?: string;
  readonly seed?: number;
  readonly library_file_ids?: readonly string[];
  readonly image_urls?: readonly string[];
  readonly check_id?: string;
  readonly verdict?: 'camera' | 'generated' | 'uncertain';
  readonly confidence?: number;
  readonly similarity?: number;
  readonly has_content_credentials?: boolean;
  readonly media_kind?: 'image' | 'video';
  readonly duration_label?: string;
  readonly error_code?: string;
  readonly request_id?: string;
  readonly index?: number;
  readonly url?: string;
  readonly domain?: string;
  readonly quote?: string;
  readonly group?: string;
  readonly dashboard_id?: string;
  readonly metric?: string;
  readonly source?: string;
  readonly points?: readonly { readonly label: string; readonly value: number }[];
}

export interface HistoryPart {
  readonly id: string;
  readonly sequence: number | null;
  readonly kind: 'text' | 'reasoning' | 'tool_call' | 'tool_result' | 'citation' | 'artifact' | 'summary' | 'research_plan' | 'research_report' | 'code_plan' | 'generated_image' | 'generated_file' | 'origin_check' | 'user_attachment' | 'chart' | 'data_dashboard';
  readonly text?: string;
  readonly metadata?: HistoryMetadata;
  readonly retention: HistoryRetention;
}

export interface HistoryMessage {
  readonly id: string;
  readonly role: string;
  readonly parent_message_id: string | null;
  readonly text: string;
  readonly created_at: string;
  readonly reasoning?: string;
  readonly reasoning_duration_ms?: number;
  readonly model_name?: string;
  readonly finish_reason?: string;
  readonly bounty_terms?: BountyTermsCard;
  readonly bounty_link?: HistoryMetadata;
  readonly research_plan?: { readonly title: string; readonly questions: readonly string[]; readonly outline: readonly string[]; readonly diagram: string; readonly scope?: { readonly domains: readonly string[]; readonly connectors?: readonly string[]; readonly project_sources: boolean } };
  readonly parts?: readonly HistoryPart[];
  readonly citations?: readonly { readonly type: 'citation'; readonly block_id: string; readonly index: number; readonly url: string; readonly title: string; readonly domain: string; readonly quote?: string }[];
  readonly generated_images?: readonly { readonly generation_id: string; readonly file_id?: string; readonly filename?: string; readonly library_file_ids?: readonly string[]; readonly image_urls?: readonly string[]; readonly retention: HistoryRetention; readonly download_url?: string; readonly content_type: string; readonly byte_size: number; readonly seed?: number; readonly duration_ms?: number; readonly caption_start?: number }[];
  readonly generated_files?: readonly HistoryMetadata[];
  readonly attachments?: readonly HistoryMetadata[];
  readonly charts?: readonly HistoryMetadata[];
  readonly origin_checks?: readonly HistoryMetadata[];
  readonly data_dashboards?: readonly HistoryMetadata[];
  readonly version_index: number;
  readonly version_count: number;
  readonly is_active_version: boolean;
}

export interface ConversationHistory {
  readonly items: readonly HistoryMessage[];
  readonly has_more: boolean;
  readonly has_older: boolean;
  readonly has_newer: boolean;
  readonly next_cursor?: string;
  readonly next_after_cursor?: string;
}

export type HistoryRequest = { readonly limit?: number } & (
  | { readonly before?: string; readonly after?: never; readonly message_id?: never }
  | { readonly before?: never; readonly after?: string; readonly message_id?: never }
  | { readonly before?: never; readonly after?: never; readonly message_id?: string }
);
