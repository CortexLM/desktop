/**
 * Branded identifier types.
 *
 * The server mints identifiers as `{prefix}_{crockford-base32}` — for example
 * `usr_01K3P7QW9XJ8ZB4T2M6N5R0VYD` — and gives each entity its own Rust type so
 * that passing a conversation id where a user id belongs will not compile. That
 * property is worth keeping on this side of the wire, because ID confusion
 * between sibling resources is a routine source of authorization bugs.
 *
 * TypeScript has no nominal types, so these are branded: structurally a `string`,
 * but not assignable to another brand. `parseId` is the only way in, and it
 * checks the prefix.
 *
 * The identifiers are also time-sortable, since the underlying value is a UUIDv7
 * rendered in Crockford base32. So lexicographic order is creation order, which
 * is what lets cursor pagination compare the wire form directly.
 */

declare const brand: unique symbol;

/** A `string` that is not interchangeable with another brand. */
type Branded<Prefix extends string> = string & { readonly [brand]: Prefix };

export type UserId = Branded<'usr'>;
export type OrganizationId = Branded<'org'>;
export type SessionId = Branded<'ses'>;
export type ProjectId = Branded<'prj'>;
export type ProjectSourceId = Branded<'psr'>;
export type ConversationId = Branded<'cnv'>;
export type MessageId = Branded<'msg'>;
export type MessageBlockId = Branded<'blk'>;
export type AttachmentId = Branded<'att'>;
export type ArtifactId = Branded<'art'>;
export type AgentRunId = Branded<'run'>;
export type AgentRunStepId = Branded<'stp'>;
export type ToolInvocationId = Branded<'tci'>;
export type SkillId = Branded<'skl'>;
export type MemoryId = Branded<'mem'>;
/** A billing plan in the public catalogue. */
export type PlanId = Branded<'pln'>;
/**
 * A structured task list the model maintains during a chat.
 *
 * Distinct from `PlanId`, which names a billing plan. Two different things with
 * one obvious name, so the brands keep them from being passed to each other.
 */
export type TaskPlanId = Branded<'tpl'>;
export type TaskPlanStepId = Branded<'tps'>;
export type LibraryFileId = Branded<'lbf'>;
export type ChatCanvasId = Branded<'cvs'>;
export type PluginConnectionId = Branded<'pcn'>;
export type SubscriptionId = Branded<'sub'>;
export type MascotId = Branded<'mst'>;
export type ComputerId = Branded<'cpt'>;
export type CodeSessionId = Branded<'cds'>;
export type CodeHostId = Branded<'hst'>;
/** A headless Code Cloud runtime: one isolated guest holding one repo. */
export type CodeRuntimeId = Branded<'crt'>;
/** A saved runtime overlay, keyed by repo + ref + harness version. */
export type CodeRuntimeImageId = Branded<'cri'>;
export type NotificationId = Branded<'ntf'>;
export type PermissionPromptId = Branded<'prm'>;
export type ComputerVideoId = Branded<'vid'>;
/** A persistable Cortex Design canvas (Paper page 13). Not a Chat markdown `cvs_` sidecar. */
export type DesignCanvasId = Branded<'dcn'>;
/** A component, page, or token in the Design Library drawer. */
export type DesignLibraryItemId = Branded<'dli'>;
/** A Cortex Science reproducible run (Chat-adjacent, not a fourth app). */
export type ScienceRunId = Branded<'scn'>;
export type ScienceNotebookId = Branded<'scb'>;
export type ScienceFigureId = Branded<'sfg'>;
export type ScienceCitationId = Branded<'sct'>;
export type ScienceComputeJobId = Branded<'scj'>;

/** Every prefix the server issues, and the entity it names. */
export const ID_PREFIXES = {
  usr: 'User',
  org: 'Organization',
  ses: 'Session',
  prj: 'Project',
  psr: 'ProjectSource',
  cnv: 'Conversation',
  msg: 'Message',
  blk: 'MessageBlock',
  att: 'Attachment',
  art: 'Artifact',
  run: 'AgentRun',
  stp: 'AgentRunStep',
  tci: 'ToolInvocation',
  skl: 'Skill',
  mem: 'Memory',
  pln: 'Plan',
  tpl: 'TaskPlan',
  tps: 'TaskPlanStep',
  lbf: 'LibraryFile',
  cvs: 'ChatCanvas',
  pcn: 'PluginConnection',
  sub: 'Subscription',
  mst: 'Mascot',
  cpt: 'Computer',
  cds: 'CodeSession',
  hst: 'CodeHost',
  crt: 'CodeRuntime',
  cri: 'CodeRuntimeImage',
  ntf: 'Notification',
  prm: 'PermissionPrompt',
  vid: 'ComputerVideo',
  dcn: 'DesignCanvas',
  dli: 'DesignLibraryItem',
  scn: 'ScienceRun',
  scb: 'ScienceNotebook',
  sfg: 'ScienceFigure',
  sct: 'ScienceCitation',
  scj: 'ScienceComputeJob',
} as const satisfies Record<string, string>;

export type IdPrefix = keyof typeof ID_PREFIXES;

/**
 * The body is 26 Crockford base32 characters. The alphabet excludes I, L, O and
 * U so that a hand-transcribed id cannot be ambiguous, which matters because
 * these appear in support tickets.
 */
const ID_BODY = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;

/**
 * Parses an identifier of a known prefix.
 *
 * Throws rather than returning a union, because a wrong-prefix id is a
 * programming error and not something a caller can recover from at runtime.
 */
export function parseId<P extends IdPrefix>(prefix: P, value: string): Branded<P> {
  const separator = value.indexOf('_');
  if (separator === -1) {
    throw new TypeError(`\`${value}\` is not an identifier: it has no \`_\` separator`);
  }

  const actual = value.slice(0, separator);
  if (actual !== prefix) {
    // Naming both is what makes this debuggable: the usual cause is passing the
    // wrong variable, and the message says which one arrived.
    throw new TypeError(
      `expected a ${ID_PREFIXES[prefix]} id (\`${prefix}_…\`) but got a \`${actual}_…\` id`,
    );
  }

  if (!ID_BODY.test(value.slice(separator + 1))) {
    throw new TypeError(`\`${value}\` has a malformed identifier body`);
  }

  return value as Branded<P>;
}

/** Whether a value is an identifier of the given prefix. */
export function isId<P extends IdPrefix>(prefix: P, value: unknown): value is Branded<P> {
  if (typeof value !== 'string') return false;
  try {
    parseId(prefix, value);
    return true;
  } catch {
    return false;
  }
}

/**
 * Adopts a string as an identifier without checking it.
 *
 * For values that came from the server and have therefore already been
 * validated. Deliberately verbose to call, because every use is a place the type
 * system stopped helping.
 */
export function unsafeAsId<P extends IdPrefix>(value: string): Branded<P> {
  return value as Branded<P>;
}
