/**
 * Library wire types (`API-32`).
 *
 * `LibraryFileId` is branded `lbf_…` in {@link ./ids.js}. Grant ids are
 * UUID strings — there is no `lgr_` prefix. This package mirrors the Rust
 * handlers; it does not invent a typesetting writer or a GiB cap.
 */

import type { ConversationId, LibraryFileId, MessageId, ProjectId, UserId } from './ids.js';

/** Filter pills on `library_files.kind`. Distinct from {@link ArtifactKind}. */
export type LibraryPillKind = 'image' | 'pdf' | 'code' | 'other';

/**
 * Product taxonomy on `library_files.artifact_kind`.
 *
 * The four pills stay `kind`. Do not overload them.
 */
export type ArtifactKind =
  | 'upload'
  | 'image'
  | 'deck'
  | 'document'
  | 'sheet'
  | 'pdf'
  | 'html'
  | 'report';

/** How the file entered the Library. */
export type LibrarySource = 'upload' | 'project' | 'generated';

/** Share role. Editor is a stub: no extra write policy yet. */
export type LibraryGrantRole = 'viewer' | 'editor';

/** One Library file. Bytes are a separate `GET …/content`. */
export interface LibraryFile {
  readonly id: LibraryFileId;
  readonly filename: string;
  readonly content_type: string;
  readonly byte_size: number;
  readonly kind: LibraryPillKind;
  readonly source: LibrarySource;
  readonly conversation_id?: ConversationId;
  readonly project_id?: ProjectId;
  readonly can_preview: boolean;
  readonly created_at: string;
  readonly artifact_kind: ArtifactKind;
  readonly source_message_id?: MessageId;
}

/** Query for `GET /v1/library`. */
export interface LibraryListQuery {
  readonly cursor?: string;
  readonly limit?: number;
  readonly q?: string;
  readonly kind?: LibraryPillKind;
  readonly artifact_kind?: ArtifactKind;
  readonly project_id?: ProjectId;
}

/** `POST /v1/library/notes`. Guests may save notes; they cannot share them. */
export interface LibraryNoteCreate {
  readonly text: string;
  readonly title?: string;
  readonly conversation_id?: ConversationId;
  readonly source_message_id?: MessageId;
}

/** One snapshot on `GET /v1/library/{id}/versions`. */
export interface LibraryVersion {
  readonly version: number;
  readonly byte_size: number;
  readonly content_type: string;
  readonly created_at: string;
}

/** A live share. `id` is a UUID string, not branded. */
export interface LibraryGrant {
  readonly id: string;
  readonly file_id: LibraryFileId;
  readonly grantee_id: UserId;
  readonly role: LibraryGrantRole;
  /** Null follows the latest restore. */
  readonly pinned_version?: number;
  readonly created_at: string;
}

/** `POST /v1/library/{id}/grants`. Invite with a user id or an email, not both. */
export interface LibraryGrantCreate {
  readonly user_id?: UserId;
  readonly email?: string;
  readonly role?: LibraryGrantRole;
  readonly pinned_version?: number;
}

/**
 * `GET /v1/library/usage`.
 *
 * Aggregate point-in-time storage. The plan limit is authoritative and
 * independent of the 10 MiB single-upload ceiling.
 */
export interface LibraryUsage {
  readonly used_bytes: number;
  /** Null only for an explicitly unlimited plan. */
  readonly limit_bytes: number | null;
  readonly plan: string;
}

/** Shared request body for pinning a Chat conversation or project. */
export interface ChatPinPatch {
  readonly pinned: boolean;
}

/** Extra list metadata used to distinguish never-pinned from now-empty. */
export interface ChatPinnedListMeta {
  readonly has_ever_pinned: boolean;
}
