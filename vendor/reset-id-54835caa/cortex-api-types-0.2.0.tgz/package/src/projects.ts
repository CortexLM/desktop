/**
 * Cortex Projects wire types.
 *
 * A project is a **container** — instructions, chats, and sources the model
 * can actually read — not a chat folder and not a fourth Chat | Code | Bot
 * tab. Agentic work from a project is a handoff to Bot or Code (`API-35`).
 */

import type {
  CodeSessionId,
  ConversationId,
  LibraryFileId,
  MascotId,
  MessageId,
  ProjectId,
  ProjectSourceId,
} from './ids.js';

export type ProjectSourceKind =
  | 'file'
  | 'url'
  | 'connector_ref'
  | 'saved_message'
  | 'text'
  | 'repository';

export type ProjectKnowledgeMode = 'inline' | 'retrieve' | 'unavailable' | 'empty';

export type ProjectHandoffTarget = 'bot' | 'code';

/** `GET/POST /v1/projects` and `GET/PATCH /v1/projects/{id}`. */
export interface Project {
  readonly id: ProjectId;
  readonly name: string;
  readonly description?: string;
  readonly conversation_count: number;
  readonly file_count: number;
  readonly updated_at: string;
  /** Detail only. List omits this so the grid does not decrypt every card. */
  readonly instructions?: string;
  readonly source_count?: number;
  /** Detail only. Sum of extracted characters. There is no `/estimate` route. */
  readonly knowledge_chars?: number;
}

/** `POST /v1/projects`. */
export interface ProjectCreate {
  readonly name: string;
  readonly instructions?: string;
}

/** `PATCH /v1/projects/{id}`. `null` clears instructions. */
export interface ProjectPatch {
  readonly name?: string;
  readonly instructions?: string | null;
}

/**
 * A source on `GET /v1/projects/{id}/sources`. Bodies and connector refs stay
 * off the wire; `url` is decrypted for the owner.
 */
export interface ProjectSource {
  readonly id: ProjectSourceId;
  readonly kind: ProjectSourceKind;
  readonly title: string;
  readonly domain?: string;
  readonly citation?: string;
  readonly repo?: string;
  readonly library_file_id?: LibraryFileId;
  readonly message_id?: MessageId;
  readonly content_chars: number;
  readonly last_refreshed_at?: string;
  readonly refresh_error?: string;
  readonly url?: string;
  readonly created_at: string;
  readonly updated_at: string;
}

/** `POST /v1/projects/{id}/sources`. */
export interface ProjectSourceCreate {
  readonly kind: ProjectSourceKind;
  readonly title?: string;
  readonly url?: string;
  readonly text?: string;
  readonly library_file_id?: LibraryFileId;
  readonly message_id?: MessageId;
  readonly repo?: string;
  readonly connector?: string;
  readonly connector_ref?: string;
}

/** One passage from `GET /v1/projects/{id}/knowledge`. */
export interface ProjectPassage {
  readonly source_id: ProjectSourceId;
  readonly title: string;
  readonly citation?: string;
  readonly text: string;
}

/**
 * The same retrieve a Chat turn uses, unwrapped so a client (and tests)
 * can see a unique token. The model path wraps this as `project_files`.
 */
export interface ProjectKnowledge {
  readonly mode: ProjectKnowledgeMode;
  readonly knowledge_chars: number;
  readonly passages: readonly ProjectPassage[];
}

/** `POST /v1/projects/{id}/handoff`. */
export interface ProjectHandoffRequest {
  readonly target: ProjectHandoffTarget;
  readonly mascot_id?: MascotId;
  readonly prompt?: string;
}

/** Bot is 200; Code is 201 with a Cloud session. */
export interface ProjectHandoff {
  readonly target: ProjectHandoffTarget;
  readonly mascot_id?: MascotId;
  readonly session_id?: CodeSessionId;
  readonly repo?: string;
}

/** Re-export so a caller can type `GET /v1/projects/{id}/chats`. */
export type { ConversationId };
