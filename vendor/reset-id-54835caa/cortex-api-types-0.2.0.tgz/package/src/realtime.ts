/**
 * Multiplexed realtime contract for Chat, Code and Bot.
 *
 * Mirrors `server/src/api/realtime.ts`. The WebSocket at
 * `GET /v1/realtime` and the SSE fallback at `GET /v1/realtime/events`
 * carry the same envelope. Chat turns still stream on
 * `POST /v1/conversations/{id}/turns` (existing `StreamEvent` union).
 */

import type { CodeSessionId, ConversationId, MascotId } from './ids.js';

export interface RealtimeFallback {
  readonly chat_sse: string;
  readonly events_sse: string;
}

export interface RealtimeHello {
  readonly type: 'hello';
  readonly user_id: string;
  readonly heartbeat_seconds: number;
  readonly fallback: RealtimeFallback;
}

export interface RealtimeHeartbeat {
  readonly type: 'heartbeat';
}

export interface RealtimeResync {
  readonly type: 'resync';
  readonly reason: string;
}

export interface RealtimeSubscribed {
  readonly type: 'subscribed';
  readonly room: string;
}

export interface RealtimeError {
  readonly type: 'error';
  readonly code: string;
  readonly detail: string;
}

export interface ScheduledTaskResult {
  readonly task_id: string;
  readonly title: string;
  readonly summary: string;
  readonly status: string;
  readonly message_id?: string;
}

export type ChatRealtimeKind =
  | { readonly kind: 'token'; readonly delta: string }
  | { readonly kind: 'turn_event'; readonly payload: unknown }
  | { readonly kind: 'scheduled_task_result'; readonly result: ScheduledTaskResult };

export interface ChatRealtime {
  readonly type: 'chat';
  readonly conversation_id: ConversationId;
  readonly message_id?: string;
  readonly event: ChatRealtimeKind;
}

export interface PermissionPrompt {
  readonly id: string;
  readonly tool_name: string;
  readonly summary: string;
  readonly detail: string;
}

export type CodeRealtimeKind =
  | { readonly kind: 'state'; readonly state: string }
  | { readonly kind: 'plan'; readonly text: string }
  | { readonly kind: 'token'; readonly delta: string }
  | { readonly kind: 'tool'; readonly name: string; readonly phase: string; readonly summary: string }
  | { readonly kind: 'permission'; readonly prompt: PermissionPrompt }
  | { readonly kind: 'terminal'; readonly stream: string; readonly chunk: string }
  | { readonly kind: 'diff'; readonly path: string; readonly patch: string };

export interface CodeRealtime {
  readonly type: 'code';
  readonly session_id: CodeSessionId;
  readonly event: CodeRealtimeKind;
}

/** The server tool-policy verdict on one evaluated Bot tool call (`API-36`). */
export type ToolEvaluation = 'run' | 'deny' | 'pause';

/** Widget fields on a live `ask_user` / `send_to_user` frame. */
export interface BotWidgetPayload {
  readonly options?: readonly string[];
  readonly field?: string;
  readonly multi?: boolean;
  readonly destructive?: boolean;
  readonly approval_id?: string;
  readonly tool?: string;
  /** Present on a confirm widget the tool policy paused. */
  readonly evaluation?: ToolEvaluation;
  readonly reason?: string;
}

export type BotRealtimeKind =
  | {
      readonly kind: 'ask_user';
      readonly message_id: string;
      readonly widget: string;
      readonly text: string;
      readonly approval_id?: string;
      readonly payload?: BotWidgetPayload;
    }
  | { readonly kind: 'wake'; readonly computer_status: string }
  | { readonly kind: 'computer_session'; readonly status: string; readonly ticket_id?: string | null }
  | { readonly kind: 'token'; readonly delta: string }
  | {
      readonly kind: 'tool_call';
      readonly name: string;
      readonly summary: string;
      /**
       * The server's evaluation of this call and the reason it decided.
       * Absent on a frame the policy never saw (the stuck-loop guard).
       */
      readonly evaluation?: ToolEvaluation;
      readonly reason?: string;
    }
  | { readonly kind: 'tool_result'; readonly name: string; readonly result: string }
  | {
      readonly kind: 'send_to_user';
      readonly message_id: string;
      readonly message_kind: string;
      readonly text: string;
      readonly approval_id?: string;
      readonly payload?: BotWidgetPayload;
    }
  | { readonly kind: 'computer_offline'; readonly reason: string };

export interface BotRealtime {
  readonly type: 'bot';
  /** Same string as `GET /v1/mascots` `id` (a UUID, not `mst_…`). */
  readonly mascot_id: string;
  readonly event: BotRealtimeKind;
}

export interface NotificationPush {
  readonly type: 'notification';
  readonly id: string;
  readonly kind:
    | 'scheduled_task_result'
    | 'mention'
    | 'code_run_done'
    | 'code_run_blocked'
    | 'bot_ask_user'
    | 'farm_wake_fail';
  readonly title: string;
  readonly body: string;
  readonly conversation_id?: string;
  readonly code_session_id?: string;
  readonly mascot_id?: string;
}

export type RealtimeEvent =
  | RealtimeHello
  | RealtimeHeartbeat
  | RealtimeResync
  | RealtimeSubscribed
  | RealtimeError
  | ChatRealtime
  | CodeRealtime
  | BotRealtime
  | NotificationPush;

export interface RealtimeFrame {
  readonly id: string;
  readonly ts: string;
}

export type RealtimeMessage = RealtimeFrame & RealtimeEvent;

/** Rooms a client may subscribe to after the implicit per-user room. */
export type RealtimeRoom =
  | `conversation:${ConversationId}`
  | `code_session:${CodeSessionId}`
  | `mascot:${MascotId}`;

export type ClientOp =
  | { readonly op: 'subscribe'; readonly room: RealtimeRoom }
  | { readonly op: 'unsubscribe'; readonly room: RealtimeRoom }
  | { readonly op: 'resume'; readonly last_event_id: string }
  | { readonly op: 'ping' }
  | { readonly op: 'pong' };

/** Code session states the Electron / web app renders. */
export type CodeSessionState =
  | 'cloud_only'
  | 'connecting'
  | 'connected'
  | 'disconnected'
  | 'running'
  | 'permission_blocked'
  | 'failed'
  | 'unpaired'
  | 'waiting'
  | 'completed'
  | 'interrupted';
