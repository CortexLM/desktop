/**
 * Wire types for Cortex Science.
 *
 * Science is a Chat-adjacent mode, not a fourth Chat | Code | Bot app
 * (`API-32`). Public discovery is `GET /v1/science/capabilities`. Durable
 * runs are member-only. Literature and compute fail closed in this release.
 */

export interface ScienceCapabilities {
  readonly product: 'Cortex Science';
  readonly domain: 'cortex.foundation';
  readonly surface: 'chat';
  readonly fourth_app: false;
  readonly web_ui: 'paper_hold';
  readonly available: false;
  readonly literature: {
    readonly available: false;
    readonly unavailable_reason: 'literature_not_configured';
    readonly search: '/v1/science/literature/search';
  };
  readonly compute: {
    readonly available: false;
    readonly unavailable_reason: 'science_compute_not_configured';
    readonly start: '/v1/science/compute';
    readonly targets: readonly ['local', 'kernel', 'hpc'];
  };
  readonly runs: {
    readonly list: '/v1/science/runs';
    readonly create: '/v1/science/runs';
    readonly item: '/v1/science/runs/{id}';
  };
}

export type ScienceComputeTarget = 'local' | 'kernel' | 'hpc';
export type ScienceRunStatus = 'recorded' | 'running' | 'completed' | 'failed';
export type ScienceEnvironment = 'none' | 'local' | 'kernel' | 'hpc';

export interface ScienceRun {
  readonly id: string;
  readonly title: string;
  readonly host: 'chat';
  readonly conversation_id?: string;
  readonly status: ScienceRunStatus;
  readonly environment: ScienceEnvironment;
  readonly created_at: string;
  readonly updated_at: string;
}

export interface ScienceCitation {
  readonly id: string;
  readonly run_id: string;
  readonly doi?: string;
  readonly url?: string;
  readonly title?: string;
  readonly source_kind: 'user_supplied';
  readonly created_at: string;
}

export interface ScienceNotebook {
  readonly id: string;
  readonly run_id: string;
  readonly schema: 'cortex.science.notebook.v1';
  readonly cells: readonly { readonly kind: string; readonly source: string }[];
}
