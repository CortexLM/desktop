/** Operator-configured identities; requests cannot supply a From address. */
export type SupportMailSender = 'transactional' | 'bot' | 'personal';

/** `POST /v1/support/reports/{id}/automation`, authenticated by x-cortex-support-token. */
export type SupportAutomationRequest =
  | {
      readonly action: 'request_information';
      /** UUID reused when retrying the same question. */
      readonly request_id: string;
      readonly message: string;
      readonly sender?: SupportMailSender | null;
    }
  | {
      readonly action: 'link_pull_request';
      readonly pull_request_number: number;
    }
  | {
      readonly action: 'resolve';
      readonly message: string;
      readonly sender?: SupportMailSender | null;
    };

export interface SupportAutomationResponse {
  readonly report_id: string;
  readonly ticket_number: string;
  readonly status: string;
  /** Resolution remains open while its required email awaits delivery. */
  readonly delivery_pending: boolean;
}

/** `POST /v1/support/deployments`, using the separate deployment credential. */
export interface SupportDeploymentRequest {
  readonly repository: 'CortexLM/backend';
  /** Full lowercase 40-hex source SHA of the verified production image. */
  readonly source_sha: string;
  readonly pull_request_number: number;
  /** RFC 3339 merge timestamp from independently verified GitHub metadata. */
  readonly merged_at: string;
  readonly run_id: number;
  readonly run_attempt: number;
}

export interface SupportDeploymentResponse {
  readonly recorded: true;
}

/** Decrypted only for the authorized webhook receiver; never log the body. */
export interface SupportAutomationReport {
  readonly id: string;
  readonly title: string;
  readonly description: string;
  readonly status: string;
  readonly response_requested: boolean;
  readonly ticket_number: string | null;
  readonly surface: string | null;
  readonly path: string | null;
  readonly created_at: string;
  readonly screenshot_count: number;
}

/** At-least-once webhook; event_id is also the idempotency-key header. */
export interface SupportReportEvent {
  readonly event: 'bug_report.created' | 'bug_report.reply_received';
  readonly event_id: string;
  readonly repository: 'CortexLM/backend';
  readonly report_id: string;
  readonly report: SupportAutomationReport;
  /** Present for reply_received; decrypted only for the authorized receiver. */
  readonly reply?: {
    readonly id: string;
    readonly body: string;
  };
}
