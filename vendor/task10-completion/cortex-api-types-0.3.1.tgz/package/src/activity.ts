/**
 * Safe projection of `AgentEvent` records from `GET /v1/{mascots|code/sessions|code/runtimes}/{id}/events`.
 *
 * The wire `payload` stays `unknown`: the producer persists whatever its caller
 * passes and the database checks only `kind` and `resource`. This projection
 * types a payload field only where a producer call site writes it and the field
 * is already owner-visible elsewhere. Everything else is omitted, and kinds
 * without a proven producer (`wake_fail`, `permission_prompt`) or unknown future
 * kinds project as opaque metadata. No projection carries an action, decision,
 * prompt, tool argument, ticket or URL, and `user_id` is always dropped.
 *
 * Kind sets differ by source: `events.ts` `KINDS` lists six kinds and omits
 * `environment_progress`; migration 0139 admits seven kinds in the database
 * check. Treat `kind` as open, never as the six-member constant.
 *
 * Live SSE delivery is process-local and published before the persisting
 * transaction commits; a frame is not a committed outcome. Re-read the owned
 * resource (or a fresh `since` page) before acting on any projection.
 */

/** Widget kinds accepted by `POST /v1/mascots/{id}/ask-user` (ASK_KINDS). */
export type BotAskWidgetKind = 'question' | 'multi_select' | 'secret_request' | 'confirm' | 'notice' | 'waiting';

/** Code runtime preparation phases: harness tool names plus model `note`. */
export type EnvironmentProgressPhase =
  | 'note'
  | 'shell'
  | 'read_file'
  | 'write_file'
  | 'list_dir'
  | 'environment_ready'
  | 'environment_failed';

interface ActivityMeta<K extends string, R extends string> {
  readonly opaque: false;
  readonly id: string;
  readonly kind: K;
  readonly resource: R;
  readonly resource_id: string;
  readonly at: string;
}

/** A widget was posted; re-read the owned Bot message before rendering or answering it. */
export interface AgentAskUserActivity extends ActivityMeta<'ask_user', 'mascot'> {
  /** Raw message UUID. */
  readonly message_id: string;
  readonly widget: BotAskWidgetKind;
}

/** A recording became ready; request a fresh ticket through the video routes, never from this record. */
export interface AgentVideoReadyActivity extends ActivityMeta<'video_ready', 'mascot'> {
  /** Raw video UUID. */
  readonly video_id: string;
  readonly title: string;
}

/**
 * A preparation phase started. `detail` is omitted: it carries shell commands,
 * paths and model prose. Not a Bot activity and not proof that a step succeeded.
 */
export interface AgentEnvironmentProgressActivity extends ActivityMeta<'environment_progress', 'code_runtime'> {
  readonly phase: EnvironmentProgressPhase;
}

export interface AgentHostConnectedActivity extends ActivityMeta<'host_connected', 'code_session'> {
  /** Raw host UUID. */
  readonly host_id: string;
  readonly hostname: string;
}

export type AgentHostDisconnectedActivity = ActivityMeta<'host_disconnected', 'code_session'>;

/** Unknown, unproven or malformed records: metadata only, never actionable. */
export interface AgentOpaqueActivity {
  readonly opaque: true;
  readonly id: string;
  readonly kind: string;
  readonly resource: string;
  readonly resource_id: string;
  readonly at: string;
}

export type AgentKnownActivity =
  | AgentAskUserActivity
  | AgentVideoReadyActivity
  | AgentEnvironmentProgressActivity
  | AgentHostConnectedActivity
  | AgentHostDisconnectedActivity;

export type AgentActivity = AgentKnownActivity | AgentOpaqueActivity;

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const WIDGETS: readonly string[] = ['question', 'multi_select', 'secret_request', 'confirm', 'notice', 'waiting'];
const PHASES: readonly string[] = ['note', 'shell', 'read_file', 'write_file', 'list_dir', 'environment_ready', 'environment_failed'];

const record = (v: unknown): Record<string, unknown> | undefined =>
  v !== null && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : undefined;
const str = (v: unknown): string | undefined => (typeof v === 'string' ? v : undefined);
const uuid = (v: unknown): string | undefined => (typeof v === 'string' && UUID.test(v) ? v.toLowerCase() : undefined);

/**
 * Projects one AgentEvent (JSON page item or SSE `data`). Returns `undefined`
 * when even the envelope is malformed; such a record must be ignored.
 */
export function projectAgentEvent(event: unknown): AgentActivity | undefined {
  const e = record(event);
  const id = uuid(e?.['id']), kind = str(e?.['kind']), resource = str(e?.['resource']);
  const resourceId = uuid(e?.['resource_id']), at = str(e?.['at']);
  if (!e || !id || !kind || !resource || !resourceId || !at) return undefined;
  const opaque: AgentOpaqueActivity = { opaque: true, id, kind, resource, resource_id: resourceId, at };
  const p = record(e['payload']);
  const meta = { opaque: false as const, id, resource_id: resourceId, at };
  if (kind === 'ask_user' && resource === 'mascot') {
    const messageId = uuid(p?.['message_id']), widget = str(p?.['kind']);
    return messageId && widget && WIDGETS.includes(widget)
      ? { ...meta, kind, resource, message_id: messageId, widget: widget as BotAskWidgetKind }
      : opaque;
  }
  if (kind === 'video_ready' && resource === 'mascot') {
    const videoId = uuid(p?.['video_id']), title = str(p?.['title']);
    return videoId && title !== undefined ? { ...meta, kind, resource, video_id: videoId, title } : opaque;
  }
  if (kind === 'environment_progress' && resource === 'code_runtime') {
    const phase = str(p?.['phase']);
    return phase && PHASES.includes(phase) ? { ...meta, kind, resource, phase: phase as EnvironmentProgressPhase } : opaque;
  }
  if (kind === 'host_connected' && resource === 'code_session') {
    const hostId = uuid(p?.['host_id']), hostname = str(p?.['hostname']);
    return hostId && hostname ? { ...meta, kind, resource, host_id: hostId, hostname } : opaque;
  }
  if (kind === 'host_disconnected' && resource === 'code_session') return { ...meta, kind, resource };
  return opaque;
}
