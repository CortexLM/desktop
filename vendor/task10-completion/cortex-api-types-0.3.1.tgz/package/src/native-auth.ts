/** Native credentials reuse the existing CLI pair; expiry is signed JWT exp. */
export type NativeSession = import('./cli.js').CliSession;
