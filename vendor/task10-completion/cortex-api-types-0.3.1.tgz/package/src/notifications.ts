/** Safe notification list wire; realtime push omits read/created_at/task_id. */
export interface NotificationItem {
  readonly id: string;
  readonly kind: string;
  readonly title: string;
  readonly body: string;
  readonly read: boolean;
  readonly created_at: string;
  readonly conversation_id?: string;
  readonly code_session_id?: string;
  /** Branded mst_, not raw roster UUID. */
  readonly mascot_id?: string;
  readonly task_id?: string;
}
export interface NotificationPage {
  readonly items: readonly NotificationItem[];
  readonly has_more: false;
}
export interface NotificationListQuery { readonly limit?: number; readonly unread?: boolean }
