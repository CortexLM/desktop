/**
 * Bot call client protocol over the `cortex-live-v1` media socket, shared by the
 * web tab and Electron main (Task16). DOM-free: HTTP, the socket and the clock
 * are injected, so each client supplies its own transport and `CallEnv`.
 *
 * `CallSession` owns tickets, the socket, frame sequence/epoch/generation,
 * `played` credits, resume and end. Muted, no capture frames are sent and the
 * mute control drops any partial utterance server-side. Playback is credited
 * only after it is heard, so the server's `limits.playback_credits` caps what a
 * client buffers. Barge-in flushes local playback and sends `interrupt`.
 *
 * A dropped socket resumes with a fresh ticket and the next epoch, retrying
 * with backoff (and waiting for connectivity while offline) until the lease the
 * server last granted runs out; close 4001 (signed out), 1000 (ended) and 4000
 * (superseded) end the call. A binary frame that does not decode is a protocol
 * error: it is counted and ends the call `failed` with `protocol_error` set.
 */
import { decodeLiveFrame, encodeLiveFrame, LIVE_FRAME, parseAudioCapabilities, type LiveFrame } from './live-calls.js';

export const CALL_SAMPLE_RATE = 16_000;
export const CALL_FRAME_SAMPLES = LIVE_FRAME.audio_bytes / 2;
const REVOKE_GRACE_MS = 2_000;
/** Resume backoff; the last step repeats until the lease deadline. */
const RESUME_BACKOFF_MS = [500, 1_000, 2_000, 4_000];

export type CallPhase = 'connecting' | 'listening' | 'hearing' | 'thinking' | 'speaking' | 'reconnecting' | 'ended' | 'error';
export type CallEnd = 'ended' | 'auth_revoked' | 'superseded' | 'unavailable' | 'busy' | 'failed' | 'mic_lost';
export interface CallSnapshot {
  readonly phase: CallPhase;
  readonly muted: boolean;
  /** Recognised utterances, oldest first. Replies are audio only. */
  readonly heard: readonly string[];
  /** The current utterance as recognised so far (streaming recognition only); never persisted. */
  readonly partial: string;
  /** The server recognises while the caller speaks (`capabilities.stt === 'streaming'` on the ticket). */
  readonly streaming: boolean;
  readonly end?: CallEnd;
  /** Set with `end: 'failed'` when the server sent a frame that does not decode (the decoder's reason). */
  readonly protocol_error?: string;
  /**
   * The server's `error` code for the last utterance (recognition, the turn or synthesis failed). The call
   * stays open and listening; cleared by the next utterance or reply. Without it a failed turn looks like silence.
   */
  readonly turn_error?: string | undefined;
}
export interface CallStats { sent: number; mutedDropped: number; received: number; staleDropped: number; acked: number; flushed: number; maxQueued: number; resumed: number; resumeAttempts: number; generation: number; closeCodes: number[]; protocolErrors: number }

export interface CallSocket {
  send(data: string | Uint8Array): void;
  close(): void;
}
export interface CallSocketEvents {
  message(data: ArrayBuffer | string): void;
  close(code: number): void;
}
/** HTTP + socket seams: the web passes the tab client; desktop main its own identity. */
export interface CallTransport {
  post(path: string, body: unknown): Promise<{ status: number; body: unknown }>;
  del(path: string): Promise<void>;
  open(wsPath: string, on: CallSocketEvents): CallSocket;
}
/** Clock and connectivity seams for resume; required, so each client states its own. */
export interface CallEnv {
  now(): number;
  sleep(ms: number): Promise<void>;
  online(): boolean;
  /** Resolves when connectivity may be back or after `ms`, whichever is first. */
  waitOnline(ms: number): Promise<void>;
}
export interface CallSink {
  /** A playback frame; call `session.played` once it has been heard. */
  play(pcm: Uint8Array, sequence: number, generation: number): void;
  /** Stop and discard queued playback (barge-in, resume, end). */
  flush(): void;
}

/** True only for an available `bot_call` block (utterance or streaming); `live` (Chat Live) is never consulted. */
export function botCallAvailable(body: unknown): boolean {
  return parseAudioCapabilities(body)?.bot_call.available === true;
}

interface Ticket { readonly id: string; readonly epoch: string; readonly ws_path: string; readonly lease_expires_at?: string; readonly capabilities?: { readonly stt?: unknown } }
const isTicket = (v: unknown): v is Ticket =>
  !!v && typeof v === 'object' && typeof (v as Ticket).id === 'string' && typeof (v as Ticket).ws_path === 'string' && typeof (v as Ticket).epoch === 'string';

export class CallSession {
  readonly stats: CallStats = { sent: 0, mutedDropped: 0, received: 0, staleDropped: 0, acked: 0, flushed: 0, maxQueued: 0, resumed: 0, resumeAttempts: 0, generation: 1, closeCodes: [], protocolErrors: 0 };
  #snap: CallSnapshot = { phase: 'connecting', muted: false, heard: [], partial: '', streaming: false };
  #listeners = new Set<(s: CallSnapshot) => void>();
  #socket: CallSocket | null = null;
  #open = false;
  #call: Ticket | null = null;
  /** Epoch ms after which the server reaps the call (`lease_expires_at` of the last ticket). */
  #leaseUntil = 0;
  #epoch = 0n;
  #seq = 0;
  #generation = 1;
  #closed = false;
  /** Between our `interrupt` and the server's `interrupted`: in-flight playback is stale. */
  #barging = false;
  sink: CallSink | null = null;

  constructor(private readonly transport: CallTransport, private readonly botId: string, private readonly env: CallEnv) {}

  get snapshot(): CallSnapshot { return this.#snap; }
  get closed(): boolean { return this.#closed; }
  subscribe(fn: (s: CallSnapshot) => void): () => void { this.#listeners.add(fn); fn(this.#snap); return () => { this.#listeners.delete(fn); }; }
  #set(patch: Partial<CallSnapshot>): void {
    if (this.#closed && patch.phase !== 'ended' && patch.phase !== 'error') return;
    this.#snap = { ...this.#snap, ...patch };
    for (const fn of this.#listeners) fn(this.#snap);
  }

  async start(): Promise<void> {
    const res = await this.transport.post('/v1/live/sessions', { surface: 'bot', consent: 'allow', bot_id: this.botId })
      .catch(() => ({ status: 0, body: null }));
    if (this.#closed) {
      if (isTicket(res.body)) await this.transport.del(`/v1/live/sessions/${res.body.id}`).catch(() => undefined);
      return;
    }
    if (res.status !== 201 || !isTicket(res.body)) return this.#finish(res.status === 503 ? 'unavailable' : res.status === 409 ? 'busy' : 'failed');
    this.#set({ streaming: res.body.capabilities?.stt === 'streaming' });
    this.#connect(res.body);
  }

  #connect(ticket: Ticket): void {
    this.#call = ticket;
    const lease = Date.parse(ticket.lease_expires_at ?? '');
    // Without a lease the server's default (30 s) bounds resume.
    this.#leaseUntil = Number.isFinite(lease) ? lease : this.env.now() + 30_000;
    this.#epoch = BigInt(ticket.epoch);
    this.#seq = 0;
    this.#open = false;
    const socket = this.transport.open(ticket.ws_path, {
      message: (d) => { if (this.#socket === socket) this.#receive(d); },
      close: (code) => { this.stats.closeCodes.push(code); if (this.#socket === socket) void this.#onClose(code); },
    });
    this.#socket = socket;
  }

  async #onClose(code: number): Promise<void> {
    this.#socket = null;
    this.#open = false;
    if (this.#closed) return;
    if (code === 4001) return this.#finish('auth_revoked');
    if (code === 1000) return this.#finish('ended');
    if (code === 4000) return this.#finish('superseded');
    if (code === 1008) return this.#finish('failed');
    const call = this.#call;
    if (!call) return this.#finish('failed');
    // Network drop: the call stays resumable until its lease runs out.
    this.#flush();
    this.#set({ phase: 'reconnecting', partial: '' });
    for (let attempt = 0; ; attempt++) {
      const left = this.#leaseUntil - this.env.now();
      if (left <= 0) break;
      if (!this.env.online()) await this.env.waitOnline(left);
      else if (attempt > 0) await this.env.sleep(Math.min(RESUME_BACKOFF_MS[Math.min(attempt - 1, RESUME_BACKOFF_MS.length - 1)]!, left));
      if (this.#closed) return;
      if (!this.env.online() || this.env.now() >= this.#leaseUntil) continue;
      this.stats.resumeAttempts++;
      const res = await this.transport.post(`/v1/live/sessions/${call.id}/resume`, { epoch: call.epoch })
        .catch(() => ({ status: 0, body: null }));
      if (this.#closed) return;
      if (res.status === 200 && isTicket(res.body)) {
        this.stats.resumed++;
        return this.#connect(res.body);
      }
      if (res.status === 410) return this.#finish('ended');
      if (res.status === 409) return this.#finish('superseded');
      if (res.status === 401) return this.#finish('auth_revoked');
      // 404 (not ours) and other 4xx will not change on retry.
      if (res.status >= 400 && res.status < 500) return this.#finish('failed');
    }
    // Lease gone: the server has (or will have) reaped it; ask it to end now.
    this.#finish('failed');
    await this.transport.del(`/v1/live/sessions/${call.id}`).catch(() => undefined);
  }

  #receive(data: ArrayBuffer | string): void {
    if (typeof data === 'string') {
      let e: Record<string, unknown>;
      try { e = JSON.parse(data) as Record<string, unknown>; } catch { return; }
      return this.#event(e);
    }
    if (Object.prototype.toString.call(data) !== '[object ArrayBuffer]') return this.#protocolError('frame type');
    let frame: LiveFrame;
    try {
      frame = decodeLiveFrame(new Uint8Array(data));
    } catch (error) {
      // The server only sends 672-byte CLV1 frames; anything else means the stream is not ours to trust.
      return this.#protocolError(error instanceof Error ? error.message : 'frame');
    }
    if (frame.direction !== 1) return;
    if (this.#barging || frame.epoch !== this.#epoch || frame.generation !== this.#generation) { this.stats.staleDropped++; return; }
    this.stats.received++;
    this.sink?.play(frame.audio, frame.sequence, frame.generation);
  }

  /** A frame that does not decode: count it, end the call `failed` with the reason, and ask the server to end it. */
  #protocolError(reason: string): void {
    this.stats.protocolErrors++;
    if (this.#closed) return;
    const call = this.#call;
    const wasOpen = this.#open;
    this.#control({ op: 'end' });
    this.#finish('failed', reason);
    if (call && !wasOpen) void this.transport.del(`/v1/live/sessions/${call.id}`).catch(() => undefined);
  }

  #event(e: Record<string, unknown>): void {
    switch (e.type) {
      case 'ready':
        this.#open = true;
        this.#barging = false;
        if (typeof e.generation === 'number') this.#generation = this.stats.generation = e.generation;
        this.#set({ phase: 'listening' });
        if (this.#snap.muted) this.#control({ op: 'mute', muted: true });
        return;
      case 'speech_started': this.#set({ phase: 'hearing', partial: '', turn_error: undefined }); return;
      case 'speech_ended': this.#set({ phase: 'thinking' }); return;
      case 'partial_transcript': if (typeof e.text === 'string' && !this.#snap.muted) this.#set({ partial: e.text }); return;
      case 'transcript': this.#set(typeof e.text === 'string' && e.text ? { heard: [...this.#snap.heard, e.text], partial: '' } : { partial: '' }); return;
      case 'reply': if (e.spoken === true) this.#set({ phase: 'speaking', turn_error: undefined }); return;
      case 'error':
        this.#flush();
        this.#set({ phase: 'listening', partial: '', turn_error: typeof e.code === 'string' && e.code ? e.code : 'internal' });
        return;
      case 'interrupted':
        this.#barging = false;
        if (typeof e.generation === 'number') this.#generation = this.stats.generation = e.generation;
        this.#flush();
        this.#set({ phase: 'listening', partial: '' });
        return;
      case 'playback_end': this.#set({ phase: 'listening' }); return;
    }
  }

  /** One 640-byte PCM16 frame from the microphone. */
  capture(audio: Uint8Array): void {
    if (this.#snap.muted) { this.stats.mutedDropped++; return; }
    if (!this.#open || !this.#socket) return;
    // Capture frames always carry generation 0; only playback is generation-tagged.
    this.#socket.send(encodeLiveFrame({ direction: 0, epoch: this.#epoch, sequence: this.#seq++, generation: 0, audio }));
    this.stats.sent++;
  }

  /** Called by the sink once a playback frame has been heard. */
  played(sequence: number, generation: number): void {
    if (generation !== this.#generation) return;
    this.#control({ op: 'played', generation, sequence });
    this.stats.acked++;
  }

  #flush(): void { this.sink?.flush(); }

  #control(msg: Record<string, unknown>): void {
    if (this.#open) this.#socket?.send(JSON.stringify({ ...msg, epoch: String(this.#epoch) }));
  }

  setMuted(muted: boolean): void {
    this.#set(muted ? { muted, partial: '' } : { muted });
    this.#control({ op: 'mute', muted });
  }

  /** Barge-in: stop what is playing now and cancel the server turn. */
  interrupt(): void {
    this.#barging = this.#open;
    this.#flush();
    this.#control({ op: 'interrupt' });
  }

  /** Hang up: tell the server, then release locally. */
  async end(): Promise<void> {
    if (this.#closed) return;
    const call = this.#call;
    const wasOpen = this.#open;
    this.#control({ op: 'end' });
    this.#finish('ended');
    if (call && !wasOpen) await this.transport.del(`/v1/live/sessions/${call.id}`).catch(() => undefined);
  }

  /** Navigation, logout or unmount: release locally and end server-side. */
  close(): void { void this.end(); }

  /** The microphone went away mid-call (permission revoked, device unplugged): end the call server-side. */
  async micLost(): Promise<void> {
    if (this.#closed) return;
    const call = this.#call;
    this.#finish('mic_lost');
    if (call) await this.transport.del(`/v1/live/sessions/${call.id}`).catch(() => undefined);
  }

  /**
   * Signed out or account replaced. Logout ends this session's calls server-side (4001); an account
   * switch does not, so ask the server to end the call too (a no-op once it has).
   */
  revoke(): void {
    this.#control({ op: 'end' });
    const socket = this.#socket;
    this.#socket = null;
    this.#finish('auth_revoked');
    // The server closes this session's sockets itself (4001); close locally only if it has not.
    if (socket) setTimeout(() => socket.close(), REVOKE_GRACE_MS);
  }

  #finish(end: CallEnd, protocolError?: string): void {
    if (this.#closed) return;
    this.#closed = true;
    const socket = this.#socket;
    this.#socket = null;
    this.#open = false;
    socket?.close();
    this.#flush();
    this.#set({ phase: end === 'ended' ? 'ended' : 'error', end, partial: '', ...(protocolError === undefined ? {} : { protocol_error: protocolError }) });
  }
}

/** Float32 at any rate -> 16 kHz samples (linear interpolation); `carry` keeps phase across chunks. */
export function resampleTo16k(input: Float32Array, rate: number, carry: { pos: number; last?: number }): Int16Array {
  if (!input.length) return new Int16Array();
  const step = rate / CALL_SAMPLE_RATE;
  const out: number[] = [];
  let pos = carry.pos;
  while (pos < input.length - 1) {
    const i = Math.floor(pos);
    const f = pos - i;
    const v = (i < 0 ? (carry.last ?? input[0]!) : input[i]!) * (1 - f) + input[i + 1]! * f;
    out.push(Math.max(-32768, Math.min(32767, Math.round(v * 32767))));
    pos += step;
  }
  carry.pos = pos - input.length;
  carry.last = input[input.length - 1]!;
  return Int16Array.from(out);
}

/** Drains whole 20 ms PCM16LE frames from accumulated 16 kHz samples (the remainder stays in `pending`). */
export function takeCallFrames(pending: number[]): Uint8Array[] {
  const frames: Uint8Array[] = [];
  while (pending.length >= CALL_FRAME_SAMPLES) {
    const out = new Uint8Array(LIVE_FRAME.audio_bytes);
    const v = new DataView(out.buffer);
    pending.splice(0, CALL_FRAME_SAMPLES).forEach((s, i) => v.setInt16(i * 2, s, true));
    frames.push(out);
  }
  return frames;
}
