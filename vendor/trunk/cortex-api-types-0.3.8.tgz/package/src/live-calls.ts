/**
 * Bot call media helpers for `POST /v1/live/sessions` and its WebSocket.
 *
 * Mirrors `server/src/api/live-calls.ts` (Task10, migration 0158). Speech is
 * endpointed by the server. With `stt: 'streaming'` it is recognised while the
 * caller speaks and `partial_transcript{text}` events precede the committed
 * `transcript`; with `stt: 'utterance'` it is recognised once per utterance and
 * there are no partials. Replies stream back as PCM frames that the caller may
 * interrupt (barge-in). `live` is Chat Live: the same transport with `surface: 'chat'`.
 *
 * Binary frames are 672 bytes: a 32-byte little-endian header (`CLV1`, u8
 * version 1, u8 direction, u16 flags 0, u64 epoch, u32 sequence, u32
 * generation, u64 timestamp µs) and 640 bytes of 16 kHz mono PCM16LE (20 ms).
 */

export const LIVE_FRAME = { magic: 'CLV1', version: 1, header_bytes: 32, audio_bytes: 640, bytes: 672 } as const;

/** `0` capture (client to server), `1` playback (server to client). */
export type LiveFrameDirection = 0 | 1;

export interface LiveFrame {
  readonly direction: LiveFrameDirection;
  /** The call epoch the frame belongs to; must equal the socket's `LiveCall.epoch`. */
  readonly epoch: bigint;
  readonly sequence: number;
  /** Capture frames carry 0; playback frames carry the server generation. */
  readonly generation: number;
  /** Sender monotonic clock in µs; informational only. */
  readonly timestampUs: bigint;
  /** 640 bytes of PCM16LE. Decoding returns a view into the input. */
  readonly audio: Uint8Array;
}

export interface LiveFrameInput {
  readonly direction: LiveFrameDirection;
  /** Decimal `LiveCall.epoch` string or its bigint value. */
  readonly epoch: string | bigint;
  readonly sequence: number;
  readonly generation: number;
  readonly audio: Uint8Array;
  readonly timestampUs?: bigint;
}

const U64_MAX = (1n << 64n) - 1n;
const U32_MAX = 0xffff_ffff;

function u32(name: string, value: number): number {
  if (!Number.isInteger(value) || value < 0 || value > U32_MAX) throw new RangeError(`${name} must be a u32.`);
  return value;
}

function u64(name: string, value: string | bigint): bigint {
  if (typeof value === 'string' && !/^(0|[1-9][0-9]{0,19})$/.test(value)) throw new RangeError(`${name} must be a decimal u64.`);
  const n = BigInt(value);
  if (n < 0n || n > U64_MAX) throw new RangeError(`${name} must be a u64.`);
  return n;
}

/** Encodes one frame. Throws `RangeError` for any value the server would refuse by layout. */
export function encodeLiveFrame(input: LiveFrameInput): Uint8Array {
  if (input.direction !== 0 && input.direction !== 1) throw new RangeError('direction must be 0 (capture) or 1 (playback).');
  if (input.audio.byteLength !== LIVE_FRAME.audio_bytes) throw new RangeError(`audio must be exactly ${LIVE_FRAME.audio_bytes} bytes.`);
  const generation = u32('generation', input.generation);
  if (input.direction === 0 && generation !== 0) throw new RangeError('capture frames carry generation 0.');
  const out = new Uint8Array(LIVE_FRAME.bytes);
  const v = new DataView(out.buffer);
  out.set([0x43, 0x4c, 0x56, 0x31], 0);
  v.setUint8(4, LIVE_FRAME.version);
  v.setUint8(5, input.direction);
  v.setUint16(6, 0, true);
  v.setBigUint64(8, u64('epoch', input.epoch), true);
  v.setUint32(16, u32('sequence', input.sequence), true);
  v.setUint32(20, generation, true);
  v.setBigUint64(24, u64('timestampUs', input.timestampUs ?? BigInt(Math.floor(performance.now() * 1000))), true);
  out.set(input.audio, LIVE_FRAME.header_bytes);
  return out;
}

/** Decodes one frame. Throws `RangeError` naming the first layout violation. */
export function decodeLiveFrame(bytes: ArrayBuffer | Uint8Array): LiveFrame {
  const buf = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (buf.byteLength !== LIVE_FRAME.bytes) throw new RangeError('frame length');
  if (buf[0] !== 0x43 || buf[1] !== 0x4c || buf[2] !== 0x56 || buf[3] !== 0x31) throw new RangeError('frame magic');
  const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  if (v.getUint8(4) !== LIVE_FRAME.version) throw new RangeError('frame version');
  const direction = v.getUint8(5);
  if (direction !== 0 && direction !== 1) throw new RangeError('frame direction');
  if (v.getUint16(6, true) !== 0) throw new RangeError('frame flags');
  return {
    direction,
    epoch: v.getBigUint64(8, true),
    sequence: v.getUint32(16, true),
    generation: v.getUint32(20, true),
    timestampUs: v.getBigUint64(24, true),
    audio: buf.subarray(LIVE_FRAME.header_bytes),
  };
}

const WS_PATH = /^\/v1\/live\/sessions\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\/media\?ticket=[0-9a-f]+$/i;

/**
 * The media WebSocket URL for a fresh `LiveCallTicket` (create or resume).
 * The ticket is one-use, valid 15 s, and must never be logged.
 */
export function liveMediaUrl(baseUrl: string, call: { readonly ws_path: string }): string {
  if (!WS_PATH.test(call.ws_path)) throw new RangeError('ws_path is not a Bot call media path.');
  const base = new URL(baseUrl);
  if (base.protocol !== 'http:' && base.protocol !== 'https:') throw new RangeError('baseUrl must be http or https.');
  if (base.search || base.hash) throw new RangeError('baseUrl must not carry a query or fragment.');
  base.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:';
  return base.href.replace(/\/+$/, '') + call.ws_path;
}

export interface BotCallAvailable {
  readonly available: true;
  readonly transport: 'cortex-live-v1';
  /** `streaming`: recognised while the caller speaks; `utterance`: once per server-endpointed utterance. */
  readonly stt: 'streaming' | 'utterance';
  readonly tts: 'pcm_stream';
  /** `true` exactly when `stt` is `streaming`: `partial_transcript` events are sent. */
  readonly interim_transcripts: boolean;
  /** Caller speech or `{op:'interrupt'}` cancels the reply in flight. */
  readonly barge_in: true;
}

export interface BotCallUnavailable {
  readonly available: false;
  readonly transport: 'cortex-live-v1';
  readonly stt: 'unavailable';
  readonly tts: 'unavailable';
  readonly interim_transcripts: false;
  readonly barge_in: false;
}

export type BotCallCapabilities = BotCallAvailable | BotCallUnavailable;

/** `GET /v1/audio/capabilities`, narrowed to what the server implementation can return. */
export interface CallAudioCapabilities {
  readonly stt: boolean;
  readonly tts: boolean;
  /** Chat Live (`surface: 'chat'`) is available; the server sets it exactly when calls are configured. */
  readonly live: boolean;
  readonly bot_call: BotCallCapabilities;
}

const KEYS = ['available', 'barge_in', 'interim_transcripts', 'stt', 'transport', 'tts'].join();

/** Narrows an untrusted capabilities body; `undefined` when it is not exactly an implemented shape. */
export function parseAudioCapabilities(value: unknown): CallAudioCapabilities | undefined {
  if (!value || typeof value !== 'object') return undefined;
  const v = value as Record<string, unknown>;
  const c = v.bot_call as Record<string, unknown> | null | undefined;
  if (typeof v.stt !== 'boolean' || typeof v.tts !== 'boolean' || typeof v.live !== 'boolean' || !c || typeof c !== 'object') return undefined;
  if (Object.keys(c).sort().join() !== KEYS || c.transport !== 'cortex-live-v1') return undefined;
  const speech = (c.stt === 'streaming' && c.interim_transcripts === true) || (c.stt === 'utterance' && c.interim_transcripts === false);
  const on = c.available === true && speech && c.tts === 'pcm_stream' && c.barge_in === true;
  const off = c.available === false && c.stt === 'unavailable' && c.interim_transcripts === false && c.tts === 'unavailable' && c.barge_in === false;
  return on || off ? (value as CallAudioCapabilities) : undefined;
}
